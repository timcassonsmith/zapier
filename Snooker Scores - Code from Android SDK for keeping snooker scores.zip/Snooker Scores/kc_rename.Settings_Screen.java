package Snooker.Scores;

import android.app.Activity;
import android.os.Bundle;


import android.widget.CheckBox;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
public class Settings_Screen extends Activity  {
	CheckBox en_anim;
	CheckBox en_snd;
	
	SharedPreferences savesnookersettings;
    public static final String SNOOKER_PREFS ="Snookerprefs";
    public static final String SNOOKER_PREFS_SND = "Sound";
    public static final String SNOOKER_PREFS_ANIM = "Anim";
    Editor snookereditor;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settingsscreen);
		setTitle("Settings");
	 
		savesnookersettings = getSharedPreferences(SNOOKER_PREFS,MODE_PRIVATE);
		snookereditor = savesnookersettings.edit();
		en_snd = (CheckBox)findViewById(R.id.en_snd);
		en_anim = (CheckBox)findViewById(R.id.en_anim);
		
		loadsettings();
		
	
	}
	
	public void loadsettings() {
		en_snd.setChecked(savesnookersettings.getBoolean(SNOOKER_PREFS_SND, false));
		en_anim.setChecked(savesnookersettings.getBoolean(SNOOKER_PREFS_ANIM, false));
	}
	

	
	@Override
	protected void onPause() {
		super.onPause();
		snookereditor.putBoolean(SNOOKER_PREFS_SND, en_snd.isChecked());
		snookereditor.putBoolean(SNOOKER_PREFS_ANIM, en_anim.isChecked());
		snookereditor.commit();
		
	}
	
	


	

}
