package Snooker.Scores;





import java.io.IOException;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.app.AlertDialog;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.RadioButton;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.ImageView;
//import android.widget.RelativeLayout;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
//import android.widget.Toast;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;


public class Snooker_ScoresActivity extends Activity implements OnLongClickListener, SeekBar.OnSeekBarChangeListener, OnClickListener, OnCheckedChangeListener, TextWatcher,OnCompletionListener {
    /** Called when the activity is first created. */
	RadioButton go_player1;
	RadioButton go_player2;
	Dialog scoresD;
	int new_scores_player = 0;
	int new_scores = 0;
	EditText newscores;
	String updatedscore = "";	
	Button confirm;
	Button canceld;
	SeekBar newscores_bar;
	Dialog ScoresDialog;
	public int redballcount = 15;
	public static int redballscore =    1;
	public static int greenballscore =  3;
	public static int yellowballscore = 2;
	public static int brownballscore =  4;
	public static int blueballscore =   5;
	public static int pinkballscore =   6;
	public static int blackballscore =  7;
	public static int foulballscore = 4;
	public int soundeffect = 1;
	public int animcheck = 1;
	public int player1score = 0;
	public int player2score = 0;
	public int isfoul = 0;
	public int whichplayer = 0;
	public String player1sname = "";
	public String player2sname = "";
	public String playerscore = "";
    TextView playersname1;
    TextView playersname2;
    TextView PlayersScore1;
    TextView PlayersScore2;
    EditText pname1;
    EditText pname2;
    CheckBox foulpot;
    public int isSoundplaying = 0;
   // Button clear_scores;
    AlertDialog.Builder builder1;
    AlertDialog alertDialog1;
    Button theplus;
    Button theminus;
    EditText newredcounttext;
    public int breakbuildup_Player1 = 0;
    public int breakbuildup_Player2 = 0;
    public int totalframes = 0;
    public int player1frames = 0;
    public int player2frames = 0;
    Intent SettingsIntent;
    SharedPreferences readsnookersettings;
    CheckBox Soundonoff;
    ImageButton Gball;
    ImageButton Rball;
    ImageButton Cball;
    ImageButton BLball;
    ImageButton Piball;
    ImageButton Yeball;
    ImageButton Brball;
    ImageButton Bball;
    TextView onefourseven;
    Animation onefs;
    public int dialogtype = 0;
    public int remainingballs=0;
    public int remainingframes=0;
    public int totalballs=0;
    
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // Set up the snooker balls 
        Bball = (ImageButton)findViewById(R.id.blackball); 
        Bball.setOnClickListener(Snooker_ScoresActivity.this);
        
        Gball = (ImageButton)findViewById(R.id.greenball); 
        Gball.setOnClickListener(this);
        Rball = (ImageButton)findViewById(R.id.redball); 
        Rball.setOnClickListener(this);
        Rball.setOnLongClickListener(this);
        Cball = (ImageButton)findViewById(R.id.cueball); 
        Cball.setOnClickListener(this);
        BLball = (ImageButton)findViewById(R.id.blueball); 
        BLball.setOnClickListener(this);
        Piball = (ImageButton)findViewById(R.id.pinkball); 
        Piball.setOnClickListener(this);
        Yeball = (ImageButton)findViewById(R.id.yellowball); 
        Yeball.setOnClickListener(this);
        Brball = (ImageButton)findViewById(R.id.brownball); 
        Brball.setOnClickListener(this);
        
        
      //  clear_scores = (Button)findViewById(R.id.Clear_scores);
       // clear_scores.setOnClickListener(this);
        // Text Labels for the two players so that the scores can be kept
        /*final TextView playersname1 = (TextView)findViewById(R.id.Player1_score);
        playersname1.setSaveEnabled(true);
        player1sname = playersname1.getText().toString();
        final TextView playersname2 = (TextView)findViewById(R.id.Player2_score);
        playersname2.setSaveEnabled(true);
        player2sname = playersname2.getText().toString()*/
        
        pname1 = (EditText)findViewById(R.id.Player1_name);
        
        
        // Set up Foul pot check box and by default this is unchecked 
        CheckBox foulpot = (CheckBox)findViewById(R.id.Foul);
        foulpot.setOnCheckedChangeListener(new OnCheckedChangeListener()
        {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if ( isChecked )
                {
                    isfoul = 1; // perform logic
                   
                }else {
                	isfoul = 0;
                }

            }
        });
        foulpot.setChecked(false);
        Soundonoff = (CheckBox)findViewById(R.id.Sound_on_off);
        loadsnookersettings();
        
       /* Soundonoff.setOnCheckedChangeListener(new OnCheckedChangeListener()
        {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if ( isChecked )
                {
                    soundeffect = 1; // perform logic
                   
                }else {
                	soundeffect = 0;
                }

            }
        });*/
      //  Soundonoff.setChecked(true);
       
        // Set up edit boxes ...
      //  final EditText pname1 = (EditText)findViewById(R.id.Player1_name);
        // ... and then create the method which monitors changes of the players names 
      /*  pname1.addTextChangedListener(new TextWatcher()   {

			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				if (player1score != 0 ) {
					playersname1.setText(pname1.getText()+" : "+Integer.toString(player1score));
					player1sname = playersname1.getText().toString();
				} else {
				    playersname1.setText(pname1.getText()+" :");
			        player1sname = playersname1.getText().toString();
				}
			    //Toast.makeText(this, player1sname, Toast.LENGTH_LONG).show();
			}

			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}

			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub
				
			}
        });
        final EditText pname2 = (EditText)findViewById(R.id.Player2_name);
        pname2.addTextChangedListener(new TextWatcher() {

			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				if (player2score != 0) {
				     playersname2.setText(pname2.getText()+ " : " + Integer.toString(player2score));
				     player2sname = playersname2.getText().toString();
					
				} else {
				     playersname2.setText(pname2.getText()+ " : ");
				     player2sname = playersname2.getText().toString();
				}
			}

			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}

			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				// TODO Auto-generated method stub
				
			}
        }); */
        
        
        go_player1 =(RadioButton)findViewById(R.id.Players1_turn);
        go_player1.setChecked(true);
        whichplayer = 1;
        go_player1.setOnClickListener(this);
        go_player2 =(RadioButton)findViewById(R.id.Players2_turn);
        go_player2.setOnClickListener(this);
        
        
        
        scoresD = new Dialog(this);
        scoresD.setContentView(R.layout.playerscores);
        scoresD.setTitle("Please Enter Players New Score");
         scoresD.setCancelable(true);
         
         
        
         newscores = (EditText) scoresD.findViewById(R.id.newscores);
        // newscores.setOnClickListener(this);
        
          confirm = (Button)scoresD.findViewById(R.id.confirm);
          confirm.setOnClickListener(this);
        
         canceld = (Button)scoresD.findViewById(R.id.cancel);
        canceld.setOnClickListener(this);
        
        newscores_bar = (SeekBar)scoresD.findViewById(R.id.seekbar);
        newscores_bar.setMax(200);
        newscores_bar.setOnSeekBarChangeListener(this);
        
        /* ScoresDialog = new Dialog(this);
        ScoresDialog.setContentView(R.layout.set_scores);
        ScoresDialog.setTitle("Enter value");       
        ScoresDialog.setCancelable(true); */

        

        //Context mContext = getApplicationContext();
        LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.set_scores,null);
        
       
        
       newredcounttext = (EditText)layout.findViewById(R.id.redballscores);
       newredcounttext.setText(""); 
        // sets up dialog box to be used with the plus and minus buttons
        builder1 = new AlertDialog.Builder(this);
        builder1.setTitle("Enter Number :");
        builder1.setPositiveButton("Set", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				  setupdialog(dialogtype);
	              //redballcount = redballcount -1;			
			}
		});
        builder1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
			    alertDialog1.cancel();	
			}
		});
        
        
        builder1.setView(layout);
        
        
        alertDialog1 = builder1.create();
        theplus = (Button)layout.findViewById(R.id.plus);
        theplus.setOnClickListener(this);
        
        theminus = (Button)layout.findViewById(R.id.minus);
        theminus.setOnClickListener(this);
       // alertDialog.show();

        PlayersScore1 = (TextView)findViewById(R.id.Player1_score);
        PlayersScore1.setSaveEnabled(true);
      // PlayersScore1.setOnClickListener(this);
        PlayersScore2 = (TextView)findViewById(R.id.Player2_score);
        PlayersScore2.setSaveEnabled(true);
        SettingsIntent = new Intent(this,Settings_Screen.class);
        onefourseven = (TextView)findViewById(R.id.onefourseven);
        onefourseven.setVisibility(View.INVISIBLE);
        
        

    }
    
    
    
    // Define the Main Menu 
    public boolean onCreateOptionsMenu (Menu menu){
    	MenuInflater inflater = getMenuInflater();
    	inflater.inflate(R.menu.mainmenu, menu);
    		
    	return true;
    }
    
    
    
    // Set up the Main Menu options
    public boolean onOptionsItemSelected(MenuItem item){
    	//RelativeLayout rlayoutp = (RelativeLayout)findViewById(R.id.port);
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	
       switch (item.getItemId()){
       case R.id.item1:
    	   // This needs the latest dialog adding with plus and minus
    	   new_scores_player = 1;
    	   newscores.setText("");
    	//   newscores_bar.setProgress(0);
    	 //  scoresD.setTitle("Enter Players 1 score");
    	   dialogtype = 2;
    	  // scoresD.show();
    	   setupdialog(dialogtype);
    	  
    	   
    	   //Toast.makeText(this, "Menu Number one", Toast.LENGTH_LONG).show();
           return true;
     /*  case R.id.item2:
    	   new_scores_player = 2;
    	   newscores.setText("");
    	 //  newscores_bar.setProgress(0);
    	//   scoresD.setTitle("Enter Players 2 score");
    //	   scoresD.show();
    	   //Toast.makeText(this, "Menu Number two", Toast.LENGTH_LONG).show();
    	   return true; */
    	   
       case R.id.item3:
    	 //  newscores_bar.setProgress(0);
    	 //  scoresD.setTitle("Enter How Many Frames");
    	   dialogtype = 1;
    	//   scoresD.show();
    	   setupdialog(dialogtype);
    	   return true;
    	   
       case R.id.item4:
    	   builder.setMessage("Are you sure you want to clear the scores?")
	       .setCancelable(false)
	       .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
	           public void onClick(DialogInterface dialog, int id) {
	               // clear_scores.performClick();
	        	   
	        	player1score = 0;
	   			player2score = 0;
	   			PlayersScore1.setText("Score : ");
	   			PlayersScore2.setText("Score : ");
	   			go_player2.setChecked(false);
	   			go_player1.setChecked(true);
	   			whichplayer = 1;
	           }
	       })
	       .setNegativeButton("No", new DialogInterface.OnClickListener() {
	           public void onClick(DialogInterface dialog, int id) {
	                dialog.cancel();
	           }
	       });
	        AlertDialog alert = builder.create();
    	    alert.show();
    	    return true;
       case R.id.item5:
    	   
    	    startActivity(SettingsIntent);
    	    
    	    return true;
       default:
    	   return super.onOptionsItemSelected(item);
       }
    	
    
    }
    
   /* public void setnewscores(int new_scores_player){
    	
    	
       if (new_scores_player == 1) {
    	   //player1score = newscores.getText().toString();
    	   PlayersScore1.setText("Score : " +Integer.toString(45));
    	   
       }
          
    } */
    
    @Override 
    public void onSaveInstanceState(Bundle outState) 
    {
        //---save whatever you need to persist�
        outState.putString("p1name",pname1.getText().toString());
        if (player1score != 0 ){
        outState.putInt("p1score", player1score);
        }
        if (player2score != 0 ){
        outState.putInt("p2score", player2score);
        }
        if (go_player1.isChecked()) {
        	outState.putBoolean("goplayer1", true);
        } else if (go_player2.isChecked()) {
        	outState.putBoolean("goplayer2", true);
        	
        }
        super.onSaveInstanceState(outState); 
    }
    
    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) 
    {
        super.onRestoreInstanceState(savedInstanceState);
        go_player1 = (RadioButton)findViewById(R.id.Players1_turn);
        go_player2 = (RadioButton)findViewById(R.id.Players2_turn);
        go_player1.setChecked(false);
        go_player2.setChecked(false);
        go_player1.setChecked(savedInstanceState.getBoolean("goplayer1", false));
        go_player2.setChecked(savedInstanceState.getBoolean("goplayer2", false));
        PlayersScore1 = (TextView)findViewById(R.id.Player1_score);
        PlayersScore2 = (TextView)findViewById(R.id.Player2_score);
        //---retrieve the information persisted earlier---
        player1score = savedInstanceState.getInt("p1score");
        player2score = savedInstanceState.getInt("p2score");
        if (player1score != 0) {
          PlayersScore1.setText("Score : " + Integer.toString(player1score));
        }
        if (player2score != 0 ){
          PlayersScore2.setText("Score : " + Integer.toString(player2score));
            }
          pname1.setText(savedInstanceState.getString("p1name"));   
    }
  

    
	public void onClick(View v) {
		// TODO Auto-generated method stub
		//Animation BallAni = AnimationUtils.loadAnimation(this, R.anim.ball_animation);
		
        //PlayersScore2.setOnClickListener(this);
        
        if (v == theplus) {
        	dialogvalues(dialogtype,0);
        	/*if (redballcount < 15) {
        	  redballcount = redballcount +1;
              newredcounttext.setText(Integer.toString(redballcount));
        	} else {
                newredcounttext.setText(Integer.toString(redballcount));
        	} */
        }
        
        if (v == theminus) {
        	dialogvalues(dialogtype,1);
        	/*if (redballcount > 1 ) {
        		redballcount = redballcount -1;
                newredcounttext.setText(Integer.toString(redballcount));
        		
        	} else {
                newredcounttext.setText(Integer.toString(redballcount));
        		
        	}*/
        	
        }
        
        if (v == confirm) {
        	//Toast.makeText(this, "Confirm has ben pressed", Toast.LENGTH_SHORT).show();
        	if (new_scores_player == 1) {
        		PlayersScore1.setText("Score : " +newscores.getText().toString());
        	    player1score = Integer.parseInt(newscores.getText().toString());
        		scoresD.dismiss();
        	}
        	if (new_scores_player == 2) {
        		PlayersScore2.setText("Score : " +newscores.getText().toString());
        		player2score = Integer.parseInt(newscores.getText().toString());
        		
        		scoresD.dismiss();
        	} 
        	
        }
        
        if (v == canceld){
        	scoresD.cancel();
        }
        
        
		if (v == go_player1 ){
			//Toast.makeText(this, "This is players 1 turn", Toast.LENGTH_LONG).show();
			go_player2.setChecked(false);
			go_player2.setSaveEnabled(false);
			whichplayer = 1;
		}else if (v == go_player2){
			//Toast.makeText(this, "This is players 2 turn", Toast.LENGTH_LONG).show();
			go_player1.setChecked(false);
			go_player1.setSaveEnabled(false);
			whichplayer = 2;
		}
	        
	/*	if (v == clear_scores){
			player1score = 0;
			player2score = 0;
			PlayersScore1.setText("Score : ");
			PlayersScore2.setText("Score : ");
			go_player2.setChecked(false);
			go_player1.setChecked(true);
			whichplayer = 1;
		
			
		}*/
		
	   
		switch (v.getId()) {
		case R.id.blackball:
			/* Animation BallAni = AnimationUtils.loadAnimation(this, R.anim.ball_animation);
		        blackballani.startAnimation(BallAni);*/
              //	v.setAnimation(BallAni)	;
              	snookerballanim(Bball,animcheck);
			// Is this player 1 and not a foul pot?
			if (whichplayer == 1 && isfoul == 0){
				 // If so add the point of the potted ball
				PlayersScore1.setText("Score : " + playerscores(0,blackballscore,whichplayer));
				  // Otherwise has player fouled on this ball ?
			}else if (whichplayer == 1 && isfoul == 1){
				   // If they have add the score to player2
				 PlayersScore2.setText("Score : " +playerscores(1,blackballscore,whichplayer));
			}	
			
			if (whichplayer == 2 && isfoul==0) {
				PlayersScore2.setText("Score : " + playerscores(0,blackballscore,whichplayer));
		
			} else if (whichplayer == 2 && isfoul==1){

				  PlayersScore1.setText("Score : " +playerscores(1,blackballscore,whichplayer));
			  }
		
			playpotsound();		 
			break; 
			 
		case R.id.greenball:
			//Toast.makeText(this, "The Green Ball is a score of 3", Toast.LENGTH_LONG).show();
			snookerballanim(Gball,animcheck);
			//v.setAnimation(BallAni)	;
			if (whichplayer == 1 && isfoul == 0){
				PlayersScore1.setText("Score : " + playerscores(0,greenballscore,whichplayer));
			}else if (whichplayer == 1 && isfoul == 1){
				 PlayersScore2.setText("Score : " +playerscores(1,foulballscore,whichplayer));
			}	
			
			if (whichplayer == 2 && isfoul==0) {
				//Toast.makeText(this, "Player 1 score is now : "+ playerscores(0,blackballscore,whichplayer), Toast.LENGTH_LONG).show();
               // updatescores(PlayersScore1,playerscore);
				PlayersScore2.setText("Score : " + playerscores(0,greenballscore,whichplayer));
		
			} else if (whichplayer == 2 && isfoul==1){
				 // Toast.makeText(this, "Oh No fouled on the black thats 7 points!!", Toast.LENGTH_LONG).show();
				  PlayersScore1.setText("Score : " +playerscores(1,foulballscore,whichplayer));
			  }
			playpotsound();
			 
			break;	
		case R.id.cueball:
		//	Toast.makeText(this, "Well If you pot this you are giving a point of 4 away !!!!", Toast.LENGTH_LONG).show();
			snookerballanim(Cball,animcheck);
			//v.setAnimation(BallAni)	;
			if (whichplayer == 1){
				PlayersScore2.setText("Score : "+playerscores(1,foulballscore,whichplayer));
			}else
			{
				PlayersScore1.setText("Score : "+playerscores(1,foulballscore,whichplayer));
			}
			playpotsound();
			 
			break;			
		case R.id.redball:
			snookerballanim(Rball,animcheck);
			//v.setAnimation(BallAni)	;
			//Toast.makeText(this, "The Red ball is a score of 1", Toast.LENGTH_LONG).show();
			if (whichplayer == 1 && isfoul == 0){
				PlayersScore1.setText("Score : " + playerscores(0,redballscore,whichplayer));
			}else if (whichplayer == 1 && isfoul == 1){
				 PlayersScore2.setText("Score : " +playerscores(1,foulballscore,whichplayer));
			}	
			
			if (whichplayer == 2 && isfoul==0) {
				//Toast.makeText(this, "Player 1 score is now : "+ playerscores(0,blackballscore,whichplayer), Toast.LENGTH_LONG).show();
               // updatescores(PlayersScore1,playerscore);
				PlayersScore2.setText("Score : " + playerscores(0,redballscore,whichplayer));
		
			} else if (whichplayer == 2 && isfoul==1){
				 // Toast.makeText(this, "Oh No fouled on the black thats 7 points!!", Toast.LENGTH_LONG).show();
				  PlayersScore1.setText("Score : " +playerscores(1,foulballscore,whichplayer));
			  }
			playpotsound();
			break;
			
		case R.id.blueball:
			//Toast.makeText(this, "The Blue ball is a score of 5", Toast.LENGTH_LONG).show();
			snookerballanim(BLball,animcheck);
			//v.setAnimation(BallAni)	;
			if (whichplayer == 1 && isfoul == 0){
				PlayersScore1.setText("Score : " + playerscores(0,blueballscore,whichplayer));
			}else if (whichplayer == 1 && isfoul == 1){
				 PlayersScore2.setText("Score : " +playerscores(1,blueballscore,whichplayer));
			}	
			
			if (whichplayer == 2 && isfoul==0) {
				//Toast.makeText(this, "Player 1 score is now : "+ playerscores(0,blackballscore,whichplayer), Toast.LENGTH_LONG).show();
               // updatescores(PlayersScore1,playerscore);
				PlayersScore2.setText("Score : " + playerscores(0,blueballscore,whichplayer));
		
			} else if (whichplayer == 2 && isfoul==1){
				 // Toast.makeText(this, "Oh No fouled on the black thats 7 points!!", Toast.LENGTH_LONG).show();
				  PlayersScore1.setText("Score : " +playerscores(1,blueballscore,whichplayer));
			  }
			playpotsound();
			break;
			
		case R.id.pinkball:
			//Toast.makeText(this, "The Pink ball is a score of 6", Toast.LENGTH_LONG).show();
			snookerballanim(Piball,animcheck);
			//v.setAnimation(BallAni)	;
			if (whichplayer == 1 && isfoul == 0){
				PlayersScore1.setText("Score : " + playerscores(0,pinkballscore,whichplayer));
			}else if (whichplayer == 1 && isfoul == 1){
				 PlayersScore2.setText("Score : " +playerscores(1,pinkballscore,whichplayer));
			}	
			
			if (whichplayer == 2 && isfoul==0) {
				//Toast.makeText(this, "Player 1 score is now : "+ playerscores(0,blackballscore,whichplayer), Toast.LENGTH_LONG).show();
               // updatescores(PlayersScore1,playerscore);
				PlayersScore2.setText("Score : " + playerscores(0,pinkballscore,whichplayer));
		
			} else if (whichplayer == 2 && isfoul==1){
				 // Toast.makeText(this, "Oh No fouled on the black thats 7 points!!", Toast.LENGTH_LONG).show();
				  PlayersScore1.setText("Score : " +playerscores(1,pinkballscore,whichplayer));
			  }
			playpotsound();
			break;
			
		case R.id.yellowball:
			//Toast.makeText(this, "The Yellow ball is a score of 2", Toast.LENGTH_LONG).show();
			snookerballanim(Yeball,animcheck);
			//v.setAnimation(BallAni)	;
			if (whichplayer == 1 && isfoul == 0){
				PlayersScore1.setText("Score : " + playerscores(0,yellowballscore,whichplayer));
			}else if (whichplayer == 1 && isfoul == 1){
				 PlayersScore2.setText("Score : " +playerscores(1,foulballscore,whichplayer));
			}	
			
			if (whichplayer == 2 && isfoul==0) {
				//Toast.makeText(this, "Player 1 score is now : "+ playerscores(0,blackballscore,whichplayer), Toast.LENGTH_LONG).show();
               // updatescores(PlayersScore1,playerscore);
				PlayersScore2.setText("Score : " + playerscores(0,yellowballscore,whichplayer));
		
			} else if (whichplayer == 2 && isfoul==1){
				 // Toast.makeText(this, "Oh No fouled on the black thats 7 points!!", Toast.LENGTH_LONG).show();
				  PlayersScore1.setText("Score : " +playerscores(1,foulballscore,whichplayer));
			  }
			playpotsound();
			break;
			
		case R.id.brownball:
			//Toast.makeText(this, "The Brown ball is a score of 4", Toast.LENGTH_LONG).show();
			snookerballanim(Brball,animcheck);
			//v.setAnimation(BallAni)	;
			if (whichplayer == 1 && isfoul == 0){
				PlayersScore1.setText("Score : " + playerscores(0,brownballscore,whichplayer));
			}else if (whichplayer == 1 && isfoul == 1){
				 PlayersScore2.setText("Score : " +playerscores(1,foulballscore,whichplayer));
			}	
			
			if (whichplayer == 2 && isfoul==0) {
				//Toast.makeText(this, "Player 1 score is now : "+ playerscores(0,blackballscore,whichplayer), Toast.LENGTH_LONG).show();
               // updatescores(PlayersScore1,playerscore);
				PlayersScore2.setText("Score : " + playerscores(0,brownballscore,whichplayer));
		
			} else if (whichplayer == 2 && isfoul==1){
				 // Toast.makeText(this, "Oh No fouled on the black thats 7 points!!", Toast.LENGTH_LONG).show();
				  PlayersScore1.setText("Score : " +playerscores(1,foulballscore,whichplayer));
			  }
			playpotsound();
			break;

		}return;
	}
	public void playpotsound (){
		//Toast.makeText(this, "Reached play pot sound method", Toast.LENGTH_LONG).show();
		if (soundeffect == 1){ 
			
			MediaPlayer potballsound = MediaPlayer.create(this, R.raw.potsound);
			potballsound.setOnCompletionListener(this);
			potballsound.stop();
		
			try {
				potballsound.prepare();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 potballsound.start();
			 isSoundplaying = 1;
			 
		}
	 	 
		
	}
	
	public void playclapping() {
		//Toast.makeText(this, "Reached play clapping method", Toast.LENGTH_LONG).show();
		MediaPlayer cl = MediaPlayer.create(this, R.raw.clapping);
		//MediaPlayer clapping = MediaPlayer.create(this, R.raw.clapping);
		cl.setOnCompletionListener(this);
		cl.stop();
	
		try {
			cl.prepare();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 cl.start();
		 isSoundplaying = 1;
		 
	}
 	
		

	
	public void onCompletion(MediaPlayer arg0) {
        //Toast.makeText(this, "playback finished", Toast.LENGTH_LONG).show();
        arg0.release();
    }

	public String  playerscores(int foulup,int pottedball,int playerwhoscored){
		// to add scoring methods in here
	//	Toast.makeText(this, "Reached playerscores method", Toast.LENGTH_LONG).show();
		if (foulup == 0) {
			//Toast.makeText(this, "Reached foul up == 0 section", Toast.LENGTH_LONG).show();
			if (playerwhoscored == 1) {
				//Toast.makeText(this, "Reached playerscores non foul point section for player 1", Toast.LENGTH_LONG).show();
				player1score = player1score + pottedball;
			//	Toast.makeText(this, "updated player1score variable with the potted ball", Toast.LENGTH_LONG).show();
			    playerscore = Integer.toString(player1score);
			} else if (playerwhoscored == 2) {
				//Toast.makeText(this, "Reached playerscores non foul point section for player 2", Toast.LENGTH_LONG).show();
				player2score = player2score + pottedball;
				playerscore = Integer.toString(player2score);
			//	pscore2.setText(pscore2.getText() + " " + Integer.toString(player2score));
			}
			
		} else if (foulup == 1) {
			if (playerwhoscored == 1) {
				//Toast.makeText(this, "Reached playerscores  foul point section for player 1", Toast.LENGTH_LONG).show();
				player2score = player2score +  pottedball;
				playerscore = Integer.toString(player2score);
			  // pscore1.setText(pscore1.getText() + " " + Integer.toString(player1score));
			} else if (playerwhoscored == 2) {
				//Toast.makeText(this, "Reached playerscores foul point section for player 2", Toast.LENGTH_LONG).show();
		    	player1score = player1score + pottedball;
		    	playerscore = Integer.toString(player1score);
			//	pscore2.setText(pscore2.getText() + " " + Integer.toString(player2score));
			}	
			
		}
		return playerscore;
		
	}
	
	public void updatescores(TextView scores,String points) {
		scores.setText(scores.getText()+" "+points);
		
	}

	
	public void afterTextChanged(Editable arg0) {
		// TODO Auto-generated method stub
		
	}
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// TODO Auto-generated method stub
		
	}
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		// TODO Auto-generated method stub
		
	}
	public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
		// TODO Auto-generated method stub
		
	}

	public void onProgressChanged(SeekBar seekBar, int progress,
			boolean fromUser) {
		// TODO Auto-generated method stub
		newscores.setText(Integer.toString(progress));
		
	}

	public void onStartTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub
		
	}

	public void onStopTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub
		
	}

	public boolean onLongClick(View v) {
		// TODO Auto-generated method stub
		final CharSequence[] items = {"Dead Red", "Multiple Pots", "Run 147 animation"};
		onefs = AnimationUtils.loadAnimation(this, R.anim.one_four_seven);
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("Choose from the following:");
		builder.setIcon(null);
		builder.setItems(items, new DialogInterface.OnClickListener() {
		    public void onClick(DialogInterface dialog, int item) {
		        //Toast.makeText(getApplicationContext(), items[item], Toast.LENGTH_SHORT).show();
		        if (items[item] == "Dead Red") {
		        	Toast.makeText(getApplicationContext(), "Dead Read selected", Toast.LENGTH_SHORT).show();
		        	//ScoresDialog.show();
		        	dialogtype = 3;
		        	alertDialog1.show();
		        	//redballcount = redballcount -1 ;
		        	
		        }
		        if (items[item] == "Multiple Pots") {
		        	Toast.makeText(getApplicationContext(), "Mulitple Pots selected", Toast.LENGTH_SHORT).show();
		        	dialogtype = 0;
		        }
		        if (items[item] == "Run 147 animation") {
		        	
		        	onefourseven.setAnimation(null);
		        	onefourseven.setVisibility(View.VISIBLE);
		        	onefourseven.setAnimation(onefs);
		        	playclapping();
		        	
		        	onefourseven.setVisibility(View.INVISIBLE);
		        	
		        }
		       
		    }
		});
		AlertDialog alert = builder.create();
		switch (v.getId()) {
		
		case R.id.redball:
			//Toast.makeText(this,"Long Click Pressed on Red Ball", Toast.LENGTH_LONG).show();
			newredcounttext.setText(Integer.toString(redballcount));
		    alert.show();  
		}
		return true;
	}
	
	
    public void loadsnookersettings(){
    	readsnookersettings = getSharedPreferences("Snookerprefs",MODE_PRIVATE);
    	if (readsnookersettings.contains("Sound")) {
    		if (readsnookersettings.getBoolean("Sound", false)==true) {
    		   Soundonoff.setChecked(readsnookersettings.getBoolean("Sound", false));
    		   soundeffect =1;
    		} else {
    			Soundonoff.setChecked(readsnookersettings.getBoolean("Sound", false));
     		   soundeffect =0;
    		}
    	}
    	if (readsnookersettings.contains("Anim")) {
    		if (readsnookersettings.getBoolean("Anim", false)==true) {
    			animcheck = 1;
    		} else {
    			animcheck = 0;
    		}
    	}
    	    	
    }
    
    public void setupdialog(int type) {
    	/* type 0 = multiple red ball count 15 max
    	 * type 1 = frames
    	 * type 2 = players scores
    	 * type 3 = dead red 15 max
    	 *
    	*/
    	// Changes the players scores based on which player is currently selected
    	if (type == 2){
    		if (go_player1.isChecked()) {
    			
    			alertDialog1.setTitle("Enter Player 1s Score :");
    			alertDialog1.show();
    			
    		} else if (go_player2.isChecked()) {
    			alertDialog1.setTitle("Enter Player 2s Score :");
    			alertDialog1.show();
    		}
    	}
    	
    }
    
    public void snookerballanim(View balls, int anim) {
    	/* animates the snooker balls depending on anim flag */
    	Animation BallAni = AnimationUtils.loadAnimation(this, R.anim.ball_animation);
    	if (anim == 1) {
    	    balls.setAnimation(BallAni);
    	}
    }
	
    @Override
    protected void onResume() {
    	super.onResume();
    	loadsnookersettings();
    	
    }
    
    public void dialogvalues(int dtype, int plusminusset){
    	/* dtype values
    	 * type 0 = multiple red ball count 15 max
    	 * type 1 = frames
    	 * type 2 = players scores
    	 * type 3 = dead red 15 max
    	 ***************************
    	 * plusminusset values
    	 * type 0 = plus button selected
    	 * type 1 = minus button selected
    	 * type 2 = set button selected
    	 *
    	*/
    	if (dtype == 0 && plusminusset == 0 || dtype == 3 && plusminusset == 0 ){ 
     	   if (redballcount < 15) {
      	       redballcount = redballcount +1;
               newredcounttext.setText(Integer.toString(redballcount));
      	    } else {
               newredcounttext.setText(Integer.toString(redballcount));
      	    }
    	}
    	if (dtype == 0 && plusminusset == 1 || dtype == 3 && plusminusset == 1 ){
    	   if (redballcount > 1 ) {
    		  redballcount = redballcount -1;
              newredcounttext.setText(Integer.toString(redballcount));
    		
    	    } else {
              newredcounttext.setText(Integer.toString(redballcount));
    		
    	   }
    	}
    }
    
    public void frames() {
    	
    }
	
    	
} 