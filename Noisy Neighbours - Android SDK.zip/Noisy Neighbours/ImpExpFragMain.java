package co.uk.shieldstothemax.blastedneighbours;



import android.os.Build;
import java.io.BufferedReader;
//import java.io.BufferedWriter;
import java.io.File;
//import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
//import java.io.FileWriter;
import java.io.IOException;







import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.app.ProgressDialog;
import android.content.DialogInterface;

public class ImpExpFragMain extends FragmentActivity implements ImpExpFragment.TaskCallbacks {
	
	String readin = "";
	FileReader csvimp = null;
	String[] rowin = null;
	 BufferedReader csvbuffrag;
	 ProgressDialog test;
	 private ImpExpFragment mTaskFragment;
	 Boolean done;
	 
	 
	@Override
	  protected void onCreate(Bundle savedInstanceState) {
	   
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.fragmain);
         
         
       
      
       
       if (savedInstanceState != null && !done) {
    	     ///TODO needs restored values on
    	     test.setMessage("I am Back from a config change!");
    	     test.show();
    	    } else {
    	    	 new AlertDialog.Builder(this)
    		     .setIcon(R.drawable.quitapp)
    		     .setTitle("Press Now to Start Import!")
    		     .setPositiveButton("NOW", new DialogInterface.OnClickListener() {

    				@Override
    				public void onClick(DialogInterface dialog, int which) {
    					// TODO Auto-generated method stub
    					 test = new ProgressDialog(ImpExpFragMain.this);
    				       test.setProgressStyle(ProgressDialog.STYLE_SPINNER);
    				       test.setTitle("Import In Progress");
    				       test.setMessage("Please Wait ....");
    				       test.setCancelable(false);
    					mTaskFragment.start();
    				}})
    		     
    		     .show(); 
    	    }
       
       
       FragmentManager fm = getSupportFragmentManager();       
       mTaskFragment = (ImpExpFragment) fm.findFragmentByTag("task");
       
       if (mTaskFragment == null) {
    	   Bundle data = new Bundle();
           data = getIntent().getExtras();
             String datain = data.getString("FILE");
    	      mTaskFragment = new ImpExpFragment();
    	      String filename = datain;
    	      Bundle fragargs = new Bundle();
    	      fragargs.putString("file",filename);
    	      mTaskFragment.setArguments(fragargs);
    	      fm.beginTransaction().add(mTaskFragment, "task").commit();
    	    }
    
	    // Initialize views
      
	}
	
	
	
	@Override
	  public void onSaveInstanceState(Bundle outState) {
	    super.onSaveInstanceState(outState);
	    outState.putInt("COUNTER", mTaskFragment.callbackcounter);
	    outState.putString("DIALOG", "ON");
	    test.cancel();
	  }

	
	@Override
	public void onPreExecute() {
		// TODO Auto-generated method stub
		test.show();
		
	}
	@Override
	public void onProgressUpdate(int percent) {
		// TODO Auto-generated method stub
		
		test.setMessage("Increase is now: "+Integer.toString(percent));

	}
	@Override
	public void onCancelled() {
		// TODO Auto-generated method stub
		test.cancel();
	}
	@Override
	public void onPostExecute() {
		// TODO Auto-generated method stub
		test.setCancelable(true);
		test.setTitle("Import Complete");
		test.setMessage("Import Complete Press Back Key");
		done = true;
		
	}

	@Override
	  protected void onStart() {
	
	    super.onStart();
	  }

	  @Override
	  protected void onResume() {
	    
	    super.onResume();
	  }

	  @Override
	  protected void onPause() {
	 
	    super.onPause();
	  }

	  @Override
	  protected void onStop() {
	    
	    super.onStop();
	  }

	  @Override
	  protected void onDestroy() {
	  
	    super.onDestroy();
	  }

}
