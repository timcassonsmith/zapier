package co.uk.shieldstothemax.blastedneighbours;

import android.support.v4.app.Fragment;
import android.util.Log;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import android.widget.Toast;
import java.io.BufferedReader;
//import java.io.BufferedWriter;
import java.io.File;
//import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
//import java.io.FileWriter;
import java.io.IOException;







public class ImpExpFragment extends Fragment {
	 Integer callbackcounter = 0;
	static interface TaskCallbacks {
	    public void onPreExecute();
	    public void onProgressUpdate(int percent);
	    public void onCancelled();
	    public void onPostExecute();
	  }
	
	private TaskCallbacks mCallbacks;
	private boolean mRunning;
	private ImpTask mTask;
	
	@Override
	  public void onAttach(Activity activity) {
	  
	    super.onAttach(activity);
	    
	    
	    if (!(activity instanceof TaskCallbacks)) {
	      throw new IllegalStateException("Activity must implement the TaskCallbacks interface.");
	    }
	    mCallbacks = (TaskCallbacks) activity;
	}
	
	@Override
	  public void onCreate(Bundle savedInstanceState) {
	   
	    super.onCreate(savedInstanceState);
	    //Bundle getfile = new Bundle();
	    //getfile = getActivity().getIntent().getExtras();
	   // filenamestored = getArguments().getString("file");
	   // filenamestored += filenamestored+" Got the file now!";
	     setRetainInstance(true);
	  }
	
	@Override
	  public void onDestroy() {
	   // Log.i(TAG, "onDestroy()");
	    super.onDestroy();
	    cancel();
	  }
	
	
	
	
	public void start() {
	    if (!mRunning) {
	      mTask = new ImpTask();
	      mTask.execute();
	      mRunning = true;
	    }
	  }

	  /**
	   * Cancel the background task.
	   */
	  public void cancel() {
	    if (mRunning) {
	      mTask.cancel(false);
	      mTask = null;
	      mRunning = false;
	    }
	  }

	  /**
	   * Returns the current state of the background task.
	   */
	  public boolean isRunning() {
	    return mRunning;
	  }

	
	
	
	
	
	
	
	
	private class ImpTask extends AsyncTask<Void, Integer, Void> {

	    @Override
	    protected void onPreExecute() {
	      // Proxy the call to the Activity
	      mCallbacks.onPreExecute();
	      mRunning = true;
	    }

	    @Override
	    protected Void doInBackground(Void... ignore) {
	      for (int i = 0; !isCancelled() && i < 100; i++) {
	    	  callbackcounter++;
	        //Log.i(TAG, "publishProgress(" + i + "%)");
	        SystemClock.sleep(100);
	        publishProgress(callbackcounter);
	      }
	      return null;
	    }

	    @Override
	    protected void onProgressUpdate(Integer... percent) {
	      // Proxy the call to the Activity
	      mCallbacks.onProgressUpdate(percent[0]);
	      
	    }

	    @Override
	    protected void onCancelled() {
	      // Proxy the call to the Activity
	      mCallbacks.onCancelled();
	      mRunning = false;
	    }

	    @Override
	    protected void onPostExecute(Void ignore) {
	      // Proxy the call to the Activity
	    	 
	    	    
	    	    
	    	    
	      mCallbacks.onPostExecute();
	      mRunning = false;
	    }
	  }
	@Override
	  public void onActivityCreated(Bundle savedInstanceState) {
	 
	    super.onActivityCreated(savedInstanceState);
	  }

	  @Override
	  public void onStart() {
	  
	    super.onStart();
	  }

	  @Override
	  public void onResume() {
	
	    super.onResume();
	  }

	  @Override
	  public void onPause() {
	 
	    super.onPause();
	  }

	  @Override
	  public void onStop() {
	   
	    super.onStop();
	  }
	
}
