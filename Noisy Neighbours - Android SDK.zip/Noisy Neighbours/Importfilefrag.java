package co.uk.shieldstothemax.blastedneighbours;

import java.io.IOException;
import java.util.Arrays;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import android.database.Cursor;
import co.uk.shieldstothemax.blastedneighbours.Importfile;
public class Importfilefrag extends Fragment {
private DBAdapter fragdb;
private Cursor fragcursor;
public boolean importrunning;

	
	
	
	
	@Override
	  public void onAttach(Activity activity) {
	    super.onAttach(activity);
	   
	  }
	
	@Override
	  public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);

	    // Retain this fragment across configuration changes.
	    setRetainInstance(true);

	    // Create and execute the background task.
	   
	  }
	
	 @Override
	  public void onDetach() {
	    super.onDetach();
	    
	  }

	 
	 
////	 private class mDBProgressAsync extends AsyncTask<Void, Void, Void> {
////
////		@Override
////		protected Void doInBackground(Void... arg0) {
////			// TODO Auto-generated method stub
////			try {
////				importdata.begint();
////				while 	((readline = csvbuf.readLine()) != null && !mdbimport.isCancelled() ) {
////					
////					// read in the data and using the comma to split the fields up
////					 row = readline.split(",");
////					// read in the date and separate the values by the forward slash
////					 if (row.length==4) {
////						 imptype = Arrays.asList(importtypes).indexOf(row[0]);
////						 impnotes = row[1];
////				    	 impdate = row[2].split("/");
////				    	 imptime = row[3].split(":");						        
////				     } else {
////				    	 imptype = Arrays.asList(importtypes).indexOf(row[0]);
////				    	 for (Integer i=1; i<row.length;i++) {
////				    		 if (!row[i].contains("/") || !row[i].contains(":")) { 
////					    	       impnotes += row[i]; 
////					    	      } else if (row[i].contains("/") ) {
////					    	    	 impdate = row[i].split("/");
////					    	      } else if (row[i].contains(":")) {
////					    	    	 imptime = row[i].split(":");
////					    	      }
////				    	 }
////				     }
////				      day = Integer.valueOf(impdate[0].trim());
////					  month = Integer.valueOf(impdate[1].trim());
////					 year = Integer.valueOf(impdate[2].trim());
////					   hour = Integer.valueOf(imptime[0].trim());
////					 min = Integer.valueOf(imptime[1].trim());
////					  sec = Integer.valueOf(imptime[2].trim());
////					  impdatetime = Integer.toString(year)+impprefixzero(month)+impprefixzero(day)
////							 +impprefixzero(hour)+impprefixzero(min)+impprefixzero(sec);
////					  impsortdatetime = Long.valueOf(impdatetime);
////					 impdates = Integer.toString(year)+impprefixzero(month)+impprefixzero(day);
////					 impsortdate = Long.valueOf(impdates);
////					importdata.createLog(impnotes, impimgref+noisedrawableimp[imptype].toString(), imptype, hour, min, sec, day, month, year, impsortdatetime, impsortdate);
////				}
////			} catch (NumberFormatException e) {
////				// TODO Auto-generated catch block
////				e.printStackTrace();
////			} catch (IOException e) {
////				// TODO Auto-generated catch block
////				e.printStackTrace();
////			}
////		
////			importdata.settSuc();
////			importdata.endt();
////			return null;
////		} 
////		 
////		 
////		 
////	 }
//	        
	 
	 
}
