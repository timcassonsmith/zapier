package co.uk.shieldstothemax.blastedneighbours;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;

import android.os.AsyncTask;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Calendar;
import android.os.Bundle;
import android.os.Environment;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.app.ProgressDialog;
import android.content.IntentFilter;
import android.content.Intent;
import android.content.pm.ActivityInfo;

public class Exportfile extends ListActivity  {
	 private List<String> item = null;
	 private List<String> path = null;
	 private String root;
	 private mDBProgressAsync mdbprogress;
	 private TextView myPath;
	 Intent exportfilter;
	 Integer csvexport = 0;
	 DBAdapter MD;
	 Cursor exportrec;
	 String fulldate = ""; 
 	String fulltime = "";
	 AlertDialog Exportyes,Exportcontinue,Exportcompleted,Exportfolderaccess,Exportfiltered,Exportquit;
	  ProgressDialog exportprogress;
	 String dialogexportedinfo  = "";
 	 String dialogfullpathname ="";
	 String exportffd,exportftd;
	 String datefile= "";
	 String fullpathname ="";
	 String exportedinfo = "";
	 List<String> exporti = null;
	 String recinfo = "";
	 Integer exportf;
	 Integer progstart = 0;
	 Integer noiseid;
	 Button okay,cancel;
	 String filename = "nuisance_log_";
	 String csvheadings = "noise type,noise notes,noise date,noise time"+ "\n";
	 String ext = ".csv";
	 String getcurpath = "";
	 private exportbr myexportbr;
	 Boolean isexportrunning = false;
	 Boolean ishasexportfinished = false;
	 Boolean iswritelogdone = false;
	 Boolean isfiltered = false;
	 String[] exporttypes = {"Shouting", "Baby Gate Bounced", "Door Slammed",
	    		"DIY", "Hoovering", "TV Music Loud","Kids Running", "Other", 
	    		  "Loud Sound","Very Loud Sound","Extremely Loud Sound"};
	 
	 Integer daye=-1,monthe=-1,yeare=-1,houre=-1,mine=-1,sece=-1,noisetypee=-1,noisenotee=-1;
	 String expcomp = "";
     Integer resultok = -1;
	 @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.filee);
	        // Holds the textview path
	        myPath = (TextView)findViewById(R.id.path);
	        // OK button / Save Here Button
	        okay = (Button)findViewById(R.id.ok);
	        // Intent for retrieving if data was filtered
	        exportfilter = this.getIntent();
	        exportprogress = new ProgressDialog(Exportfile.this);
	        // Allows this dialog to be cancelled
	       
	        if (savedInstanceState != null) { 
	        	isexportrunning = savedInstanceState.getBoolean("EXPORTR");
	        	ishasexportfinished = savedInstanceState.getBoolean("EXPORTD");
	        	expcomp =  savedInstanceState.getString("EXPORTBRC");
	        	 resultok = savedInstanceState.getInt("EXPORTBRES");
	        	fullpathname = savedInstanceState.getString("PATH");
	        }
	        
//	        if (savedInstanceState != null) {
//	        	//iswritelogdone = savedInstanceState.getBoolean("DONELOG");
//	        	Boolean exportchk = savedInstanceState.getBoolean("EXPORTR");
//	        	isfiltered = savedInstanceState.getBoolean("FILTER");
//	        	Log.d("EXPCHK","Export Running ="+exportchk);
//	        	Boolean exportdone = savedInstanceState.getBoolean("EXPORTD");
//	        	Log.d("EXPCHK","Export Done ="+exportdone);
//	        	//List<String> exportir = savedInstanceState.getStringArrayList("DATA"); 	
//	        	//Log.d("EARRAY","Retained array size = "+exportir.size())
//	        	exportprogress = new ProgressDialog(Exportfile.this);
//	        	if (myexportbr == null && exportchk) {
//	            	Log.d("REGBR","Reached the re-register of the broadcast receiver");
//	                  myexportbr = new exportbr();
//					 IntentFilter intentFilter = new IntentFilter(ImpExpService.ACTION_MyIntentService);
//					  intentFilter.addCategory(Intent.CATEGORY_DEFAULT);
//					 registerReceiver(myexportbr, intentFilter);
//	            }
//	            
//	        	
//	        String fullpath = savedInstanceState.getString("PATH");
//	        	fullpathname = fullpath;
//	        //	Log.d("EPATH","Full path stored is = "+fullpath);
//	        //	Log.d("EPATH","Full path NAME stored is = "+fullpathname);
//	            if (!exportprogress.isShowing() && exportchk) {
//	            	 // Sets up Progress window when gathering data for export
//	    	        
//	            	isexportrunning = true;
//	            	
//	            	exportprogress.setCancelable(false);
//	            	exportprogress.setCanceledOnTouchOutside(false);
//	            	exportprogress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
//	            	exportprogress.setTitle("Export");
//	            	exportprogress.setMessage("Gathering Database Information (Config Change)...");
//	            	exportprogress.show();
//	            }
//	            
//	            
//	            if (exportdone) {
//	            	
//	            	ishasexportfinished = true;
//	             
//	            	 new AlertDialog.Builder(Exportfile.this)
//				     .setIcon(R.drawable.app_icon)
//				     .setTitle("Export Complete")
//				     .setMessage("Export has finished, filename and location are "+fullpath+
//						        " .Returning to main application screen")
//				     .setPositiveButton("OK", new DialogInterface.OnClickListener() {
//
//							@Override
//							public void onClick(DialogInterface arg0, int arg1) {
//								// TODO Auto-generated method stub
//								isexportrunning = false;
//								ishasexportfinished = false;
//								finish();
//								
//								
//							}})
//					     
//					     
//					     
//					     .show(); 
//	            
//	           
//	          }
//	        }
	        
	        exportf = exportfilter.getIntExtra("filtered", 0);
	        if (exportf == 3 && !isfiltered) {
	           Exportfiltered =	new AlertDialog.Builder(Exportfile.this)
		   	     .setIcon(R.drawable.exportcsv)
		   	     .setTitle("Database Currently Filtered")
		   	     .setMessage("Do you want to export filtered records or all records?")
		   	     .setPositiveButton("Filtered", new android.content.DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						exportffd = exportfilter.getStringExtra("fromd");
			        	exportftd = exportfilter.getStringExtra("tod");
			        	isfiltered = true;
					    arg0.cancel();
						//writelog(dialogexportedinfo,dialogfullpathname);
						
		        	 //   Toast.makeText(Exportfile.this, "Info Exported: "+"\n"+dialogexportedinfo, Toast.LENGTH_LONG).show();
					//	csvexport = 1;
					}})
					
					.setNegativeButton("All", new android.content.DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog,
								int which) {
							// TODO Auto-generated method stub
						//	csvexport = 0;
							exportffd ="";
							exportftd = "";
						     dialog.cancel();	
						}})
					.show();
	        	
	        }
	        
	        
	        
	        okay.setOnClickListener( new OnClickListener () {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					//** NEW CODE FOR RUNNING INTENTSERVICE **
					Calendar filedate = Calendar.getInstance();
				    datefile = Integer.toString(filedate.get(Calendar.DAY_OF_MONTH))+Integer.toString(filedate.get(Calendar.MONTH)+1)+
						    Integer.toString(filedate.get(Calendar.YEAR))+Integer.toString(filedate.get(Calendar.HOUR))+
						    Integer.toString(filedate.get(Calendar.MINUTE))+Integer.toString(filedate.get(Calendar.SECOND));
				  fullpathname = getcurpath+"/"+filename+datefile+ext;
				  Log.d("FILE", "FULL PATH NAME AT THE START = "+fullpathname);
					  Intent intentMyIntentService = new Intent(Exportfile.this,Exportservice.class);
					  //intentMyIntentService.putExtra("IMPEXP",2);
					  intentMyIntentService.putExtra("FROMDATE", exportffd);
					  intentMyIntentService.putExtra("TODATE", exportftd);
					  intentMyIntentService.putExtra("FILEE", fullpathname);
					  startService(intentMyIntentService);
					Log.d("SERVICE", "Started Service");
					  myexportbr = new exportbr();
					  IntentFilter intentFilter = new IntentFilter(Exportservice.ACTION_ServiceE);
					  intentFilter.addCategory(Intent.CATEGORY_DEFAULT);
					  registerReceiver(myexportbr, intentFilter);
					  Log.d("BRECIVER", "Started Receiver");
					  // Sets up Progress window when gathering data for export
				      //  exportprogress = new ProgressDialog(Exportfile.this);
					  isexportrunning = true;
					  exportprogress.setCancelable(false);
				        exportprogress.setTitle("Export");
				        // Sets the dialog to a spinning style
				        exportprogress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
				        // Sets the message for the end user to see
				        exportprogress.setMessage("Gathering Database Information...");
				        // gets the value from the Intent to see if the data is filtered
					  exportprogress.show();
					  
					  Log.d("FILE", "FULL PATH NAME NOW SERVICE IS RUNNING = "+fullpathname);
					
					
					
					//Exportfile.this.setRequestedOrientation(Exportfile.this.getResources().getConfiguration().orientation);
                   
                     
                     
					
				//	fullpathname = getcurpath+"/"+filename+datefile+ext;
					
					//exporti = new ArrayList<String>();
					//Toast.makeText(Exportfile.this, "Location and filename is :"+fullpathname, Toast.LENGTH_LONG).show();
					
				//	MD = new DBAdapter(v.getContext());
				//	MD = MD.open();
//					if (exportffd!=null && exportftd!=null) {
//			        exportrec = MD.gdf(Integer.valueOf(exportffd), Integer.valueOf(exportftd));
//			        
//					} else {
//						exportrec = MD.GetAllLogs(2, "noise_date_sort");
//					}
//					
			//        if (exportrec.getCount()>0) {
//			        	exportrec.moveToFirst();
//			        	daye = exportrec.getColumnIndex("noise_day");		
//			        	monthe = exportrec.getColumnIndex("noise_month");
//			        	yeare = exportrec.getColumnIndex("noise_year");
//			        	houre = exportrec.getColumnIndex("noise_hour");
//			        	mine = exportrec.getColumnIndex("noise_min");
//			        	sece = exportrec.getColumnIndex("noise_second");
//			        	noisetypee = exportrec.getColumnIndex("noise_type_id");
//			        	noisenotee = exportrec.getColumnIndex("noise_info");
//			        	
//			        	
//			        	noiseid = exportrec.getInt(noisetypee);
//			        	exporti.add(csvheadings);
//			        	recinfo = String.format("%s,%s,%02d/%02d/%04d,%02d:%02d:%02d", exporttypes[noiseid],
//			        			  exportrec.getString(noisenotee),exportrec.getInt(daye),exportrec.getInt(monthe)
//			        			  ,exportrec.getInt(yeare),exportrec.getInt(houre),exportrec.getInt(mine),exportrec.getInt(sece));
//			        	exporti.add(recinfo+"\n");
//			        	
//			        	exportedinfo = csvheadings;
//			    		exportedinfo += exporttypes[noiseid] +","+exportrec.getString(noisenotee)+","+
//			    				fulldate+","+fulltime + " \n" ; 
//			        	mdbprogress = new mDBProgressAsync();
//			        
//	                     
//	                     mdbprogress.execute();
//			        	exportrec.moveToFirst();
//			        	String fulldate = ""; 
//			        	String fulltime = "";		
//			        	fulldate =	exportnumberformatter(exportrec.getInt(exportrec.getColumnIndex("noise_day")))
//			        			+"/"+exportnumberformatter(exportrec.getInt(exportrec.getColumnIndex("noise_month")))+"/"
//			        			+String.valueOf(exportrec.getInt(exportrec.getColumnIndex("noise_year")));
//			        	
//			        	fulltime = exportnumberformatter(exportrec.getInt(exportrec.getColumnIndex("noise_hour")))+":"
//			        			+exportnumberformatter(exportrec.getInt(exportrec.getColumnIndex("noise_min")))+":"
//			        			+exportnumberformatter(exportrec.getInt(exportrec.getColumnIndex("noise_second")));
//			        	noiseid = exportrec.getInt(exportrec.getColumnIndex("noise_type_id"));
//			        	exportedinfo = csvheadings;
//		        		exportedinfo += exporttypes[noiseid] +","+exportrec.getString(exportrec.getColumnIndex("noise_info"))+","+
//		        				fulldate+","+fulltime + " \n" ; 
//			        	while (!exportrec.isLast()) {
//			        		if ( exportrec.moveToNext() ) {
//			        		fulldate =	exportnumberformatter(exportrec.getInt(exportrec.getColumnIndex("noise_day")))
//				        			+"/"+exportnumberformatter(exportrec.getInt(exportrec.getColumnIndex("noise_month")))+"/"
//				        			+String.valueOf(exportrec.getInt(exportrec.getColumnIndex("noise_year")));
//			        		
//				        	fulltime =  exportnumberformatter(exportrec.getInt(exportrec.getColumnIndex("noise_hour")))+":"
//				        			+exportnumberformatter(exportrec.getInt(exportrec.getColumnIndex("noise_min")))+":"
//				        			+exportnumberformatter(exportrec.getInt(exportrec.getColumnIndex("noise_second")));
//				        	
//			        		noiseid = exportrec.getInt(exportrec.getColumnIndex("noise_type_id"));
//			        		exportedinfo += exporttypes[noiseid] +","+exportrec.getString(exportrec.getColumnIndex("noise_info"))+","+
//			        				fulldate+","+fulltime+" \n" ;  
//			        		}
//			        	} 
			        	//AlertDialog.Builder csvyesno = new AlertDialog.Builder(Exportfile.this);
			        	//csvyesno.set
//			        	
//			        	dialogexportedinfo  = exportedinfo;
//			            dialogfullpathname = fullpathname;
//			        	Exportcontinue = new AlertDialog.Builder(Exportfile.this)
//			   	     .setIcon(R.drawable.exportcsv)
//			   	     .setTitle("Export Data")
//			   	     .setMessage("Do you wish to continue with the export?")
//			   	     .setPositiveButton("Yes", new android.content.DialogInterface.OnClickListener() {
//
//						@Override
//						public void onClick(DialogInterface arg0, int arg1) {
//							// TODO Auto-generated method stub
//							//Toast.makeText(Export, "Database information Stored" , Toast.LENGTH_LONG).show();
//							if (writelog(dialogexportedinfo,dialogfullpathname)) {
//								Exportcompleted = new AlertDialog.Builder(Exportfile.this)
//						   	     .setIcon(R.drawable.exportcsv)
//						   	     .setTitle("Exported Completed")
//						   	     .setMessage("Filename and location :"+"\n"+dialogfullpathname+"\n"+"Do you want to return to the main program?")
//						   	     .setPositiveButton("Yes", new android.content.DialogInterface.OnClickListener() {
//
//									@Override
//									public void onClick(DialogInterface arg0, int arg1) {
//										// TODO Auto-generated method stub
//										arg0.dismiss();
//										finish();
//									}})
//									
//									.setNegativeButton("No", new android.content.DialogInterface.OnClickListener() {
//
//										@Override
//										public void onClick(DialogInterface dialog,
//												int which) {
//											// TODO Auto-generated method stub
//											
//										     dialog.cancel();	
//										}})
//									.show();
//							}
//							
//			        	 //   Toast.makeText(Exportfile.this, "Info Exported: "+"\n"+dialogexportedinfo, Toast.LENGTH_LONG).show();
//						//	csvexport = 1;
//						}})
//						
//						.setNegativeButton("No", new android.content.DialogInterface.OnClickListener() {
//
//							@Override
//							public void onClick(DialogInterface dialog,
//									int which) {
//								// TODO Auto-generated method stub
//							//	csvexport = 0;
//							     dialog.cancel();	
//							}})
//						.show();
			   	     
//			   	      if (csvexport ==1) {
//			            	writelog(exportedinfo,fullpathname);
//			        	    Toast.makeText(Exportfile.this, "Info Exported: "+"\n"+exportedinfo, Toast.LENGTH_LONG).show();
//			        	    csvexport = 0;
//			        	}
			      //  } 
			        
			        //else {
//			        	Toast.makeText(Exportfile.this.getApplicationContext(), "No Records to export!!!", Toast.LENGTH_LONG).show();
//			        }
					//MD.close();
					//exportrec.close();
					
				}});
	        
	        cancel = (Button)findViewById(R.id.cancel);
	        
	        cancel.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
				Exportquit = new AlertDialog.Builder(Exportfile.this)
			   	     .setIcon(R.drawable.quitapp)
			   	     .setTitle("Do you wish to quit?")
			   	     .setPositiveButton("Yes", new android.content.DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface arg0, int arg1) {
							// TODO Auto-generated method stub
							finish();
						}})
						
						.setNegativeButton("No", new android.content.DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								// TODO Auto-generated method stub
								
							     dialog.cancel();	
							}})
						.show();
			   	     
					
					
				}}); 
	        root = Environment.getExternalStorageDirectory().getPath();
	        
	        getDir(root);
	    }
	   
	 
	 // This is the getDir method which gets the list of folders for the export class
	    private void getDir(String dirPath)
	    {
	     myPath.setText("Current Folder: " + dirPath);
	     getcurpath = dirPath;
	     item = new ArrayList<String>();
	     path = new ArrayList<String>();
	     File f = new File(dirPath);
	     FileFilter ff = new FileFilter() {

			@Override
			public boolean accept(File arg0) {
				// TODO Auto-generated method stub
				return arg0.isDirectory();
				
				
				
			}
		};
	     File[] files = f.listFiles(ff);
	     
//	     List<String> sortorder = new ArrayList<String>();
//	     for(int i=0; i < files.length; i++)
//	     {
//	      File file = files[i];
//	      
//	      if(!file.isHidden() && file.canRead()){
//	     
//	          if(file.isDirectory()){
//	        	sortorder.add(file.getPath());
//	            //item.add(file.getName() + "/");
//	          } 
//	      } 
//	     }
	     if(!dirPath.equals(root))
	     {
	      item.add(root);
	      path.add(root);
	      item.add("../");
	      path.add(f.getParent()); 
	     }
	   Arrays.sort(files, dirsort);
	 //   Collections.sort(sortorder, String.CASE_INSENSITIVE_ORDER);
	     for(int i=0; i < files.length; i++)
	     {
	      File file = files[i];
	   //   path.add(sortorder.get(i).toString());
	     // item.add(sortorder.get(i).toString()+ "/");
	      if(!file.isHidden() && file.canRead()){
	     
	          if(file.isDirectory()){
	        	path.add(file.getPath());
	            item.add(file.getName() + "/");
	          } 
	      } 
	     }
         // Collections.sort(item, String.CASE_INSENSITIVE_ORDER);
          //Collections.sort(path, String.CASE_INSENSITIVE_ORDER);
	     ArrayAdapter<String> fileList =
	       new ArrayAdapter<String>(this, R.layout.row, item);
	     setListAdapter(fileList); 
	    }
// This method is used to sort the list of folders from getDir
	    Comparator<? super File> dirsort = new Comparator<File>() {

            @Override
			public int compare(File arg0, File arg1) {
				// TODO Auto-generated method stub
				if (arg0.isDirectory()) {
					if (arg1.isDirectory()) {
						return String.valueOf(arg0.getName().toLowerCase()).compareTo(arg1.getName().toLowerCase());
					} else {
						return -1;
					}
				} else {
					if (arg1.isDirectory()) {
						return 1;
					} else {
						return String.valueOf(arg0.getName().toLowerCase()).compareTo(arg1.getName().toLowerCase());
					}
				}
			
			}
	    	
	    	
	    }; 
 	    
	    
	    // This is used inconjunction wih the listview activity which checks to see if the folder can be accessed
	 @Override
	 protected void onListItemClick(ListView l, View v, int position, long id) {
	  // TODO Auto-generated method stub
	  File file = new File(path.get(position));
//	  new AlertDialog.Builder(Exportfile.this)
//	     .setIcon(R.drawable.quitapp)
//	     .setTitle(file.getName() + "has been clicked !, absolute path="+file.getAbsolutePath())
//	     .setPositiveButton("OK", null).show(); 
	  
	//  Toast.makeText(Exportfile.this, "Position clicked:"+Integer.toString(position)+"\n"+"Details are ", Toast.LENGTH_LONG).show();
	  //Toast.makeText(Exportfile.this, "Position clicked:"+Integer.toString(position), Toast.LENGTH_LONG).show();
	  if (file.isDirectory())
	  {
		 // Toast.makeText(Exportfile.this, "Position clicked:"+Integer.toString(position)+" Is a directory!", Toast.LENGTH_LONG).show();
	   if(file.canRead()){
		   //Toast.makeText(Exportfile.this, "Position clicked:"+Integer.toString(position)+" Can be read!", Toast.LENGTH_LONG).show();
	    getDir(path.get(position));
	   }else{
	   new AlertDialog.Builder(Exportfile.this)
	     .setIcon(R.drawable.quitapp)
	     .setTitle("[" + file.getName() + "] Cannot be accessed! Please try another folder")
	     .setPositiveButton("OK", null).show(); 
	   } 
	  }	 
	 }
	 
	 
	 // used to write the export csv file to the storage device within the folder selected ..
	 // This also error checks to see if the file can be written to the given area
	 public boolean writelog(List<String> logfile,String logfilename) {
		 if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
			 File file = new File(logfilename);
			 if (!file.exists()) {
				 try
				 {
					file.createNewFile(); 
					
				 } catch (IOException error) {
					 error.printStackTrace();
					 Toast.makeText(this, "Error Writing file:" + file.getName(), Toast.LENGTH_LONG).show();
					 return false;
				 }
			 }
			 try {
				BufferedWriter buflog = new BufferedWriter(new FileWriter(file,false));
				  if (logfile.size()>0) {
		            for (int data=0;data<=logfile.size()-1;data++) {
		            	buflog.write(logfile.get(data));
		            }
				  }
				buflog.close();
				
			 } catch (IOException error) {
				 error.printStackTrace();
				 Toast.makeText(this, "Error Creating file.", Toast.LENGTH_LONG).show();
				 return false;
			 }
		 } else {
			 Toast.makeText(this, "Cannot write to this folder", Toast.LENGTH_LONG).show();
			 return false;
		 }
		 return true;
	 }
	 
	 
	 // used in conjunction with the intent service to determine when the intent service has finished
	 
	 public class exportbr extends BroadcastReceiver {
		// public static final String ACTION_RESP = "co.uk.shieldstothemax.RESPONSEEXPORT";
		 
		@Override
		public void onReceive(Context arg0, Intent arg1) {
			// TODO Auto-generated method stub
			Log.d("BRECIVER", "Reached Receiver");
		//	if (arg1.getAction() == Exportservice.ACTION_ServiceE) {
			Log.d("BRECIVER", "Reached Receiver action");
			Bundle bundle = arg1.getExtras();
			if (bundle != null ) {
				Log.d("BUNDLE", "There is something back from the service!");
				 expcomp = bundle.getString("FINISH");
				 resultok = bundle.getInt("RESULT");
				isexportrunning = false;
				ishasexportfinished = true;
				if (exportprogress.isShowing()) {
				   exportprogress.dismiss();
				}
			}
			
			
		
			
			
			//Log.d("EXPORT","Records exported are "+Integer.toString(exporti.size()));
			if (expcomp.equals("DONE") && resultok==1) {
				if (exportprogress.isShowing()) {
					   exportprogress.dismiss();
					}
				//exporti = new ArrayList<String>();
				//exporti = arg1.getStringArrayListExtra("LIST");
				dialogfullpathname = fullpathname;
		//		if (writelog(exporti,dialogfullpathname)) {
			//		iswritelogdone = true;
				
				Exportcompleted =   new AlertDialog.Builder(Exportfile.this)
				     .setIcon(R.drawable.app_icon)
				     .setTitle("Export Complete")
				     .setMessage("Export has finished, filename and location are "+dialogfullpathname+
				        " .Returning to main application screen")
				     .setPositiveButton("OK", new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface arg0, int arg1) {
							// TODO Auto-generated method stub
							isexportrunning = false;
							ishasexportfinished = false;
							finish();
							
							
						}})
				     
				     
				     
				     .show(); 
					   
				   
		} else {
			Exportcompleted =   new AlertDialog.Builder(Exportfile.this)
			     .setIcon(R.drawable.quitapp)
				     .setTitle("OOPS")
				     .setMessage("Something has gone horribly wrong :(")
				     .setPositiveButton("OK", null).show();
				   isexportrunning = false;
			
		}
		} 
		 
		//}
	 }
	 
	
	 
	 
	 @Override 
	 protected void onResume() {
		 super.onResume();
		 if (myexportbr == null && isexportrunning) {
			 
		 myexportbr = new exportbr();
		 IntentFilter intentFilter = new IntentFilter(Exportservice.ACTION_ServiceE);
		  intentFilter.addCategory(Intent.CATEGORY_DEFAULT);
		  registerReceiver(myexportbr, intentFilter);
		 Log.d("REGBR","Reached the re-register of the broadcast receiver");
		 }
		 if (!exportprogress.isShowing() && isexportrunning) {
//         	 // Sets up Progress window when gathering data for export
// 	        
//         	isexportrunning = true;
//         //	ishasexportfinished = false;
        	exportprogress.setCancelable(false);
        	exportprogress.setCanceledOnTouchOutside(false);
        	exportprogress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        	exportprogress.setTitle("Export");
         	exportprogress.setMessage("Gathering Database Information (Config Change)...");
         	exportprogress.show();
        }
		 
		 if (ishasexportfinished) {
			 Exportcompleted = new AlertDialog.Builder(Exportfile.this)
		     .setIcon(R.drawable.app_icon)
		     .setTitle("Export Complete")
		     .setMessage("Export has finished, filename and location are "+fullpathname+
				        " .Returning to main application screen")
		     .setPositiveButton("OK", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						isexportrunning = false;
						ishasexportfinished = false;
						finish();
						
						
					}})

				
			     .show(); 
		 }
		 
	 }
	 
	 @Override
	 protected void onPause() {
		 super.onPause();
		 if (exportprogress.isShowing()) {
			 exportprogress.dismiss();
		 }
		if (myexportbr != null) {
			  unregisterReceiver(myexportbr); 
	}
		 if (Exportcompleted != null) {
			 if (Exportcompleted.isShowing()) {
			 Exportcompleted.dismiss();
			 }
		 }
		 
	 }
	 
	 @Override
	 protected void onDestroy() {
	  super.onDestroy();
	 
	  //un-register BroadcastReceiver
	  
	 }
	 
	 
	// @Override
	// public void onRestoreInstanceState (Bundle savedInstanceState) {
	//	 super.onRestoreInstanceState(savedInstanceState);
		//iswritelogdone = savedInstanceState.getBoolean("DONELOG");
     	//Boolean exportchk = savedInstanceState.getBoolean("EXPORTR");
     	//isfiltered = savedInstanceState.getBoolean("FILTER");
     	//Log.d("EXPCHK","Export Running ="+exportchk);
     	//Boolean exportdone = savedInstanceState.getBoolean("EXPORTD");
     	//Log.d("EXPCHK","Export Done ="+exportdone);
     	//List<String> exportir = savedInstanceState.getStringArrayList("DATA"); 	
     	//Log.d("EARRAY","Retained array size = "+exportir.size())
     	
     	//if (myexportbr == null ) {
     ////     	Log.d("REGBR","Reached the re-register of the broadcast receiver");
      //////          myexportbr = new exportbr();
 		////		 IntentFilter intentFilter = new IntentFilter(Exportservice.ACTION_MyIntentServiceE);
 		///		 registerReceiver(myexportbr, intentFilter);
      ///    } 
         
     	
//     String fullpath = savedInstanceState.getString("PATH");
//     	fullpathname = fullpath;
//     //	Log.d("EPATH","Full path stored is = "+fullpath);
//     //	Log.d("EPATH","Full path NAME stored is = "+fullpathname);
//         if (!exportprogress.isShowing() && exportchk) {
//         	 // Sets up Progress window when gathering data for export
// 	        
//         	isexportrunning = true;
//         //	ishasexportfinished = false;
//         	exportprogress.setCancelable(false);
//         	exportprogress.setCanceledOnTouchOutside(false);
//         	exportprogress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
//         	exportprogress.setTitle("Export");
//         	exportprogress.setMessage("Gathering Database Information (Config Change)...");
//         	exportprogress.show();
//         }
//         
//         if (myexportbr == null && exportchk) {
//          	Log.d("REGBR","Reached the re-register of the broadcast receiver");
//                myexportbr = new exportbr();
// 				 IntentFilter intentFilter = new IntentFilter(Exportservice.ACTION_MyIntentServiceE);
// 				  intentFilter.addCategory(Intent.CATEGORY_DEFAULT);
// 				 registerReceiver(myexportbr, intentFilter);
//          } 
//         
//         if (exportdone) {
//        //	 isexportrunning = false;
//         	ishasexportfinished = true;
//          
//         	 new AlertDialog.Builder(Exportfile.this)
//			     .setIcon(R.drawable.app_icon)
//			     .setTitle("Export Complete")
//			     .setMessage("Export has finished, filename and location are "+fullpath+
//					        " .Returning to main application screen")
//			     .setPositiveButton("OK", new DialogInterface.OnClickListener() {
//
//						@Override
//						public void onClick(DialogInterface arg0, int arg1) {
//							// TODO Auto-generated method stub
//							isexportrunning = false;
//							ishasexportfinished = false;
//							finish();
//							
//							
//						}})
//				     
//				     
//				     
//				     .show(); 
//         
//        
//       }
	// }
	 
	 @Override
	 public void onSaveInstanceState(Bundle saved) { 
	
		       if (expcomp.length()>0) {
		    	   Log.d("SAVE_EXPCOMP","export broadcaster complete flag = "+expcomp);
				   saved.putString("EXPORTBRC", expcomp);
		       } else {
		    	   Log.d("SAVE_EXPCOMP","export broadcaster NOT complete flag ");
				   saved.putString("EXPORTBRC", expcomp);
		       }
		       
		       if (resultok==1) {
		    	   Log.d("SAVE_EXPRESULT","export broadcaster Result flag = "+resultok);
		    	   saved.putInt("EXPORTBRES", resultok);
		       } else {
		    	   Log.d("SAVE_EXPRESULT","export broadcaster Result flag = -1 ");
		    	   saved.putInt("EXPORTBRES", -1);
		       }
		 
		       if (isexportrunning) {
			   Log.d("SAVE_EXPO","export running "+isexportrunning);
			   saved.putBoolean("EXPORTR", isexportrunning);
		       } else {
		    	   Log.d("SAVE_EXPOE","export running is false");
				   saved.putBoolean("EXPORTR", false);
		       }
		   
		       if (ishasexportfinished) {
			   Log.d("SAVE_EXPF","export finished "+ishasexportfinished);
			   saved.putBoolean("EXPORTD", ishasexportfinished);
		       } else {
		    	   Log.d("SAVE_EXPFE","export finished false");
				   saved.putBoolean("EXPORTD", false);
		       }
		
		  
			   Log.d("SAVE_FIL","Filtered "+isfiltered);
			   saved.putBoolean("FILTER", isfiltered);
		   
		   
//		   if (iswritelogdone) {
//			   saved.putBoolean("DONELOG", iswritelogdone);
//		   }
		   
//		   if (exporti !=null) {
//	  Log.d("SAVEDI","export data count=");
//			   saved.putStringArrayList("DATA",  (ArrayList<String>) exporti);
//		   }
//		   
	   if (fullpathname.length()>0) {
			   saved.putString("PATH", fullpathname);
		   Log.d("SAVEDP","File name and location = "+fullpathname);
	   }
	   super.onSaveInstanceState(saved);
		  
	 }
	 
	 
	 
	// **********************************************************
		 // Possibly redundant method now .............
		 // *********************************************************
		
	 public String exportnumberformatter(int i) {
			String result = Integer.toString(i);
		  //  Log.d("PREFIX", "result starts with this = "+result);
		    if (result.length() >1 ) {
		  	//  Log.d("PREFIX", "NO ZEROES HERE");
		  	 return Integer.toString(i);
		  	 }
		   	 
		   String zeroprefix = "";
		   zeroprefix = "0"+result;
		   //Log.d("PREFIX", zeroprefix);
		   
		      return zeroprefix ;
		}
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	// **********************************************************
	 // Possibly redundant method now .............
	 // *********************************************************
	 
	 private class mDBProgressAsync extends AsyncTask<Void, Integer, Void> {

		@Override
		protected Void doInBackground(Void... arg0) {
			// TODO Auto-generated method stub
        	
        	
        	while (!exportrec.isAfterLast()) {
        		if ( exportrec.moveToNext() ) {
        			recinfo = String.format("%s,%s,%02d/%02d/%04d,%02d:%02d:%02d",exporttypes[noiseid],exportrec.getString(noisenotee),exportrec.getInt(daye),exportrec.getInt(monthe)
		        			  ,exportrec.getInt(yeare),exportrec.getInt(houre),exportrec.getInt(mine),exportrec.getInt(sece));
		        	exporti.add(recinfo+"\n");
//		        	
//        		fulldate =	exportnumberformatter(exportrec.getInt(daye))
//	        			+"/"+exportnumberformatter(exportrec.getInt(monthe))+"/"
//	        			+String.valueOf(exportrec.getInt(yeare));
//        		
//	        	fulltime =  exportnumberformatter(exportrec.getInt(houre))+":"
//	        			+exportnumberformatter(exportrec.getInt(mine))+":"
//	        			+exportnumberformatter(exportrec.getInt(sece));
//	        	
//        		noiseid = exportrec.getInt(noisetypee);
//        		exportedinfo += exporttypes[noiseid] +","+exportrec.getString(noisenotee)+","+
//        				fulldate+","+fulltime+" \n" ;  
        		}
        	} 
        	
        	
       
        	
			return null;
		}
		
		
		
		@Override
		protected void onPreExecute() {
				super.onPreExecute();
				progstart = 1;
				exportprogress.show();
				
		}
		
		 @Override
	        protected void onPostExecute(Void result) {
	            super.onPostExecute(result);
	            exportrec.close();
	            MD.close();
	            progstart = 0;
	            exportprogress.dismiss();
//	            for (int data=0;data<=exporti.size();data++) {
//	            	dialogexportedinfo += exporti.get(data);
//	            }
	            //dialogexportedinfo  = exportedinfo;
	        //    dialogexportedinfo = exporti.get(1);
	            dialogfullpathname = fullpathname;
	        	Exportcontinue = new AlertDialog.Builder(Exportfile.this)
	   	     .setIcon(R.drawable.exportcsv)
	   	     .setTitle("Export Data")
	   	     .setMessage("Do you wish to continue with the export?")
	   	     .setPositiveButton("Yes", new android.content.DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					// TODO Auto-generated method stub
					//Toast.makeText(Export, "Database information Stored" , Toast.LENGTH_LONG).show();
					if (writelog(exporti,dialogfullpathname)) {
						Exportcompleted = new AlertDialog.Builder(Exportfile.this)
				   	     .setIcon(R.drawable.exportcsv)
				   	     .setTitle("Exported Completed")
				   	     .setMessage("Filename and location :"+"\n"+dialogfullpathname+"\n"+"Do you want to return to the main program?")
				   	     .setPositiveButton("Yes", new android.content.DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface arg0, int arg1) {
								// TODO Auto-generated method stub
								arg0.dismiss();
								finish();
							}})
							
							.setNegativeButton("No", new android.content.DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub
									Exportfile.this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
								     dialog.cancel();	
								}})
							.show();
					}
					
	        	 //   Toast.makeText(Exportfile.this, "Info Exported: "+"\n"+dialogexportedinfo, Toast.LENGTH_LONG).show();
				//	csvexport = 1;
				}})
				
				.setNegativeButton("No", new android.content.DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog,
							int which) {
						// TODO Auto-generated method stub
					//	csvexport = 0;
					     dialog.cancel();
					     Exportfile.this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
					}})
				.show();
	        	//Exportfile.this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
	        }
	 }
	 
//	 @Override
//	 public void onResume() {
//		 super.onResume();
//		 if (progstart ==1 && mdbprogress.isCancelled()) {
//			 new AlertDialog.Builder(Exportfile.this)
// 	          .setIcon(R.drawable.exportcsv)
//  		      .setTitle("Export Cancelled")
//  		     .setMessage("The Export has been cancelled ")
//		     .setPositiveButton("OK", null).show();
//		 } 
//	 } 
//
//	
	
	
	
}
