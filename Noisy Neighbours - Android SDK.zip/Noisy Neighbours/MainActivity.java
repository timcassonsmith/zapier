package co.uk.shieldstothemax.blastedneighbours;



import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
//import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.annotation.TargetApi;
import android.app.ActionBar;
/*import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.EditText;
import android.widget.TextView;
*/import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.widget.DatePicker;
import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PaintDrawable;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.ArrayAdapter;
import android.widget.SimpleCursorAdapter.ViewBinder;
import android.widget.TableRow;
import android.widget.Toast;
import android.widget.TextView;
import android.app.AlertDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.DialogInterface;
import android.content.Context;
import android.content.res.Resources;
import android.widget.TableLayout;


public class MainActivity extends ListActivity  {
	private DBAdapter mDBHelper;
	private Cursor mC;
	static class ViewHolder {
	     public TextView noisetype;
	     public TextView noisedesc;
	     public ImageView iconnoise;
	     public TextView seper;
	     public TextView dayfield;
	     public TextView monthfield;
	     public TextView yearfield;
	     public TextView hourfield;
	     public TextView minfield ;
	     public TextView secfield;
	    public TableLayout tb1 ;
		public	TableLayout tb2 ;
		public	TableLayout tb3 ;
			
		public TableRow tbr1;
		public	TableRow tbr2;
		public	TableRow tbr3;
			
		public	LinearLayout ll;
	     
	     
	}
	TableLayout tb1;
	Integer rowchecked = -1;
	private static final int REQUEST_ADD = 1;
    private static final int REQUEST_EDIT = 2;
    Integer[] vnoiserefer = {R.drawable.shouticon48,R.drawable.babygate,R.drawable.dooricon48,
	           R.drawable.hammer,R.drawable.vac,R.drawable.tv,R.drawable.kid,R.drawable.bungeespydaquestion,
	             R.drawable.loud_speaker,R.drawable.very_loud_speaker,R.drawable.extremly_loud_speaker,R.drawable.app_icon };
	
	  String[] vnoiseimage = {"Shouting", "Baby Gate Bounced", "Door Slammed",
	    		"DIY", "Hoovering / Vacuuming ", "TV Music Loud","Childrens Noise", "Other Problems", 
	    		  "Loud Sound","Very Loud Sound","Extremely Loud Sound","Ridiculously Loud Sound"};
	  String[] monthsofyear = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
	  // problem with fields date and time are not being accepted by appending them with delemiters 
	  String[] fields = new String[] {DBAdapter.COL_NOISE_TYPE,DBAdapter.COL_NOISE_IMAGE,DBAdapter.COL_NOISE_INFO, DBAdapter.COL_NOISE_DAY,DBAdapter.COL_NOISE_MON,DBAdapter.COL_NOISE_YEAR,DBAdapter.COL_NOISE_HOUR,DBAdapter.COL_NOISE_MIN,DBAdapter.COL_NOISE_SEC,DBAdapter.COL_NOISE_DAY};
	  int[] viewfields = new int[] {R.id.noise_image_type,R.id.noise_type_view,R.id.noise_info_view ,R.id.noise_date_day_view,R.id.noise_date_month_view,R.id.noise_date_year_view,R.id.noise_time_hour_view,R.id.noise_time_min_view,R.id.noise_time_sec_view,R.id.seper};
  //  String[] noiseimage = {"Shouting", "Baby Gate Bounced", "Door Slammed",
    	//	"DIY", "Hoovering", "TV Music Loud", "Other"};
    
   // Integer[] noiserefer = {R.drawable.shouticon48,R.drawable.dooricon48,R.drawable.dooricon48,
     //      R.drawable.loudicon48,R.drawable.vac,R.drawable.tv,R.drawable.loudicon48 };
    // default sort DESC
	 Integer snotesflag = -1;
    Integer sorttype = 1;
    //EditText Enotes,Ehour,Emin,Esec,Eday,Emonth,Eyear;
    ImageView imgpic;
    TextView sep,datefrom,dateto,guidetxt,abouttxt;
    String noise_sort_field = "noise_date";
    DatePickerDialog fromd = null;
    DatePickerDialog tod = null;
    Integer filteryear,filterday,filtermonth,filterflag,fromfilterday,fromfiltermonth,fromfilteryear,filtered;
    Integer tofilterday,tofiltermonth,tofilteryear;
    String fromdatefilter = "";
    String todatefilter = "";
    Long fromdatef = Long.valueOf("20000101");
    Long todatef = Long.valueOf("20130228");
    Button cancelguide;
    Dialog guided;
    String guidestr = "";
    Integer listcurpost = -1;
    SimpleCursorAdapter adapter;
    Long rowid=null; 
    Integer longrowclick =-1;
    Integer longrowclick1 = -1;
    Integer prevlongclick = -1;
    Boolean islongclick = false; 
    Boolean islongclickbefore = false;
    Boolean islongclicked = false;
    Boolean isclick = false;
    Boolean guideon = false;
    Integer blackcolor = -16777216;
    Integer bluecolor = -12042869;
    Integer refreshc = -1;
    Integer colorcounter = -1;
    Integer posdeledit = -1;
    Long ideledit=12345678910L;
    Boolean issinglerecdel = false,isallrecdel = false,isnorecexp = false,isaddnewrec = false,isnorecfilter = false,isnofilterrecfound=false;
    mainlistadapter myadapter;
	View myviewp = null;
	AlertDialog alldialogs;
	AlertDialog singelrecdel,delallrec,norecexport,addnewrec,norecfilter,nofilterrecfound;
	mainlistadapter getmainlistadapter;
	String snotes = "";
	Integer movetopos = -1;
	int editpos = -1;
	Long editdeletepos = 12345678910L;
	Integer dialogno = -1;
	Integer contextdialog = -1;
	ListView datalist;
    //Spinner noisetypes,noiseimages;
    //Button Fillrecord;
    //Integer rday,rmon,ryear,rhour,rmin,rsec;
	Activity contextactivity = null;
	Integer deleditflag = -1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.main_list);
		
		if (savedInstanceState != null) {
			Log.d("SAVED","In onCreate saved Instance");
			guideon = savedInstanceState.getBoolean("GUIDE");
			Log.d("SAVED","Guideon = "+guideon);
			
			dialogno = savedInstanceState.getInt("ALLDIALOGS",-1);
			Log.i("SAVED","dialogno = "+dialogno);
			editpos = savedInstanceState.getInt("RECPOS",-1);
			editdeletepos = savedInstanceState.getLong("RECID",-1);
			contextdialog = savedInstanceState.getInt("CONTEXT",-1);
			longrowclick1 = savedInstanceState.getInt("ROWPOS",-1);
		}
		
		/*ActionBar actionbar = getActionBar();
        actionbar.setDisplayShowHomeEnabled(true);
        actionbar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);*/
		Log.v("FROMDATEFILTER", "On Create fromdef="+fromdatef);
		Log.v("TODATEFILTER", "On Create tomdef="+todatef);
		fromdatefilter = String.valueOf(fromdatef);
		todatefilter = String.valueOf(todatef);
		filteryear = 0;
		filteryear = 0;
		filtermonth = 0;
		filterflag = -1;
		filtered = -1;
		fromfilterday = 1;
	     fromfiltermonth = 1;
	     fromfilteryear = 2000;
	     tofilterday = 28;
	     tofiltermonth = 2;
	     tofilteryear = 2013;
	    
	    
	     tb1 = (TableLayout)findViewById(R.id.Table1);
	 //   if (!guideon) {
	   // 	 guidedialog();
	    // }
	     
	     if (!dialogno.equals(-1)) {
	    	 rundialog(dialogno);
	     }
//	     guided = new Dialog(this);
//	     guided.setContentView(R.layout.help);
//	     guided.setTitle("Basic Guide");
//	     guided.setCancelable(true);
//	     
//         
//         
//         guidetxt = (TextView)guided.findViewById(R.id.helptxt);
//	     //guidetxt.setText("This is where the instructions for the Nuisance Neighbour app will be");
//	     
//	   
//	    
//		try {
//			 Resources gstr = getResources();
//			 InputStream ingstr = gstr.openRawResource(R.raw.nnguide);
//			byte[] b = new byte[ingstr.available()];
//			ingstr.read(b);
//			guidetxt.setText(new String(b));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			guidetxt.setText("Sorry - Help guide not found :( ");
//		}
//
//		cancelguide = (Button)guided.findViewById(R.id.closehelp);
//		cancelguide.setVisibility(View.VISIBLE);
//        cancelguide.setOnClickListener(new OnClickListener () {
//
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				guided.dismiss();
//				
//			}
//			
//       });
		    
	       datalist = getListView();
	      datalist.setCacheColorHint(0);
	      datalist.setClickable(false);
	      datalist.setPressed(false);
	     datalist.setSelector(R.drawable.transparent);
	     //datalist.setLongClickable(true);
	    
	   // datalist.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
	    
           
//	      datalist.setOnItemClickListener(new  OnItemClickListener() {
//
//			@Override
//			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
//					long arg3) {
//				// TODO Auto-generated method stub
//				
//				rowchecked = arg2;
//				rowid = arg3;
//				isclick = true;
//				islongclick = false;
//			datalist.smoothScrollToPosition(arg2);
//				
//			
//			//  arg0.setSelection(arg2);
//		//	datalist.setItemChecked(arg2, true);
//			Toast.makeText(getApplicationContext(), "Row "+Integer.toString(arg2) + " Clicked", Toast.LENGTH_LONG).show();
//				
//			}});
//	 
	      
	      datalist.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
		 

			@Override
			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				
				
				 Toast.makeText(getApplicationContext(), "You have Reached onItemClickListener   ", Toast.LENGTH_SHORT).show();
				 if (longrowclick1==arg2) {
					 islongclickbefore = true;
					 Log.i("onItemLongClick LongRowClick", "longrowlick1 matches arg2 : "+longrowclick1+" Arg2 = "+arg2);
					 Log.i("onItemLongClick ", "islongclickbefore = "+islongclickbefore);
					 getmainlistadapter.setlongpos(arg2);
					 longrowclick1 = -1;
					// islongclickbefore = false;
					// Log.i("", "");
				//	 Log.i("", "");
					 //colorcounter = -1;
					// adapter.notifyDataSetChanged();
//					Cursor longclickcursorblack = adapter.getCursor();
//					longclickcursorblack.moveToPosition(arg2);
//					((TableLayout)arg1.findViewById(R.id.Table1)).setBackgroundColor(Color.BLACK);
//					((TableLayout)arg1.findViewById(R.id.Table2)).setBackgroundColor(Color.BLACK);
//					((TableLayout)arg1.findViewById(R.id.Table3)).setBackgroundColor(Color.BLACK);
//					((TableRow)arg1.findViewById(R.id.tableRow1)).setBackgroundColor(Color.BLACK);
//					((TableRow)arg1.findViewById(R.id.tableRow2)).setBackgroundColor(Color.BLACK);
//					((TableRow)arg1.findViewById(R.id.tableRow3)).setBackgroundColor(Color.BLACK);
//					// refreshc++;
					 Toast.makeText(getApplicationContext(), "YOU HAVE CLICKED HERE BEFORE!!!! , Refreshed =   "+Integer.toString(refreshc), Toast.LENGTH_SHORT).show();
//					 Log.d("LONGCLICKCOLORCOUNTER","ColorCounter reached  = "+colorcounter);
//					
					 return true; 
				 } else   {
					 posdeledit = arg2;
					 ideledit = arg3;
					 rundialog(10);
					 // if (longrowclick1!=arg2
					 Log.i("onItemLongClick LongRowClick1", "LongRowClick1 does not match arg2 : "+longrowclick1+" Arg2 = "+arg2);
					 islongclickbefore = false;
					 longrowclick1 = arg2;
					 Log.i("onItemLongClick ", "islongclickbefore = "+islongclickbefore);
					 getmainlistadapter.setlongpos(arg2);
					 Toast.makeText(getApplicationContext(), "This is the first time you have clicked here WOW!", Toast.LENGTH_SHORT).show();
//					 colorcounter = -1;
//					 isclick = false;
//						islongclick = true;
//						if ( longrowclick1!=arg2 && longrowclick1!=-1) {
//							Cursor longclickcursorbluebefore = adapter.getCursor();
//							longclickcursorbluebefore.moveToPosition(longrowclick1);
//							mC.moveToPosition(longrowclick1);
//							 Log.d("LONGCLICKMOVEBACK","Long Click Move back to pos  = "+longclickcursorbluebefore.getPosition());
//							 Log.d("LONGCLICKMOVEBACK","Long Click Pos to Move to is  = "+arg2);
//							((TableLayout)arg1.findViewById(R.id.Table1)).setBackgroundColor(Color.BLACK);
//							((TableLayout)arg1.findViewById(R.id.Table2)).setBackgroundColor(Color.BLACK);
//							((TableLayout)arg1.findViewById(R.id.Table3)).setBackgroundColor(Color.BLACK);
//							((TableRow)arg1.findViewById(R.id.tableRow1)).setBackgroundColor(Color.BLACK);
//							((TableRow)arg1.findViewById(R.id.tableRow2)).setBackgroundColor(Color.BLACK);
//							((TableRow)arg1.findViewById(R.id.tableRow3)).setBackgroundColor(Color.BLACK);
//							return false;
//						}
//						longrowclick1 = arg2;
//						 Log.d("ONITEMLONGCLICK","View Clicked = "+arg1);
//						 Log.d("ONITEMLONGCLICK","Position Clicked = "+arg2);
//						 islongclickbefore = false;
//					 //adapter.notifyDataSetChanged();
//							Cursor longclickcursorblue = adapter.getCursor();
//							longclickcursorblue.moveToPosition(arg2);
//							((TableLayout)arg1.findViewById(R.id.Table1)).setBackgroundResource(R.drawable.darkslateblue);
//							((TableLayout)arg1.findViewById(R.id.Table2)).setBackgroundResource(R.drawable.darkslateblue);
//							((TableLayout)arg1.findViewById(R.id.Table3)).setBackgroundResource(R.drawable.darkslateblue);
//							((TableRow)arg1.findViewById(R.id.tableRow1)).setBackgroundResource(R.drawable.darkslateblue);
//							((TableRow)arg1.findViewById(R.id.tableRow2)).setBackgroundResource(R.drawable.darkslateblue);
//							((TableRow)arg1.findViewById(R.id.tableRow3)).setBackgroundResource(R.drawable.darkslateblue);
//						// datalist.smoothScrollToPosition(longrowclick1);
//					 
					return false;
				 }
				
					 
			//	datalist.smoothScrollToPosition(arg2);
				//Toast.makeText(getApplicationContext(), "Row "+Integer.toString(arg2) + " Long Clicked", Toast.LENGTH_LONG).show();
				//Toast.makeText(getApplicationContext(), "Long Cick Row = "+Integer.toString(longrowclick) + " Long Clicked", Toast.LENGTH_LONG).show();
			// adapter.notifyDataSetChanged();
			// datalist.smoothScrollToPosition(longrowclick1);
			//	return true;
			}});
	     
	     
	     //datalist.setSelector(R.drawable.steelblue);
	    // datalist.setSelector(R.drawable.steelblue);
	     
		//Enotes = (EditText)findViewById(R.id.notes);
		//Ehour = (EditText)findViewById(R.id.hour_edit);
		//Emin = (EditText)findViewById(R.id.min_edit);
		//Esec = (EditText)findViewById(R.id.sec_edit);
		//Eday = (EditText)findViewById(R.id.Day_edit);
		//Emonth = (EditText)findViewById(R.id.Mon_edit);
		//Eyear = (EditText)findViewById(R.id.year_edit);
		
		//noisetypes = (Spinner)findViewById(R.id.c_types);
	//	noiseimages = (Spinner)findViewById(R.id.image_list);
		//noiseimages.setAdapter(new MyCustomAdapter(MainActivity.this, R.layout.spinner, noiseimage));
	    
	//	Fillrecord = (Button)findViewById(R.id.fill);
		//Fillrecord.setOnClickListener(this);
	
		
		
	
       mDBHelper = new DBAdapter(this);
       mDBHelper = mDBHelper.open();
       
       
       
       
       
 //    registerForContextMenu(getListView()); 
     
     refreshList();
  /**   if (contextdialog.equals(1)) {
    	 getListView().getOnItemLongClickListener();
     } **/
	}
	
	
	public void rundialog(Integer showit) {
		// 1 = single record delete dialog - Done
		// 2 = Record Edit routine - Done
		// 3 = delete all record dialog
		// 4 = no records to export dialog
		// 5 = add new record dialog
		// 6 = no records found on filter
		// 7 = No data on first use of app - add import cancel
		// 8 = Guide Dialog Box - Done
		// 9 = Quit Program - Done
		// 10 = Alert Dialog to replace the Context Menu - Done
		// 11 = The filter date dialog may even include keeping the date picker on screen
		switch (showit) {
		
		case 1:
			//alldialogs
			dialogno = showit;
			AlertDialog.Builder delrecdialog = new AlertDialog.Builder(this);
			delrecdialog.setMessage("Do you want to delete THIS Record?!?!?")
			.setCancelable(false)
			.setPositiveButton("YES!", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					mDBHelper.deleteLogRec(ideledit);		
					longrowclick1= -1;
					islongclickbefore = false;
					dialogno = -1;
					refreshList();
				}
			})
			.setNegativeButton("NO!!", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					dialogno = -1;
				  dialog.cancel();	
				}
			});
			alldialogs = delrecdialog.create();
			alldialogs.setTitle("Delete THIS Records?!?!?");
			alldialogs.setIcon(R.drawable.delete);
			alldialogs.show();
			break;
			
		case 2: 
			dialogno = -1;
			Cursor c = mC;
			c.moveToPosition(posdeledit);
			
			Intent i = new Intent();
			i.setClass(this, enterdata.class);
			
			i.putExtra(DBAdapter.COL_ID, ideledit);
			
			i.putExtra(DBAdapter.COL_NOISE_DAY, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_DAY)));
			i.putExtra(DBAdapter.COL_NOISE_MON, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_MON)));
			i.putExtra(DBAdapter.COL_NOISE_YEAR, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_YEAR)));
			i.putExtra(DBAdapter.COL_NOISE_HOUR, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_HOUR)));
			i.putExtra(DBAdapter.COL_NOISE_MIN, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_MIN)));
			i.putExtra(DBAdapter.COL_NOISE_SEC, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_SEC)));
			
			i.putExtra(DBAdapter.COL_NOISE_IMAGE, c.getString(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_IMAGE)));
			i.putExtra(DBAdapter.COL_NOISE_INFO, c.getString(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_INFO)));
			i.putExtra(DBAdapter.COL_NOISE_TYPE, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_TYPE)));
			
			longrowclick1= -1;
			islongclickbefore = false;
			startActivityForResult(i, REQUEST_EDIT);	
			break;
        case 3: 
        	dialogno = showit;
			break;

        case 4: 
        	dialogno = showit;
			break;
        case 5: 
        	dialogno = showit;
			break;
			
        case 6: 
        	dialogno = showit;
			break;

        case 7: 
        	dialogno = showit;
			break;

        case 8 :
        	guidedialog();
        	dialogno = showit;
         	guideon = true;
       	    guided.show();
        	break;
        case 9:
        	dialogno = showit;
        	AlertDialog.Builder quitprogram = new AlertDialog.Builder(this);
        	quitprogram.setMessage("Quit Nuisance Neighbour?")
			.setCancelable(false)
			.setPositiveButton("YES!", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					finish();
				}
			})
			.setNegativeButton("NO!!", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					dialogno = -1;
				  dialog.cancel();	
				}
			});
			alldialogs = quitprogram.create();
			alldialogs.setTitle("Quit Program?");
			alldialogs.setIcon(R.drawable.app_icon);
			alldialogs.show();
        	break;
        	
        case 10:
        	final String[] deleteedit = {"Delete","Edit"}; 
        	dialogno = showit;
        	AlertDialog.Builder popupmenu = new AlertDialog.Builder(this);
        	popupmenu.setTitle("Delete or Edit Record?")
        	.setCancelable(false)
        	.setSingleChoiceItems(deleteedit, -1,  new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					if (deleteedit[which]=="Delete") {
						deleditflag = 1;
					} else if (deleteedit[which]=="Edit") {
						deleditflag = 2;
					}
				}
			})
			.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					if (deleditflag == 1) {
						dialogno = -1;
						rundialog(1);
						
					} else if (deleditflag == 2) {
						dialogno = -1;
						rundialog(2);
					}
					
				}
			})
			
			.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					dialogno = -1;
					islongclickbefore = true;
					getmainlistadapter.setlongpos(posdeledit);
					longrowclick1 = -1;
				    dialog.dismiss();	
				}
			});
			
        	alldialogs = popupmenu.create();
			alldialogs.setTitle("Edit or Delete Record?");
			alldialogs.setIcon(R.drawable.app_icon);
			alldialogs.show();
        	
        	//popupmenu.sets
        	
        	break;
		
		}
	}
	
	
	
	public void guidedialog()
	{
		 guided = new Dialog(this);
	     guided.setContentView(R.layout.help);
	     guided.setTitle("Basic Guide");
	     guided.setCancelable(true);
	     
         
         
         guidetxt = (TextView)guided.findViewById(R.id.helptxt);
	     //guidetxt.setText("This is where the instructions for the Nuisance Neighbour app will be");
	     
	   
	    
		try {
			 Resources gstr = getResources();
			 InputStream ingstr = gstr.openRawResource(R.raw.nnguide);
			byte[] b = new byte[ingstr.available()];
			ingstr.read(b);
			guidetxt.setText(new String(b));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			guidetxt.setText("Sorry - Help guide not found :( ");
		}

		cancelguide = (Button)guided.findViewById(R.id.closehelp);
		cancelguide.setVisibility(View.VISIBLE);
        cancelguide.setOnClickListener(new OnClickListener () {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				guideon = false;
				dialogno = -1;
				guided.dismiss();
				
			}
			
       });
		
	}	
	@Override
	protected void onSaveInstanceState(Bundle saved) {
		Log.i("SAVEI","Reached on Save Instance State");
		Log.i("SAVEI","Dialog NO = "+dialogno);
		if (guideon) {
			Log.i("GUIDEON","Guide on = "+guideon);
			saved.putBoolean("GUIDE", guideon);
		}
		if (!dialogno.equals(-1)) {
			saved.putInt("ALLDIALOGS", dialogno);
			if (!editdeletepos.equals(12345678910L)) {
	    	 	saved.putLong("RECID", editdeletepos);
	 	    	saved.putInt("RECPOS", editpos); 
			}
		}
		
		if (!islongclickbefore) {
			saved.putInt("ROWPOS", longrowclick1);
			
		}
		
		super.onSaveInstanceState(saved);
	}
	@Override
	protected void onResume() {
		super.onResume();
		Log.d("RESUME","Reached on Resume");
	//	if (guideon) {
	///		Log.d("GUIDEON","On Resume - Guide on = YES");
	///		guidedialog();
	///		guided.show();
	///	}
		
		
	}
	
	
	
	@Override
	protected void onPause() {
		super.onPause();
		Log.i("PAUSE","Reached on Pause");
		
		if (!dialogno.equals(-1)) {
			Log.i("CLDIALOG","Before closing dialog, Dialogno is "+dialogno);
			if (guideon) {
				Log.i("GUIDEON","On Resume - Guide on = YES - Close Dialog");
				guided.dismiss();
			} else {
				Log.i("DIALOGON","On Resume - DIALOG on = YES - Close Dialog");
			  alldialogs.dismiss(); 
			}
		}
		
		
		  
		     
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		//MenuInflater inflater = getMenuInflater();
	//	inflater.inflate(R.menu.main, menu);
		getMenuInflater().inflate(R.menu.main, menu);
			
		return true;
	}
	
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		 super.onCreateContextMenu(menu, v, menuInfo);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.contextmenu, menu);
		// set variable to acknowledge that the context menu has been used
       contextdialog = 1;
		
	     
		
	}

	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId())
		{
		case R.id.Insert:
			//Toast.makeText(this, "Add", Toast.LENGTH_SHORT).show();
			Intent i = new Intent();
			i.setClass(this, enterdata.class);
			i.putExtra("id", 0);
			
			startActivityForResult(i, REQUEST_ADD);			
			
			return true;
			
		case R.id.export:
		if (mC.getCount()>0) {	
			Intent export = new Intent();			
			if (filtered==3) {
				export.putExtra("filtered", filtered);
				export.putExtra("fromd", fromdatefilter);
				export.putExtra("tod", todatefilter);
			}
			export.setClass(this, Exportfile.class);
			startActivity(export);
		} else {
			new AlertDialog.Builder(this)
			.setTitle("Alert!")
			.setIcon(R.drawable.exportcsv)
			.setMessage("There are no Records to export")
			.setPositiveButton("OK",null)
			.show();
		}
			return true;
			
		case R.id.importd:
			Intent importdi = new Intent();
			importdi.setClass(this, Importfile.class);
			startActivity(importdi);
			
			
		
		return true;
		
		
		case R.id.guide:
			rundialog(8);
			//guideon = true;
			//Log.d("GUIDEON","Starting Help Dialog... guideon = "+guideon);
			//guided.show();
			
			return true;
		
		case R.id.DeleteAll:
			AlertDialog.Builder deldialog = new AlertDialog.Builder(this);
			deldialog.setMessage("Do you want to delete ALL Records?!?!?")
			.setCancelable(false)
			.setPositiveButton("YES!", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					mDBHelper.deleteAllLogs();
					refreshList();
				}
			})
			.setNegativeButton("NO!!", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
				  dialog.cancel();	
				}
			});
			AlertDialog deleterecords = deldialog.create();
			deleterecords.setTitle("Delete ALL Records?!?!?");
			deleterecords.setIcon(R.drawable.delete);
			deleterecords.show();
			
			
			return true;
			
		case R.id.stats:
			if (mC.getCount()>0) {
			Intent statspage = new Intent();
			statspage.setClass(this, StatsScreen.class);
			startActivity(statspage);
			} else {
				Toast.makeText(this, "No records found", Toast.LENGTH_LONG).show();
				
			}
			return true;
			
		case R.id.findnotes:
			
			searchnote();
			
			return true;
			
		case R.id.movetorec:
			entermonth();
		   return true;
			
		case R.id.movefirst:
		  ListView getfirst = getListView();
		  getfirst.setSelection(0);
		return true;
		
		case R.id.movelast:
			final ListView getlast = getListView();
		//	getlast.setEnabled(false);
			//mC.moveToLast();
			getlast.post(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					getlast.setSelection(mC.getCount()-1);
				}});
			
		
			//getlast.setEnabled(true);
			return true;
		    
		    
		case R.id.datefilter:
//			  if (sorttype == 1 ) {
//				  sorttype = 2;
//				  refreshList();
//			  } else if (sorttype == 2) {
//				  sorttype = 1;
//				  refreshList();
//			  }
//			final Dialog dialog = new Dialog(MainActivity.this);
//			dialog.setContentView(R.layout.datefilter);
//			dialog.setTitle("Please choose a date range");
//			dialog.setCancelable(true);
//			
//			Button fromdate = (Button)dialog.findViewById(R.id.fromdate);
//			Button todate = (Button)dialog.findViewById(R.id.todate);
//			Button okfilter = (Button)dialog.findViewById(R.id.okfilter);
//			Button cancelfilter = (Button)dialog.findViewById(R.id.cancelfilter);
//			datefrom = (TextView)dialog.findViewById(R.id.datefrom);
//			 dateto = (TextView)dialog.findViewById(R.id.dateto);
//			 
//			 okfilter.setOnClickListener(new OnClickListener() {
//
//				@Override
//				public void onClick(View arg0) {
//					// TODO Auto-generated method stub
//					if (fromfilteryear <= tofilteryear) {
//						Toast.makeText(MainActivity.this, "From Year is LESS!! that to Year", Toast.LENGTH_LONG).show();
//						filtered = 1;
//						if (fromfiltermonth <= tofiltermonth) {
//							filtered = 2;	
//							Toast.makeText(MainActivity.this, "From Month is LESS!! that to Month", Toast.LENGTH_LONG).show();
//							if (fromfilterday <= tofilterday) {
//								filtered = 3;
//								Toast.makeText(MainActivity.this, "From Day is LESS!! that to Day", Toast.LENGTH_LONG).show();
//							} else {
//								Toast.makeText(MainActivity.this, "From Day is Greater that to Day", Toast.LENGTH_LONG).show();
//								filtered = -1;
//							}
//							
//							
//						} else {
//							Toast.makeText(MainActivity.this, "From Month is Greater that to Month", Toast.LENGTH_LONG).show();
//							filtered = -1;
//						}
//					  refreshList();
//					  dialog.cancel();
//					} else {
//						Toast.makeText(MainActivity.this, "From Date is Greater that to Date", Toast.LENGTH_LONG).show();
//						filtered = -1;
//					}
//					
//					
////					if (fromdatef > todatef) {
////						Toast.makeText(MainActivity.this, "From Date is Greater that to Date", Toast.LENGTH_LONG).show();
////						fromdatef = Long.valueOf("0");
////						todatef = Long.valueOf("0");
////					} else {
////						Toast.makeText(MainActivity.this, "From Date is LESS!! that to Date", Toast.LENGTH_LONG).show();
////					}
//					
//				} });
//			 
//			 todate.setOnClickListener(new OnClickListener() {
//
//				@Override
//				public void onClick(View arg0) {
//					// TODO Auto-generated method stub
//					Calendar filtertodate = Calendar.getInstance();
//					tod = new DatePickerDialog(MainActivity.this, new DatePickHandler(), filtertodate.get(Calendar.YEAR), filtertodate.get(Calendar.MONTH), filtertodate.get(Calendar.DAY_OF_MONTH));
//					filterflag = 2;
//					tod.show();
//				} });
//			fromdate.setOnClickListener(new OnClickListener() {
//
//				@Override
//				public void onClick(View arg0) {
//					// TODO Auto-generated method stub
//					
//					Calendar filterfromdate = Calendar.getInstance();
//					fromd = new DatePickerDialog(MainActivity.this, new DatePickHandler(), filterfromdate.get(Calendar.YEAR), filterfromdate.get(Calendar.MONTH), filterfromdate.get(Calendar.DAY_OF_MONTH));
//					filterflag = 1;
//					fromd.show();
//					
//				}});
//			
//			cancelfilter.setOnClickListener(new OnClickListener() {
//
//				@Override
//				public void onClick(View arg0) {
//					// TODO Auto-generated method stub
//					
//					dialog.cancel();
//				}});
//					
//			dialog.show();
			
			filterdate();
			return true;
			
		case R.id.time:		
			  if (sorttype == 1 ) {
			  sorttype = 2;
			  noise_sort_field = "noise_date"; 
			refreshList();
		  } else if (sorttype == 2) {
			  sorttype = 1;
			  noise_sort_field = "noise_date";
			  refreshList();
		  }
	         return true;
	         
//		case R.id.type :
//			  if (sorttype == 1 ) {
//				  sorttype = 2;
//				  noise_sort_field = "noise_type_id"; 
//				refreshList();
//			  } else if (sorttype == 2) {
//				  sorttype = 1;
//				  noise_sort_field = "noise_type_id";
//				  refreshList();
//			  }
//			  return true;
		case R.id.clearsort:
			sorttype = 1;
			noise_sort_field = "noise_date";
			filtered = -1;
			snotesflag = -1;
			snotes = "";
			refreshList();
			return true;
			
		case R.id.exitapp:
			rundialog(9);
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		
		AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
		//int position = info.position;
		editpos = info.position;
		//final long id = info.id;
		editdeletepos = info.id;
		
	   
		switch (item.getItemId())
		{
		case R.id.miDelete:
			rundialog(1);
		/**	AlertDialog.Builder delrecdialog = new AlertDialog.Builder(this);
			delrecdialog.setMessage("Do you want to delete THIS Record?!?!?")
			.setCancelable(false)
			.setPositiveButton("YES!", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					mDBHelper.deleteLogRec(editdeletepos);		
					longrowclick1= -1;
					islongclickbefore = false;
					refreshList();
				}
			})
			.setNegativeButton("NO!!", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
				  dialog.cancel();	
				}
			});
			AlertDialog deleterecord = delrecdialog.create();
			deleterecord.setTitle("Delete THIS Records?!?!?");
			deleterecord.setIcon(R.drawable.delete);
			deleterecord.show(); **/
				
			return true;
		case R.id.miEdit:
			
			Cursor c = mC;
			c.moveToPosition(editpos);
			
			Intent i = new Intent();
			i.setClass(this, enterdata.class);
			
			i.putExtra(DBAdapter.COL_ID, editdeletepos);
			
			i.putExtra(DBAdapter.COL_NOISE_DAY, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_DAY)));
			i.putExtra(DBAdapter.COL_NOISE_MON, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_MON)));
			i.putExtra(DBAdapter.COL_NOISE_YEAR, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_YEAR)));
			i.putExtra(DBAdapter.COL_NOISE_HOUR, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_HOUR)));
			i.putExtra(DBAdapter.COL_NOISE_MIN, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_MIN)));
			i.putExtra(DBAdapter.COL_NOISE_SEC, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_SEC)));
			
			i.putExtra(DBAdapter.COL_NOISE_IMAGE, c.getString(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_IMAGE)));
			i.putExtra(DBAdapter.COL_NOISE_INFO, c.getString(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_INFO)));
			i.putExtra(DBAdapter.COL_NOISE_TYPE, c.getInt(c.getColumnIndexOrThrow(DBAdapter.COL_NOISE_TYPE)));
			
			longrowclick1= -1;
			islongclickbefore = false;
			startActivityForResult(i, REQUEST_EDIT);		
			
			
			return true;
		default:
			return super.onContextItemSelected(item);
		}
	}

	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		
		mDBHelper.close();
	}
public void refreshList() {
	   Log.v("FILTERED", String.valueOf(filtered));
	   
	    
	   
		if (filtered==3 ) {
			Log.v("FROMDATE", String.valueOf(fromfilterday) + " "+ String.valueOf(fromfiltermonth) + " "  +String.valueOf(fromfilteryear));
			Log.v("TODATE", String.valueOf(tofilterday) + " "+ String.valueOf(tofiltermonth) + " "  +String.valueOf(tofilteryear));
			//mC = mDBHelper.GetDateFilter(fromfilterday,fromfiltermonth,fromfilteryear,tofilterday, tofiltermonth,tofilteryear);
			
		
			mC = mDBHelper.gdfl(Long.valueOf(fromdatefilter), Long.valueOf(todatefilter));
			
			//mC = mDBHelper.gdf(Integer.valueOf(fromdatefilter), Integer.valueOf(todatefilter));
			
			
		} else {	
			mC = mDBHelper.GetAllLogs(sorttype,noise_sort_field);
		}
		if (snotesflag == 1) {
	    	mC = mDBHelper.searchnotes(snotes);
	    	Log.v("SNOTES",snotes);
	    	
	    } else if (snotesflag == -1 && filtered == -1) {
	    	mC = mDBHelper.GetAllLogs(sorttype,noise_sort_field);
	    }
		
		if (movetopos !=-1 ) {
			mC.moveToPosition(movetopos);
		}
		//mC = mDBHelper.GetAllLogs(sorttype,noise_sort_field);
		//mC = mDBHelper.GetAllLogs(sorttype,noise_sort_field);
		startManagingCursor(mC);
		if (mC.getCount()==0 && filtered==-1) {
			AlertDialog.Builder insertdialog = new AlertDialog.Builder(this);
			insertdialog.setMessage("There are no records found, do you want to create a new record?")
			.setCancelable(false)
			.setPositiveButton("YES!", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					Intent i = new Intent();
					i.setClass(getApplicationContext(), enterdata.class);
					i.putExtra("id", 0);
					
					startActivityForResult(i, REQUEST_ADD);		
				}
			})
			
			.setNeutralButton("IMPORT?", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					Intent importdi = new Intent();
					importdi.setClass(MainActivity.this, Importfile.class);
					startActivity(importdi);
				}
			})
			
			.setNegativeButton("NO!", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
				  dialog.cancel();	
				}
			});
			AlertDialog insertrecord = insertdialog.create();
			insertrecord.setTitle("Insert a new record?");
			insertrecord.setIcon(R.drawable.app_icon);
			insertrecord.show();
		} else if (mC.getCount()==0 && filtered==3) {
			AlertDialog.Builder filterdialog = new AlertDialog.Builder(this);
			filterdialog.setMessage("There are no records found. Clear sort? or Filter again? ")
			.setCancelable(false)
			.setPositiveButton("Clear Sort", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					sorttype = 1;
					noise_sort_field = "noise_date";
					filtered = -1;
					refreshList();
					dialog.cancel();
				}
			})
			.setNegativeButton("Filter Again", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					sorttype = 1;
					noise_sort_field = "noise_date";
					filtered = -1;
					refreshList();
				    filterdate();
				
				  dialog.cancel();	
				  
				}
			});
			AlertDialog filteralert = filterdialog.create();
			filteralert.setTitle("No Filtered Records Found");
			filteralert.setIcon(R.drawable.dateerror);
			filteralert.show();
		}
		
		

		
	//	 adapter = new SimpleCursorAdapter(this,R.layout.viewdata, mC, fields, viewfields);
		 
		
		 getmainlistadapter = new mainlistadapter(this,R.layout.viewdata,mC,fields,viewfields);
	
      
	/**	adapter.setViewBinder(new SimpleCursorAdapter.ViewBinder() {
			
			@Override
			public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
				// TODO Auto-generated method stub
				 colorcounter++;
				 Log.d("BEFORENOW","longrowclick1 = "+longrowclick1);
	Log.d("COLORCOUNTER","Color Counter = "+colorcounter); 
//	if (colorcounter.equals(89)) {
//		//longrowclick1 = -1;
//		//islongclickbefore = false;
//		Log.d("COLORCOUNTER_RESET","Color Counter before reset = "+colorcounter);
//		colorcounter = -1;
//		if (islongclickbefore) {
//			islongclickbefore = false;
//			longrowclick1 = -1;
//		}
//	}
	Log.d("STARTHERE", "longrowclick1 row no= "+longrowclick1 +" Cursor POS="+cursor.getPosition());
	// is the current cursor position the same that has been Long Clicked			
	if (cursor.getPosition()==longrowclick1 && !islongclickbefore ) {
		islongclicked = true;
		Log.d("COLORCOUNTER","Inside Blue Highlight Color Counter = "+colorcounter);
		// sets up parent view of object
		if (((View)view.getParent()).getId()==R.id.Table1  || ((View)view.getParent()).getId()==R.id.tableRow1  || ((View)view.getParent()).getId()==R.id.tableRow2  || ((View)view.getParent()).getId()==R.id.tableRow3 || ((View)view.getParent()).getId()==R.id.Table2  || ((View)view.getParent()).getId()==R.id.Table3  ){ 
		    myviewp = (View) view.getParent();
		 }
		  Log.d("HERE", "Set to Blue not long clicked");
		  
		  Log.d("HERE", "Parent view clicked "+myviewp);
				
		 if (myviewp.getId()==R.id.Table1  || myviewp.getId()==R.id.tableRow1  || myviewp.getId()==R.id.tableRow2  || myviewp.getId()==R.id.tableRow3 || myviewp.getId()==R.id.Table2  || myviewp.getId()==R.id.Table3  ) {	 
		 // checks if parent view is valid (there are a lot here)
	//	if (((View)view.getParent()).getId()==R.id.Table1  || ((View)view.getParent()).getId()==R.id.tableRow1  || ((View)view.getParent()).getId()==R.id.tableRow2  || ((View)view.getParent()).getId()==R.id.tableRow3 || ((View)view.getParent()).getId()==R.id.Table2  || ((View)view.getParent()).getId()==R.id.Table3  ) {
			//Toast.makeText(getApplication(), "Long Row Click1 = "+Integer.toString(longrowclick1) +" and Prev Long Click =  "+Integer.toString(prevlongclick)  , Toast.LENGTH_LONG).show();
			  Log.d("PARENTCHECK", "Set to Blue not long clicked before and the parent view is : "+myviewp);
		
			  myviewp.setBackgroundResource(R.drawable.darkslateblue);
			  if (view.getId()!=R.id.seper) {
					view.setBackgroundResource(R.drawable.darkslateblue);
					
					// ... set them to the dark slate blue ...
				//	view.setBackgroundResource(R.drawable.darkslateblue);
				} else { // else if the child object is the date separator ..
					// .. keep it as dark gray
					view.setBackgroundColor(Color.DKGRAY);
				}
		  
 	 		// Then sets the background to dark slate blue
			//myviewp.setBackgroundResource(R.drawable.darkslateblue);
		
//	        ColorDrawable vbk = (ColorDrawable) myviewp.getBackground();
//	        if (vbk.getColor()==bluecolor && colorcounter==9) {
//	        	colorcounter = -1;
//	              	
//	        	   Log.d("GOTCOLOR", "Parent background is BLUE! ");
//	        	   myviewp.setBackgroundColor(Color.BLACK);
//	        	   
//	        
//	        } else if (vbk.getColor()==blackcolor && colorcounter==9) {
//	        	colorcounter = -1;
//	        	Log.d("GOTCOLOR", "Parent background is BLACK! ");
//	        	myviewp.setBackgroundResource(R.drawable.darkslateblue);
//	        }
//	        Log.d("BACKGRD", "Back Ground Color of Main Views int value when selected (BLUE) =  "+vbk.getColor());
//	        Log.d("BACKGRD", "Dark Slate Blue Int =   "+R.drawable.darkslateblue);
//					
			// if one of the child views are not the date separator then ..
//			if (view.getId()!=R.id.seper) {
//				view.setBackgroundResource(R.drawable.darkslateblue);
//				
//				// ... set them to the dark slate blue ...
//			//	view.setBackgroundResource(R.drawable.darkslateblue);
//			} else { // else if the child object is the date separator ..
//				// .. keep it as dark gray
//				view.setBackgroundColor(Color.DKGRAY);
//			}
		
	
		}
			
		
		
		
	} 
	
	if (cursor.getPosition()!=longrowclick1 && !islongclickbefore ) {// if the cursor position does not match the Long Click Position then ..
		// .. get the parent of the current child object ...
	//	islongclicked = false;
		Log.d("HERE", "Set to black not long clicked before : longrowclick1 row no= "+longrowclick1 +"Cursor POS="+cursor.getPosition());
           //islongclickbefore = false;
        //   colorcounter = -1;
        
		 myviewp = (View) view.getParent();
		 // .. set the background of the parent to black ..
		myviewp.setBackgroundColor(Color.BLACK);
		// .. check to make sure that the child object is not the date separator ...
		if (view.getId()!=R.id.seper) {
			// .. and then set the child object background to black .. 
	    	view.setBackgroundColor(Color.BLACK); 
		 } else { // .. else if it the child object is the date separator then ..
	         // .. set it to the dark gray background .	
			 view.setBackgroundColor(Color.DKGRAY);
		 }
		 ColorDrawable vbk1 = (ColorDrawable) myviewp.getBackground();
		Log.d("BACKGRD", "Back Ground Color of Main Views int value when not selected (BLACK) =  "+vbk1.getColor());
		
		
	}			
	
	if (cursor.getPosition()==longrowclick1 && islongclickbefore ) {
		Log.d("HERE", "Set to black - Long Clicked Before!!!");
		 myviewp = (View) view.getParent();
		 if (((View)view.getParent()).getId()==R.id.Table1  || ((View)view.getParent()).getId()==R.id.tableRow1  || ((View)view.getParent()).getId()==R.id.tableRow2  || ((View)view.getParent()).getId()==R.id.tableRow3 || ((View)view.getParent()).getId()==R.id.Table2  || ((View)view.getParent()).getId()==R.id.Table3  ) { 
		 // .. set the background of the parent to black ..
	    	myviewp.setBackgroundColor(Color.BLACK);
		// .. check to make sure that the child object is not the date separator ...
		if (view.getId()!=R.id.seper) {
			// .. and then set the child object background to black .. 
	    	view.setBackgroundColor(Color.BLACK); 
		 } else { // .. else if it the child object is the date separator then ..
	         // .. set it to the dark gray background .	
			 view.setBackgroundColor(Color.DKGRAY);
		 }
		 }
		 //longrowclick1 = -1;
		 //islongclickbefore = false;
		 //return false;
		
	}
				
					
				
         if (view.getId()==R.id.seper) {
        	 Integer prevrowday = 0, prevrowmonth = 0 , prevrowyear=0;
        	 Integer currowdate = cursor.getInt(cursor.getColumnIndex("noise_day"));
        	 Integer currowmonth = cursor.getInt(cursor.getColumnIndex("noise_month"));
        	 Integer currowyear = cursor.getInt(cursor.getColumnIndex("noise_year"));
        	 Integer currdatesort = cursor.getInt(cursor.getColumnIndex("noise_date_sort"));
        	 Log.v("NOISE DATE SORT: ", String.valueOf(currdatesort));
        	 String daystr="",monthstr="";
        	 ((TextView)view).setVisibility(View.INVISIBLE);
        	 Log.v("SEP", "Reached separator");
        	 if (cursor.getPosition()==0 ) {
        		 
        		 daystr = prefixzero(currowdate);
        		 monthstr = months(currowmonth);
        		
        		 ((TextView)view).setText(daystr+" "+monthstr+" "+String.valueOf(currowyear));
        		 ((TextView)view).setVisibility(View.VISIBLE);
        		 
        	 }
        	 Log.v("SEP", "currowdate="+String.valueOf(currowdate)+"; Record postion="+String.valueOf(cursor.getPosition()));
				if (cursor.getPosition()>0 && cursor.moveToPrevious() ) {
			    	
				    prevrowday = cursor.getInt(cursor.getColumnIndex("noise_day"));
				    prevrowmonth = cursor.getInt(cursor.getColumnIndex("noise_month"));
				    prevrowyear = cursor.getInt(cursor.getColumnIndex("noise_year"));
				    Log.v("SEP", "prevrowdate="+String.valueOf(prevrowday)+"; Record postion="+String.valueOf(cursor.getPosition()));
				    cursor.moveToNext();
				
				   if ((prevrowday == null || !prevrowday.equals(currowdate)) || (prevrowmonth == null || !prevrowmonth.equals(currowmonth))|| (prevrowyear == null || !prevrowyear.equals(currowyear))) {
					   Log.v("SEP", "NOW reached where prevdate is new");
					   Log.v("SEP", "prevdate sep="+String.valueOf(prevrowday));
					     daystr = prefixzero(currowdate);
		        		 monthstr = months(currowmonth);
		        		 ((TextView)view).setText(daystr+" "+monthstr+" "+String.valueOf(currowyear));
				//	   ((TextView)view).setText("Day :"+String.valueOf(currowdate));
					   ((TextView)view).setVisibility(View.VISIBLE);
					   
				   } else{
					   ((TextView)view).setVisibility(View.INVISIBLE);
				   }
				}   
				
				return true;
         }				
				
			//	Integer currowdate = cursor.getInt(cursor.getColumnIndex("noise_day")+cursor.getColumnIndex("noise_month")+cursor.getColumnIndex("noise_year"));
//				if (cursor.getCount()>0 && !cursor.isFirst()) {
//			    	cursor.moveToPrevious();
//				    Integer prevrowdate = cursor.getInt(cursor.getColumnIndex("noise_day")+cursor.getColumnIndex("noise_month")+cursor.getColumnIndex("noise_year"));
//				   if (currowdate > prevrowdate) {
//					   sep.setText("Date :"+String.valueOf(prevrowdate));
//					   sep.setVisibility(0);
//					   
//				   }
//				   cursor.moveToNext();
//				}
			    
			
			
			/**	String imgreference = cursor.getString(cursor.getColumnIndex("noise_image_desc"));
					if (view instanceof ImageView ) {
						//Log.i("IMG", "Setting unqiue image");
						int imgres = getResources().getIdentifier(imgreference, null, null);
						((ImageView)view).setImageResource(imgres);
						//**************************************************
				return true;
					} **/ 
				
	/**				if (view.getId()==R.id.noise_type_view) {
						int imgtext = cursor.getInt(cursor.getColumnIndex("noise_type_id"));
						((TextView)view).setText(vnoiseimage[imgtext]);
						return true;
					}
					
				if (view.getId()==R.id.noise_date_day_view) {
					Integer daydataconv = cursor.getInt(cursor.getColumnIndex("noise_day"));
					 String dayconv =prefixzero(daydataconv);
					 //String dayconv1 =fill(((TextView)view).getText().toString());
					// Log.d("PREFIX", "dayconv="+dayconv);
					 //Log.d("PREFIX", "dayconv1="+dayconv1);
					 ((TextView)view).setText(dayconv);
					//  ((TextView)view).setText(dayconv1);
					return true;
				}	
				if (view.getId()==R.id.noise_date_month_view) {
					 Integer monthdataconv = cursor.getInt(cursor.getColumnIndex("noise_month"));
					 String monconv =prefixzero(monthdataconv);
					 //Log.d("PREFIX", "monconv="+monconv);
					  ((TextView)view).setText(monconv);
					return true;
				}	
				
				if (view.getId()==R.id.noise_time_hour_view) {
					Integer hourdataconv = cursor.getInt(cursor.getColumnIndex("noise_hour"));
					 String hourconv =prefixzero(hourdataconv);
				//	 Log.d("PREFIX", "hourconv="+hourconv);
					  ((TextView)view).setText(hourconv);
					return true;
				}	
						
				if (view.getId()==R.id.noise_time_min_view) {
				     Integer mindataconv = cursor.getInt(cursor.getColumnIndex("noise_min"));
					 String minconv =prefixzero(mindataconv);
				//	 Log.d("PREFIX", "minconv="+minconv);
					  ((TextView)view).setText(minconv);
					return true;
				}	
				
				
				
				
				
				if (view.getId()==R.id.noise_time_sec_view) {
					 Integer secdataconv = cursor.getInt(cursor.getColumnIndex("noise_second"));
					 String secconv =prefixzero(secdataconv);
				//	 Log.d("PREFIX", "secconv="+secconv);
					  ((TextView)view).setText(secconv);
					return true;
				}	
				return false;
			
			}
			
			  
		});**/
        
		
        //setListAdapter(adapter);
        setListAdapter(getmainlistadapter);
        ListView cu = getListView();
        if (movetopos !=-1 ){
        cu.smoothScrollToPosition(movetopos);
        mC.moveToPosition(movetopos);
        
        }
        if (contextdialog.equals(1)) {
        	Log.i("REFRESHLIST_CONTEXTDIALOG", "Reached Check ");
			Log.i("LONGCLICKCONTEXT", "contextdialog variable = "+contextdialog);
			
   	   
   	//contextdialog= -1;
    } 
        
	//getmainlistadapter
	}

public class mainlistadapter extends SimpleCursorAdapter {
	private Cursor datacursor;
	private Context datacontext;
	private int layout;
	private final LayoutInflater inflater;
	private String[] datafrom;
	private int[] datato;
    
	public mainlistadapter (Context context,int layout, Cursor c, String[] from, int[] to) {
		super(context,layout,c,from,to);
		this.datacursor = c;
		this.layout = layout;
		this.datacontext = context;
		this.datafrom = from;
		this.datato = to;
		this.inflater = LayoutInflater.from(context);
		
	}
	
/**	@Override
	public View newView (Context context,Cursor cursor, ViewGroup parent) {
		return inflater.inflate(layout,null);
	}
	
	
	@Override
	public void bindView(View view, Context context, Cursor cursor) {
		super.bindView(view, context, cursor);
		
		// Sets up the Image that relates to the noise
		ImageView iconnoise = (ImageView)view.findViewById(R.id.noise_image_type);	
	    String imgreference = datacursor.getString(datacursor.getColumnIndex("noise_image_desc"));
	    int imgres = getResources().getIdentifier(imgreference, null, null);
	    iconnoise.setImageResource(imgres);
	    //*****************************************************************************************
	    
	    // Sets up the description relating to the noise
	    TextView noisetype = (TextView)view.findViewById(R.id.noise_type_view);
	    int imgtext = cursor.getInt(cursor.getColumnIndex("noise_type_id"));
	    noisetype.setText(vnoiseimage[imgtext]);
	  //*****************************************************************************************
	    
	    // Sets up the separator bar which shows the date in DD MMMMMMMMM YYYY format
	    TextView seper = (TextView)view.findViewById(R.id.seper);
        Integer prevrowday = 0, prevrowmonth = 0 , prevrowyear=0;
        Integer currowdate = cursor.getInt(cursor.getColumnIndex("noise_day"));
        Integer currowmonth = cursor.getInt(cursor.getColumnIndex("noise_month"));
        Integer currowyear = cursor.getInt(cursor.getColumnIndex("noise_year"));
        Integer currdatesort = cursor.getInt(cursor.getColumnIndex("noise_date_sort"));
        Log.v("NOISE DATE SORT: ", String.valueOf(currdatesort));
        String daystr="",monthstr="";
        seper.setVisibility(View.INVISIBLE);
        Log.v("SEP", "Reached separator");
        if (cursor.getPosition()==0 ) {
        		 
        		 daystr = prefixzero(currowdate);
        		 monthstr = months(currowmonth);
        		
        		 seper.setText(daystr+" "+monthstr+" "+String.valueOf(currowyear));
        		 seper.setVisibility(View.VISIBLE);
        		 
        	 }
        	 Log.v("SEP", "currowdate="+String.valueOf(currowdate)+"; Record postion="+String.valueOf(cursor.getPosition()));
				if (cursor.getPosition()>0 && cursor.moveToPrevious() ) {
			    	
				    prevrowday = cursor.getInt(cursor.getColumnIndex("noise_day"));
				    prevrowmonth = cursor.getInt(cursor.getColumnIndex("noise_month"));
				    prevrowyear = cursor.getInt(cursor.getColumnIndex("noise_year"));
				    Log.v("SEP", "prevrowdate="+String.valueOf(prevrowday)+"; Record postion="+String.valueOf(cursor.getPosition()));
				    cursor.moveToNext();
				
				   if ((prevrowday == null || !prevrowday.equals(currowdate)) || (prevrowmonth == null || !prevrowmonth.equals(currowmonth))|| (prevrowyear == null || !prevrowyear.equals(currowyear))) {
					   Log.v("SEP", "NOW reached where prevdate is new");
					   Log.v("SEP", "prevdate sep="+String.valueOf(prevrowday));
					     daystr = prefixzero(currowdate);
		        		 monthstr = months(currowmonth);
		        		seper.setText(daystr+" "+monthstr+" "+String.valueOf(currowyear));
		
					  seper.setVisibility(View.VISIBLE);
					   
				   } else{
					   seper.setVisibility(View.INVISIBLE);
				   }
				}   
				//*****************************************************************************************
				//*****************************************************************************************
				
				// This section formats the date and time per record and padds single numbers with a leading zero .....
				
				// This is the day of the month
				TextView dayfield = (TextView)view.findViewById(R.id.noise_date_day_view);
				Integer daydataconv = cursor.getInt(cursor.getColumnIndex("noise_day"));
				String dayconv =prefixzero(daydataconv);
				dayfield.setText(dayconv);
				
				// This is the month of the year
				TextView monthfield = (TextView)view.findViewById(R.id.noise_date_month_view);    
				Integer monthdataconv = cursor.getInt(cursor.getColumnIndex("noise_month"));
				String monconv =prefixzero(monthdataconv);
			    monthfield.setText(monconv);
					
			    // This is the Hour of the day
				TextView hourfield = (TextView)view.findViewById(R.id.noise_time_hour_view);		
				Integer hourdataconv = cursor.getInt(cursor.getColumnIndex("noise_hour"));
				String hourconv =prefixzero(hourdataconv);			
				hourfield.setText(hourconv);
				
			
				// This is the minute of the day
				TextView minfield = (TextView)view.findViewById(R.id.noise_time_min_view);
				Integer mindataconv = cursor.getInt(cursor.getColumnIndex("noise_min"));
				String minconv =prefixzero(mindataconv);				
				minfield.setText(minconv);		
				
				
				
				// This is the second of the day
				TextView secfield = (TextView)view.findViewById(R.id.noise_time_sec_view);				
				Integer secdataconv = cursor.getInt(cursor.getColumnIndex("noise_second"));
				String secconv =prefixzero(secdataconv);
				secfield.setText(secconv);
				
				TableLayout tb1 = (TableLayout)view.findViewById(R.id.Table1);
				TableLayout tb2 = (TableLayout)view.findViewById(R.id.Table2);
				TableLayout tb3 = (TableLayout)view.findViewById(R.id.Table3);
				
				TableRow tbr1 = (TableRow)view.findViewById(R.id.tableRow1);
				TableRow tbr2 = (TableRow)view.findViewById(R.id.tableRow2);
				TableRow tbr3 = (TableRow)view.findViewById(R.id.tableRow3);
				
				LinearLayout ll = (LinearLayout)view.findViewById(R.id.row_root_layout);
				
				if (longrowclick1 == cursor.getPosition()  && !islongclickbefore) {
					tb1.setBackgroundResource(R.drawable.darkslateblue);
					tb2.setBackgroundResource(R.drawable.darkslateblue);
					tb3.setBackgroundResource(R.drawable.darkslateblue);
                    ll.setBackgroundResource(R.drawable.darkslateblue);
					tbr1.setBackgroundResource(R.drawable.darkslateblue);
					tbr2.setBackgroundResource(R.drawable.darkslateblue);
					tbr3.setBackgroundResource(R.drawable.darkslateblue);
					iconnoise.setBackgroundResource(R.drawable.darkslateblue);
					
					noisetype.setBackgroundResource(R.drawable.darkslateblue);
					//isblue = true;
				
					
			       } else  {
			    	   tb1.setBackgroundColor(Color.TRANSPARENT);
			    	   tb2.setBackgroundColor(Color.TRANSPARENT);
			    	   tb3.setBackgroundColor(Color.TRANSPARENT);
			    	   ll.setBackgroundColor(Color.TRANSPARENT);
			    	   tbr1.setBackgroundColor(Color.TRANSPARENT);
			    	   tbr2.setBackgroundColor(Color.TRANSPARENT);
			    	   tbr3.setBackgroundColor(Color.TRANSPARENT);
			    	   
			    	   iconnoise.setBackgroundColor(Color.TRANSPARENT);
						
						noisetype.setBackgroundColor(Color.TRANSPARENT);
			    	   
			    	  // isblue = false;
			    	  // posselc = 0;
			    	   
			       }
				
         
	} **/
	
	
	
	@Override
		public View getView(int position,View convertView, ViewGroup parent) {
	 //super.getView(position, convertView, parent); 
		Log.i("Record POS in GetView", "Pos="+position);
		Log.i("LongClickrow 1 in GetView", "LongClickRow1="+longrowclick1);
	    ViewHolder holder;
	    datacursor.moveToPosition(position);
	   
	//	View view =  super.getView(position, convertView, parent);  
	 View view = convertView;
	if (view == null) {
			
			LayoutInflater grow=getLayoutInflater();
			//grow = LayoutInflater.from(getBaseContext());
			view = grow.inflate(R.layout.viewdata,null);
			holder = new ViewHolder();
			holder.iconnoise = (ImageView)view.findViewById(R.id.noise_image_type);
			holder.noisetype = (TextView)view.findViewById(R.id.noise_type_view);
			holder.noisedesc = (TextView)view.findViewById(R.id.noise_info_view);
			holder.seper = (TextView)view.findViewById(R.id.seper);
			holder.dayfield = (TextView)view.findViewById(R.id.noise_date_day_view);
			holder.monthfield = (TextView)view.findViewById(R.id.noise_date_month_view);
			holder.yearfield = (TextView)view.findViewById(R.id.noise_date_year_view);
			holder.hourfield = (TextView)view.findViewById(R.id.noise_time_hour_view);
			holder.minfield = (TextView)view.findViewById(R.id.noise_time_min_view);
			holder.secfield = (TextView)view.findViewById(R.id.noise_time_sec_view);
			holder.tb1 = (TableLayout)view.findViewById(R.id.Table1);
			holder.tb2 = (TableLayout)view.findViewById(R.id.Table2);
			holder.tb3 = (TableLayout)view.findViewById(R.id.Table3);
			
			holder.tbr1 = (TableRow)view.findViewById(R.id.tableRow1);
			holder.tbr2 = (TableRow)view.findViewById(R.id.tableRow2);
			holder.tbr3 = (TableRow)view.findViewById(R.id.tableRow3);
			
			holder.ll = (LinearLayout)view.findViewById(R.id.row_root_layout);
			view.setTag(holder);
			
		} else {
			holder = (ViewHolder) view.getTag();
		}
		
	// Sets up the Image that relates to the noise
			//ImageView iconnoise = (ImageView)view.findViewById(R.id.noise_image_type);	
		    String imgreference = datacursor.getString(datacursor.getColumnIndex("noise_image_desc"));
		    int imgres = getResources().getIdentifier(imgreference, null, null);
		    holder.iconnoise.setImageResource(imgres);
		    
		    // Sets up the description relating to the noise
		    //TextView noisetype = (TextView)view.findViewById(R.id.noise_type_view);
		    Integer imgtext = datacursor.getInt(datacursor.getColumnIndex("noise_type_id"));
		    holder.noisetype.setText(vnoiseimage[imgtext]);
		    
		    holder.noisedesc.setText(datacursor.getString(datacursor.getColumnIndex("noise_info")));
		    
		    // Sets up the separator bar which shows the date in DD MMMMMMMMM YYYY format
		 //   TextView seper = (TextView)view.findViewById(R.id.seper);
	        Integer prevrowday = 0, prevrowmonth = 0 , prevrowyear=0;
	        Integer currowdate = datacursor.getInt(datacursor.getColumnIndex("noise_day"));
	        Integer currowmonth = datacursor.getInt(datacursor.getColumnIndex("noise_month"));
	        Integer currowyear = datacursor.getInt(datacursor.getColumnIndex("noise_year"));
	        Integer currdatesort = datacursor.getInt(datacursor.getColumnIndex("noise_date_sort"));
	        Log.v("NOISE DATE SORT: ", String.valueOf(currdatesort));
	        String daystr="",monthstr="";
	        holder.seper.setVisibility(View.INVISIBLE);
	        Log.v("SEP", "Reached separator");
	        if (datacursor.getPosition()==0 ) {
	        		 
	        		 daystr = prefixzero(currowdate);
	        		 monthstr = months(currowmonth);
	        		
	        		 holder.seper.setText(daystr+" "+monthstr+" "+String.valueOf(currowyear));
	        		 holder.seper.setVisibility(View.VISIBLE);
	        		 
	        	 }
	        	 Log.v("SEP", "currowdate="+String.valueOf(currowdate)+"; Record postion="+String.valueOf(datacursor.getPosition()));
					if (datacursor.getPosition()>0 && datacursor.moveToPrevious() ) {
				    	
					    prevrowday = datacursor.getInt(datacursor.getColumnIndex("noise_day"));
					    prevrowmonth = datacursor.getInt(datacursor.getColumnIndex("noise_month"));
					    prevrowyear =datacursor.getInt(datacursor.getColumnIndex("noise_year"));
					    Log.v("SEP", "prevrowdate="+String.valueOf(prevrowday)+"; Record postion="+String.valueOf(datacursor.getPosition()));
					    datacursor.moveToNext();
					
					   if ((prevrowday == null || !prevrowday.equals(currowdate)) || (prevrowmonth == null || !prevrowmonth.equals(currowmonth))|| (prevrowyear == null || !prevrowyear.equals(currowyear))) {
						   Log.v("SEP", "NOW reached where prevdate is new");
						   Log.v("SEP", "prevdate sep="+String.valueOf(prevrowday));
						     daystr = prefixzero(currowdate);
			        		 monthstr = months(currowmonth);
			        		 holder.seper.setText(daystr+" "+monthstr+" "+String.valueOf(currowyear));
			
			        		 holder.seper.setVisibility(View.VISIBLE);
						   
					   } else{
						   holder.seper.setVisibility(View.INVISIBLE);
					   }
					}   
					//*****************************************************************************************
					//*****************************************************************************************
					
					// This section formats the date and time per record and padds single numbers with a leading zero .....
					
					// This is the day of the month
					//TextView dayfield = (TextView)view.findViewById(R.id.noise_date_day_view);
					Integer daydataconv = datacursor.getInt(datacursor.getColumnIndex("noise_day"));
					String dayconv =prefixzero(daydataconv);
					holder.dayfield.setText(dayconv);
					
					// This is the month of the year
					//TextView monthfield = (TextView)view.findViewById(R.id.noise_date_month_view);    
					Integer monthdataconv = datacursor.getInt(datacursor.getColumnIndex("noise_month"));
					String monconv =prefixzero(monthdataconv);
				    holder.monthfield.setText(monconv);
						
				    // This is the Hour of the day
					//TextView hourfield = (TextView)view.findViewById(R.id.noise_time_hour_view);		
					Integer hourdataconv = datacursor.getInt(datacursor.getColumnIndex("noise_hour"));
					String hourconv =prefixzero(hourdataconv);			
					holder.hourfield.setText(hourconv);
					
					holder.yearfield.setText(Integer.toString(datacursor.getInt(datacursor.getColumnIndex("noise_year"))));
					
				
					// This is the minute of the day
					//TextView minfield = (TextView)view.findViewById(R.id.noise_time_min_view);
					Integer mindataconv = datacursor.getInt(datacursor.getColumnIndex("noise_min"));
					String minconv =prefixzero(mindataconv);				
					holder.minfield.setText(minconv);		
					
					
					
					// This is the second of the day
					//TextView secfield = (TextView)view.findViewById(R.id.noise_time_sec_view);				
					Integer secdataconv = datacursor.getInt(datacursor.getColumnIndex("noise_second"));
					String secconv =prefixzero(secdataconv);
					//String fulldate = Integer.toString(datacursor.getInt(datacursor.getColumnIndex("noise_date_sort")));
					holder.secfield.setText(secconv);
					
				/**	TableLayout tb1 = (TableLayout)view.findViewById(R.id.Table1);
					TableLayout tb2 = (TableLayout)view.findViewById(R.id.Table2);
					TableLayout tb3 = (TableLayout)view.findViewById(R.id.Table3);
					
					TableRow tbr1 = (TableRow)view.findViewById(R.id.tableRow1);
					TableRow tbr2 = (TableRow)view.findViewById(R.id.tableRow2);
					TableRow tbr3 = (TableRow)view.findViewById(R.id.tableRow3);
					
					LinearLayout ll = (LinearLayout)view.findViewById(R.id.row_root_layout); **/
					
					if (longrowclick1 == position  && !islongclickbefore) {
						//datacursor.moveToPosition(position);
						
						holder.ll.setBackgroundResource(0);
						holder.ll.setBackgroundResource(R.drawable.darkslateblue);
						holder.tb1.setBackgroundResource(0);
						holder.tb1.setBackgroundResource(R.drawable.darkslateblue);
						
						holder.tb2.setBackgroundResource(0);
						holder.tb2.setBackgroundResource(R.drawable.darkslateblue);
						
						holder.tb3.setBackgroundResource(0);
						holder.tb3.setBackgroundResource(R.drawable.darkslateblue);
						
						holder.tbr1.setBackgroundResource(0);
						holder.tbr1.setBackgroundResource(R.drawable.darkslateblue);
						
						holder.tbr2.setBackgroundResource(0);
						holder.tbr2.setBackgroundResource(R.drawable.darkslateblue);
						
						holder.tbr3.setBackgroundResource(0);
						holder.tbr3.setBackgroundResource(R.drawable.darkslateblue);
						
						
						holder.iconnoise.setBackgroundResource(0);
						holder.iconnoise.setBackgroundResource(R.drawable.darkslateblue);
						
						holder.noisedesc.setBackgroundResource(0);
						holder.noisedesc.setBackgroundResource(R.drawable.darkslateblue);
						
						holder.noisetype.setBackgroundResource(0);
						holder.noisetype.setBackgroundResource(R.drawable.darkslateblue);
						
						
					/**	holder.tb1.setBackgroundColor(Color.BLUE);
						holder.tb2.setBackgroundColor(Color.BLUE);
						holder.tb3.setBackgroundColor(Color.BLUE);
						holder.ll.setBackgroundColor(Color.BLUE);
						holder.tbr1.setBackgroundColor(Color.BLUE);
						holder.tbr2.setBackgroundColor(Color.BLUE);
						holder.tbr3.setBackgroundColor(Color.BLUE);
						holder.iconnoise.setBackgroundColor(Color.BLUE);
						  holder.noisedesc.setBackgroundColor(Color.BLUE);
						holder.noisetype.setBackgroundColor(Color.BLUE);  **/
					   
						 Log.i("GETVIEW_LONGROWCLICK=POSITION_ISLONGCLICKBEFORE=FALSE", "LONGROWCLICK="+longrowclick1+" isongclickbefore="+islongclickbefore+" Postion of Row= "+position);
						 
						 
						 
					
						
				       } else   {
				    	   holder.ll.setBackgroundColor(Color.TRANSPARENT);
				    	   
				    	   holder.tb1.setBackgroundColor(Color.TRANSPARENT);
				    	   holder.tb2.setBackgroundColor(Color.TRANSPARENT);
				    	   holder.tb3.setBackgroundColor(Color.TRANSPARENT);
				    	   holder.ll.setBackgroundColor(Color.TRANSPARENT);
				    	   holder.tbr1.setBackgroundColor(Color.TRANSPARENT);
				    	   holder.tbr2.setBackgroundColor(Color.TRANSPARENT);
				    	   holder.tbr3.setBackgroundColor(Color.TRANSPARENT);
				    	   holder.noisedesc.setBackgroundColor(Color.TRANSPARENT);
				    	   holder.iconnoise.setBackgroundColor(Color.TRANSPARENT);
				    	   holder.noisetype.setBackgroundColor(Color.TRANSPARENT); 
							
							Log.i("GETVIEW_LONGCLICKROW<>POSITION_ISLONGCLICKBEFORE=TRUE_OR_FALSE", "LONGROWCLICK="+longrowclick1+" isongclickbefore="+islongclickbefore+" Postion of Row= "+position);
				    	   
				       } /**else if (longrowclick1 == position  && islongclickbefore) {
					    	  holder.tb1.setBackgroundColor(Color.YELLOW);
					    	   holder.tb2.setBackgroundColor(Color.YELLOW);
					    	   holder.tb3.setBackgroundColor(Color.YELLOW);
					    	   holder.ll.setBackgroundColor(Color.YELLOW);
					    	   holder.tbr1.setBackgroundColor(Color.YELLOW);
					    	   holder.tbr2.setBackgroundColor(Color.YELLOW);
					    	   holder.tbr3.setBackgroundColor(Color.YELLOW);
					    	   holder.noisedesc.setBackgroundColor(Color.YELLOW);
					    	   holder.iconnoise.setBackgroundColor(Color.YELLOW);
								
								holder.noisetype.setBackgroundColor(Color.YELLOW); 
								
					    	 
					    	   
					       } **/
	    
		return view;
} 
		
		 /**
		  * if (islongclick) {
				Toast.makeText(getApplicationContext(), "Long Cick Reached Get View Method.... ", Toast.LENGTH_LONG).show();
				Toast.makeText(getApplicationContext(), "LongRowClick= "+Integer.toString(longrowclick) +"Long Row Click 1= "+Integer.toString(longrowclick1), Toast.LENGTH_LONG).show();
				if (!longrowclick.equals(-1) && longrowclick!=longrowclick1) {
					//mC.moveToPosition(longrowclick1);
					Toast.makeText(getApplicationContext(), "Long Cick Row - moving to previous row..... ", Toast.LENGTH_LONG).show();
				//  datalist.smoothScrollToPosition(longrowclick);
				   mC.moveToPosition(longrowclick);
				   ((TableLayout)v.findViewById(R.id.Table1)).setBackgroundColor(Color.BLACK);
					((TableLayout)v.findViewById(R.id.Table2)).setBackgroundColor(Color.BLACK);
					((TableLayout)v.findViewById(R.id.Table3)).setBackgroundColor(Color.BLACK);
				}
			//	datalist.smoothScrollToPosition(arg2);
				Toast.makeText(getApplicationContext(), "Second Version LongRowClick= "+Integer.toString(longrowclick) +"Long Row Click 1= "+Integer.toString(longrowclick1), Toast.LENGTH_LONG).show();
			//	mC.moveToPosition(longrowclick1);
				Toast.makeText(getApplicationContext(), " Adapter Pos = "+Integer.toString(mC.getPosition()) +"Long Row Click 1= "+Integer.toString(longrowclick1), Toast.LENGTH_LONG).show();
				
				if (position==longrowclick1 ) {
					
					mC.moveToPosition(longrowclick1);
					Toast.makeText(getApplicationContext(), "Now Marking Row with LongRowClick1= "+Integer.toString(longrowclick1) +"Now Marking row on Long Row Click 1= "+Integer.toString(longrowclick1), Toast.LENGTH_LONG).show();
				((TableLayout)v.findViewById(R.id.Table1)).setBackgroundResource(R.drawable.darkslateblue);
				((TableLayout)v.findViewById(R.id.Table2)).setBackgroundResource(R.drawable.darkslateblue);
				((TableLayout)v.findViewById(R.id.Table3)).setBackgroundResource(R.drawable.darkslateblue);
				} 
				longrowclick = longrowclick1;
				islongclick = false;
			}
		  *  
		  *  **/
		
		
	
	
	public void setlongpos (int longpos) {
		longrowclick1 = longpos;
		
		notifyDataSetChanged();
		
	}
	
	public void movetorecpos (int recpos) {
		
		notifyDataSetChanged();
	}
	
}
 



public String prefixzero(Integer number) {
	String result = Integer.toString(number);
  //  Log.d("PREFIX", "result starts with this = "+result);
    if (result.length() >1 ) {
  	 // Log.d("PREFIX", "NO ZEROES HERE");
  	 return Integer.toString(number);
  	 }
   	 
   String zeroprefix = "";
   zeroprefix = "0"+result;
  // Log.d("PREFIX", zeroprefix);
   
      return zeroprefix ;
}

/*public static String fill(String text) {
    if (text.length() >=10) {
        return text;
    }
    else 
        return "0"+ text;
}
*/



@Override
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	if (resultCode==Activity.RESULT_OK) {
	switch(requestCode)
	{
	case REQUEST_ADD:
		Integer reccount = data.getIntExtra("records", 0);
		if (reccount==1) { 
			Toast.makeText(this, "Only one record found", Toast.LENGTH_LONG).show();
		String info = data.getStringExtra("info"+Integer.toString(reccount));
		String image = data.getStringExtra("image"+Integer.toString(reccount));
		
		Integer type = data.getIntExtra("type"+Integer.toString(reccount),0);
		Integer hour = data.getIntExtra("hour"+Integer.toString(reccount), 0);
		//Log.d("REC", "Receiving Hour is"+Integer.toString(hour));
		Integer min = data.getIntExtra("min"+Integer.toString(reccount), 0);
		//Log.d("REC", "Receiving Minute is"+Integer.toString(min));
		Integer sec = data.getIntExtra("sec"+Integer.toString(reccount), 0);
		//Log.d("REC", "Receiving Second is"+Integer.toString(sec));
		Integer day = data.getIntExtra("day"+Integer.toString(reccount), 0);
		//Log.d("REC", "Receiving Day is"+Integer.toString(day));
		Integer month = data.getIntExtra("month"+Integer.toString(reccount), 0);
		//Log.d("REC", "Receiving Month is"+Integer.toString(month));
		Integer year = data.getIntExtra("year"+Integer.toString(reccount), 0);
		//Log.d("REC", "Receiving Year is"+Integer.toString(year));
		String noisedate = Integer.toString(year)+prefixzero(month)+prefixzero(day)+
				prefixzero(hour)+prefixzero(min)+prefixzero(sec);
		//Toast.makeText(this, "noisedate is "+noisedate, Toast.LENGTH_LONG).show();
		Long sortdate = Long.valueOf(noisedate);
		String inoisesortdate = Integer.toString(year)+prefixzero(month)+prefixzero(day);
		Long idatesort = Long.valueOf(inoisesortdate);
		mDBHelper.createLog(info, image, type, hour, min, sec, day, month, year,idatesort,sortdate);
	} else if (reccount>1) {
		Toast.makeText(this, "More than  one record found", Toast.LENGTH_LONG).show();
		Integer counter =1;
		while (counter<=reccount) {
			String infos = data.getStringExtra("info"+Integer.toString(counter));
			String images = data.getStringExtra("image"+Integer.toString(counter));
			
			Integer types = data.getIntExtra("type"+Integer.toString(counter),0);
			Integer hours = data.getIntExtra("hour"+Integer.toString(counter), 0);
			//Log.d("REC", "Receiving Hour is"+Integer.toString(hour));
			Integer mins = data.getIntExtra("min"+Integer.toString(counter), 0);
			//Log.d("REC", "Receiving Minute is"+Integer.toString(min));
			Integer secs = data.getIntExtra("sec"+Integer.toString(counter), 0);
			//Log.d("REC", "Receiving Second is"+Integer.toString(sec));
			Integer days = data.getIntExtra("day"+Integer.toString(counter), 0);
			//Log.d("REC", "Receiving Day is"+Integer.toString(day));
			Integer months = data.getIntExtra("month"+Integer.toString(counter), 0);
			//Log.d("REC", "Receiving Month is"+Integer.toString(month));
			Integer years = data.getIntExtra("year"+Integer.toString(counter), 0);
			//Log.d("REC", "Receiving Year is"+Integer.toString(year));
			String noisedate = Integer.toString(years)+prefixzero(months)+prefixzero(days)+
					prefixzero(hours)+prefixzero(mins)+prefixzero(secs);
			//Toast.makeText(this, "noisedate is "+noisedate, Toast.LENGTH_LONG).show();
			Long sortdate = Long.valueOf(noisedate);
			String inoisesortdate = Integer.toString(years)+prefixzero(months)+prefixzero(days);
			Long idatesort = Long.valueOf(inoisesortdate);
			mDBHelper.createLog(infos, images, types, hours, mins, secs, days, months, years,idatesort,sortdate);
			counter++;
		}
		
	}
		refreshList();
		
		break;
		
	case REQUEST_EDIT:
		
		String editinfo = data.getStringExtra("info1");
		String editimage = data.getStringExtra("image1");
		Integer edittype = data.getIntExtra("type1", 0);
		Integer edithour = data.getIntExtra("hour1", 0);
		Integer editmin = data.getIntExtra("min1", 0);
		Integer editsec = data.getIntExtra("sec1", 0);
		Integer editday = data.getIntExtra("day1", 0);
		Integer editmonth = data.getIntExtra("month1", 0);
		Integer edityear = data.getIntExtra("year1", 0);
		long updateId = data.getLongExtra("id", 0);
		String unoisedate = Integer.toString(edityear)+prefixzero(editmonth)+prefixzero(editday)+
				prefixzero(edithour)+prefixzero(editmin)+prefixzero(editsec);
		String unoisesortdate = Integer.toString(edityear)+prefixzero(editmonth)+prefixzero(editday);
		//Toast.makeText(this, "unoisedate is "+unoisedate, Toast.LENGTH_LONG).show();
		Long usortdate = Long.valueOf(unoisedate);
		Long udatesort = Long.valueOf(unoisesortdate);
		mDBHelper.updateLog(updateId, editinfo, editimage, edittype, edithour, editsec, editmin, editday, editmonth, edityear,udatesort,usortdate);
		
		refreshList();
		
		break;
	default:
		super.onActivityResult(requestCode, resultCode, data);
	}
 } else {
	 Toast.makeText(this, "Add / Update Record Cancelled", Toast.LENGTH_SHORT).show();
 }
}	


public String months(Integer monthin) {
	String monthout="";
	switch (monthin) {
	
	case 1:
		monthout = monthsofyear[0];
		break;
		
	case 2:
		monthout = monthsofyear[1];
		break;
	
	case 3:
		monthout = monthsofyear[2];
		break;
		
	case 4:
		monthout = monthsofyear[3];
		break;
		
	case 5:
		monthout = monthsofyear[4];
		break;
	
	case 6:
		monthout = monthsofyear[5];
		break;
		
	case 7:
		monthout = monthsofyear[6];
		break;
		
	case 8:
		monthout = monthsofyear[7];
		break;
	
	case 9:
		monthout = monthsofyear[8];
		break;
	
	case 10:
		monthout = monthsofyear[9];
		break;
	
	case 11:
		monthout = monthsofyear[10];
		break;
		
	case 12:
		monthout = monthsofyear[11];
		break;
	
	}
	
	return monthout;
	
}


public void jumptorec(Integer passmonth,Integer passyear) {
	 //movetopos = mDBHelper.getrecpos(5);
	 Log.i("JUMPPOS", "PassMonth= "+passmonth);
		Integer getposmonth = -1;
		Integer getposyear = -1;
		Integer month = passmonth;
		Integer yearm = passyear;
		Log.i("JUMPPOS", "Month= "+month);
		Log.i("JUMPPOS", "year= "+yearm );
		mC.moveToFirst();
		
		
 		while (!mC.isAfterLast() ) {
			getposmonth = mC.getInt(mC.getColumnIndex("noise_month"));
			getposyear = mC.getInt(mC.getColumnIndex("noise_year"));
			Log.i("JUMPPOS", "get pos year= "+getposyear);
			if (getposmonth==month  ) {
				if (getposyear.equals(yearm)) {
			    	movetopos = mC.getPosition(); 
				}
			}
			mC.moveToNext();
		} 
	
	if (!movetopos.equals(-1)) {
		//getmainlistadapter.datacursor.moveToPosition(2000);
		//refreshList();
		ListView getlistpos = getListView();
		getlistpos.setSelection(movetopos);
	
	} else {
		Toast.makeText(MainActivity.this, "No Records for this month or invalid month entered", Toast.LENGTH_LONG).show();
	}
	
}

public void searchnote() {
	final Dialog searchdialog = new Dialog(MainActivity.this);
	searchdialog.setContentView(R.layout.notessearch);
	searchdialog.setTitle("Search Notes");
    Button searchbtn = (Button)searchdialog.findViewById(R.id.searchnotes);
    Button csearchbtn = (Button)searchdialog.findViewById(R.id.cancelnotes);
    
    final EditText searchtxt = (EditText)searchdialog.findViewById(R.id.searchtext);
    
    searchbtn.setOnClickListener( new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			if (searchtxt.getText().toString().length()>0) {
				 snotes =  searchtxt.getText().toString();
				snotesflag = 1;
				refreshList();
				searchdialog.cancel();
			} else {
				Toast.makeText(MainActivity.this, "Notes Text Is Blank Please enter a search or cancel", Toast.LENGTH_LONG).show();
				searchtxt.requestFocus();
				
			}
		}});
    
    csearchbtn.setOnClickListener( new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			searchdialog.cancel();
		}});

    searchdialog.show();
}

public void entermonth() {
	final Dialog jumpmonthhdialog = new Dialog(MainActivity.this);
	jumpmonthhdialog.setContentView(R.layout.datemoveto);
	jumpmonthhdialog.setTitle("Jump to Month (Note: The day will be ignored)");
    Button jumpmhbtn = (Button)jumpmonthhdialog.findViewById(R.id.okdatemoveto);
    Button cjumpbtn = (Button)jumpmonthhdialog.findViewById(R.id.canceldatemoveto);
    
//    final EditText jumptxt = (EditText)jumpmonthhdialog.findViewById(R.id.entermonth);
   final DatePicker datepick = (DatePicker)jumpmonthhdialog.findViewById(R.id.datePicker1);
   
    jumpmhbtn.setOnClickListener( new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			
			
			// TODO Auto-generated method stub
		//	if (jumptxt.getText().toString().length()>2 || jumptxt.getText().toString().length()<1 ) {
			//	Toast.makeText(MainActivity.this, "Please Enter a valid month ", Toast.LENGTH_LONG).show();
				//jumptxt.requestFocus();
		//	} else if (jumptxt.getText().toString().length()<=2) {
				
			  Integer getmon = datepick.getMonth()+1;
			  Integer getyear = datepick.getYear();
			  
			  Log.i("getmon","Get Mon="+getmon);
			  Log.i("getYear", "Get Year ="+getyear);
			  
			  jumptorec(getmon,getyear);
			   
			/**	String strmonth = jumptxt.getText().toString();
				Integer getmonth = Integer.valueOf(strmonth);
				jumptorec(getmonth);**/
				jumpmonthhdialog.cancel();
				
				
				
	//		}
		}});
    
    cjumpbtn.setOnClickListener( new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			jumpmonthhdialog.cancel();
		}});

    jumpmonthhdialog.show();
}


public void filterdate() {
	
	final Dialog dialog = new Dialog(MainActivity.this);
	dialog.setContentView(R.layout.datefilter);
	dialog.setTitle("Please choose a date range");
	dialog.setCancelable(true);
	
	Button fromdate = (Button)dialog.findViewById(R.id.fromdate);
	Button todate = (Button)dialog.findViewById(R.id.todate);
	Button okfilter = (Button)dialog.findViewById(R.id.okfilter);
	Button cancelfilter = (Button)dialog.findViewById(R.id.cancelfilter);
	datefrom = (TextView)dialog.findViewById(R.id.datefrom);
	 dateto = (TextView)dialog.findViewById(R.id.dateto);
	 
	 final Long ffromd = Long.valueOf(fromdatefilter);
	 final Long ftod = Long.valueOf(todatefilter);
	 
	 
	 
	 okfilter.setOnClickListener(new OnClickListener() {

		@Override
		public void onClick(View arg0) {
	
			// TODO Auto-generated method stub
			
			if (ffromd <= ftod) {
				Toast.makeText(MainActivity.this, "THE FULL FROMDATE is LESSTHAN OR EQUAL TO THE FULL TODATE!", Toast.LENGTH_LONG).show();
				filtered = 3;
				refreshList();
				dialog.cancel();
			} else {
				Toast.makeText(MainActivity.this, "THE FULL FROMDATE IS GREATER THAN THE FULL TODATE - SORRY!!!", Toast.LENGTH_LONG).show();
				filtered = -1;
			}
//			
//			if (fromfilteryear <= tofilteryear) {
//				Toast.makeText(MainActivity.this, "From Year is LESS!! that to Year", Toast.LENGTH_LONG).show();
//				filtered = 1;
//				if (fromfiltermonth <= tofiltermonth || (fromfiltermonth >= tofiltermonth && fromfilteryear <= tofilteryear)) {
//					filtered = 2;	
//					Toast.makeText(MainActivity.this, "From Month is LESS!! that to Month", Toast.LENGTH_LONG).show();
//					if (fromfilterday <= tofilterday || (fromfilterday >= tofilterday && fromfiltermonth <= tofiltermonth && fromfilteryear <= tofilteryear)) {
//						filtered = 3;
//						Toast.makeText(MainActivity.this, "From Day is LESS!! that to Day", Toast.LENGTH_LONG).show();
//					} else {
//						Toast.makeText(MainActivity.this, "From Day is Greater that to Day", Toast.LENGTH_LONG).show();
//						filtered = -1;
//					}
//					
//					
//				} else {
//					Toast.makeText(MainActivity.this, "From Month is Greater that to Month", Toast.LENGTH_LONG).show();
//					filtered = -1;
//				}
//			  refreshList();
//			  dialog.cancel();
//			} else {
//				Toast.makeText(MainActivity.this, "From Date is Greater that to Date", Toast.LENGTH_LONG).show();
//				filtered = -1;
//			}
			
			
//			if (fromdatef > todatef) {
//				Toast.makeText(MainActivity.this, "From Date is Greater that to Date", Toast.LENGTH_LONG).show();
//				fromdatef = Long.valueOf("0");
//				todatef = Long.valueOf("0");
//			} else {
//				Toast.makeText(MainActivity.this, "From Date is LESS!! that to Date", Toast.LENGTH_LONG).show();
//			}
			
		} });
	 
	 todate.setOnClickListener(new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			Calendar filtertodate = Calendar.getInstance();
			tod = new DatePickerDialog(MainActivity.this, new DatePickHandler(), filtertodate.get(Calendar.YEAR), filtertodate.get(Calendar.MONTH), filtertodate.get(Calendar.DAY_OF_MONTH));
			filterflag = 2;
			tod.show();
		} });
	fromdate.setOnClickListener(new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			
			Calendar filterfromdate = Calendar.getInstance();
			fromd = new DatePickerDialog(MainActivity.this, new DatePickHandler(), filterfromdate.get(Calendar.YEAR), filterfromdate.get(Calendar.MONTH), filterfromdate.get(Calendar.DAY_OF_MONTH));
			filterflag = 1;
			fromd.show();
			
		}});
	
	cancelfilter.setOnClickListener(new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			
			dialog.cancel();
		}});
			
	dialog.show();
	
}
	

/*	public class MyCustomAdapter extends ArrayAdapter<String>{

		public MyCustomAdapter(Context context, int textViewResourceId,
		String[] objects) {
		super(context, textViewResourceId, objects);
		// TODO Auto-generated constructor stub
		}
		
		@Override
		public View getDropDownView(int position, View convertView,
		ViewGroup parent) {
		// TODO Auto-generated method stub
		return getCustomView(position, convertView, parent);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		return getCustomView(position, convertView, parent);
		}

		public View getCustomView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		//return super.getView(position, convertView, parent);

		LayoutInflater inflater=getLayoutInflater();
		View row=inflater.inflate(R.layout.spinner, parent, false);
		TextView label=(TextView)row.findViewById(R.id.noisetypetext);
		label.setText(noiseimage[position]);

		ImageView icon=(ImageView)row.findViewById(R.id.noisetypespinner);

		if (noiserefer[position]==R.drawable.shouticon48){
			icon.setImageResource(R.drawable.shouticon48);
			}else if (noiserefer[position]==R.drawable.dooricon48) {
			icon.setImageResource(R.drawable.dooricon48);
			}else if (noiserefer[position]==R.drawable.dooricon48) {
			icon.setImageResource(R.drawable.dooricon48);
			} else if (noiserefer[position]==R.drawable.loudicon48) {
			icon.setImageResource(R.drawable.loudicon48);
			}else if (noiserefer[position]==R.drawable.vac) {
			icon.setImageResource(R.drawable.vac);
			}else if (noiserefer[position]==R.drawable.tv) {
			icon.setImageResource(R.drawable.tv);
			}else if (noiserefer[position]==R.drawable.loudicon48) {
			icon.setImageResource(R.drawable.loudicon48);
			}

		
		
		
		if (noiseimage[position]=="Shouting"){
		icon.setImageResource(R.drawable.shouticon48);
		}else if (noiseimage[position]=="Baby Gate Bounced") {
		icon.setImageResource(R.drawable.dooricon48);
		}else if (noiseimage[position]=="Door Slammed") {
		icon.setImageResource(R.drawable.dooricon48);
		} else if (noiseimage[position]=="DIY") {
		icon.setImageResource(R.drawable.loudicon48);
		}else if (noiseimage[position]=="Hoovering") {
		icon.setImageResource(R.drawable.vac);
		}else if (noiseimage[position]=="TV Music Loud") {
		icon.setImageResource(R.drawable.tv);
		}else if (noiseimage[position]=="Other") {
		icon.setImageResource(R.drawable.loudicon48);
		}   
		
		return row;
		}

		
		

	}
	*/

private class DatePickHandler implements OnDateSetListener {

	@Override
	public void onDateSet(DatePicker view, int year, int monthOfYear,
			int dayOfMonth) {
		// TODO Auto-generated method stub
		filterday = dayOfMonth;
		filteryear = year;
		filtermonth = monthOfYear+1;
		if (filterflag == 1) {
		     datefrom.setText(prefixzero(filterday)+"/"+prefixzero(filtermonth)+"/"+prefixzero(filteryear));
		     fromdatefilter = Integer.toString(filteryear)+prefixzero(filtermonth)+prefixzero(filterday);
		     fromdatef = Long.valueOf(fromdatefilter);
		     Log.v("FROMDATEFILTER", "fromdef="+fromdatef);
		     fromfilterday = dayOfMonth;
		     fromfiltermonth = monthOfYear+1;
		     fromfilteryear = year;
		     filterflag = -1;
		     fromd.hide();
	    }
		if (filterflag == 2) {
		     dateto.setText(prefixzero(filterday)+"/"+prefixzero(filtermonth)+"/"+prefixzero(filteryear));
		     todatefilter = Integer.toString(filteryear)+prefixzero(filtermonth)+prefixzero(filterday);
		     todatef = Long.valueOf(todatefilter);
		     Log.v("TODATEFILTER", "tomdef="+todatef);
		     tofilterday = dayOfMonth;
		     tofiltermonth = monthOfYear+1;
		     tofilteryear = year;
		     filterflag = -1;
		     tod.hide();
	    }
		
		
		
	}
 }
	
@Override
public void onBackPressed() {
	
	rundialog(9);
	
	
}


}
