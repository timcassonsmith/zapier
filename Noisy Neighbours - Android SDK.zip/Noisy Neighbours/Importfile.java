package co.uk.shieldstothemax.blastedneighbours;

//import android.app.Activity;
import java.io.BufferedReader;
//import java.io.BufferedWriter;
import java.io.File;
//import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
//import java.io.FileWriter;
import java.io.IOException;
import android.os.AsyncTask;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Calendar;






import android.os.Bundle;
import android.os.Environment;
//import android.app.Activity;
import android.app.AlertDialog;
import android.app.ListActivity;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
//import android.widget.Toast;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;


import android.content.IntentFilter;

//import android.content.Intent;
import android.content.pm.ActivityInfo;


public class Importfile extends ListActivity  {
	 public DBAdapter importdata;
	 public Cursor importcursor;
	 Button oki,canceli;
	 Integer selectedrow = 0;
	 Integer currpos = -1;
	 Integer prevpos = -1;
	 Integer selpos = -1;
	 Boolean isbluebefore= false;
	 Integer dirchk = 0 , posselc = 0;
	 Boolean isblue = false;
	 String filenamei = "nuisance_log_";
	 String csvheadingsi = "noise type,noise notes,noise date,noise time";
	 String exti = ".csv";
	 String selectedfile = "",selectedext="",selectedfname = "";
	 String rooti;
	 String getcurpathi = "";
	 String[] importtypes = {"Shouting", "Baby Gate Bounced", "Door Slammed",
	    		"DIY", "Hoovering", "TV Music Loud","Kids Running", "Other", 
	    		  "Loud Sound","Very Loud Sound","Extremely Loud Sound"};
	 String impimgref = "co.uk.shieldstothemax.blastedneighbours:drawable/";
		String[] noisedrawableimp = {"shouticon48","babygate","dooricon48","hammer","vacuum","tv","kid","loudicon48",
				   "loud_speaker","very_loud_speaker","extremly_loud_speaker"};
		
	 TextView mypathi,rowtext;
	 AlertDialog importquit;
	 FileReader csvimport = null;
	 ProgressDialog importprogress;
	 private mDBProgressAsync mdbimport;
	 private List<String> itemi = null;
	 private List<String> pathi = null;
	 private List<String> fullpathi = null;
	 String readline = "";
	 String[] row = null;
	 String[] impdate = null;
	 String[] imptime = null;
	 Integer imptype = 0;
	 String impnotes= "";
	  Integer day = 0;
		 Integer month = 0;
		 Integer year = 0;
		  Integer hour = 0;
		 Integer min = 0;
		 Integer sec = 0;
		 String impdatetime = "";
		 Long impsortdatetime = null;
		 String impdates = "";
		 Long impsortdate = null;
		 BufferedReader csvbuf;
	 ArrayAdapter<String> fileListi = null;
	 private importbr myimportbr;
	Boolean iservicerunning = false;
	Boolean hasfinished = false;
	 FileListAdapter fl = null;
	 String rootdir = "";
	 Boolean quit =false;
	 AlertDialog quitimport,importfinished;
	 @Override
	    public void onCreate(Bundle savedInstanceState) {
		 super.onCreate(savedInstanceState);
	        setContentView(R.layout.filei);
	        
	        
	        
	       
	        
	        
	        
	        // Sets up TextView for the Path display
	        mypathi = (TextView)findViewById(R.id.pathi);
	        // Sets up the Textview for the rows in the list
	        rowtext = (TextView)findViewById(R.id.fname);
	        // Sets up the OK/Import button
	       oki = (Button)findViewById(R.id.oki);
	       // This is not enabled until the user selects a valid file.
	       oki.setEnabled(false);
	       // Creates a new ProgressDialog
	       importprogress = new ProgressDialog(Importfile.this);
	       
	       if (savedInstanceState != null ){
	    	   Boolean chk = savedInstanceState.getBoolean("RUNNING");
	    	   Boolean done = savedInstanceState.getBoolean("DONE");
	    	   quit = savedInstanceState.getBoolean("QUIT");
	    	  if (quit) {
	    		  quitimport= new AlertDialog.Builder(Importfile.this)
	 		     .setIcon(R.drawable.app_icon)
	 		     .setTitle("Quit Import")
	 		     .setMessage("Do you wish to quit the Import Routine?")
	 		     .setPositiveButton("YES", new DialogInterface.OnClickListener() {

	 				@Override
	 				public void onClick(DialogInterface arg0, int arg1) {
	 					// TODO Auto-generated method stub
	 					
	 					finish();
	 					
	 					
	 				}})
	 		     
	 		     .setNegativeButton("NO", new DialogInterface.OnClickListener() {
	 				
	 				@Override
	 				public void onClick(DialogInterface dialog, int which) {
	 					// TODO Auto-generated method stub
	 					dialog.dismiss();
	 				}
	 			})
	 		     
	 		     .show();  
	    		  
	    	  }
	       if (!importprogress.isShowing() && chk) {
	           // Stops the dialog from being cancelled
	    	   iservicerunning = true;
	           importprogress.setCancelable(false);
	           importprogress.setCanceledOnTouchOutside(false);
	           // Sets the style of the dialog box as a spinner
	           importprogress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
	        // Gives the dialog a title of what is happening
	           importprogress.setTitle("Import");
	       // Sets a message to inform the user of what is in progress
	            importprogress.setMessage("Import in Progress.. Please Wait... "); 
	            importprogress.show();
	           }
	       
	       
	       if (myimportbr == null && chk) {
				
				myimportbr = new importbr();
				  
				  //register BroadcastReceiver
				  IntentFilter intentFilter = new IntentFilter(ImpExpService.ACTION_MyIntentService);
				  intentFilter.addCategory(Intent.CATEGORY_DEFAULT);
				  registerReceiver(myimportbr, intentFilter);
				}
	       
	       if (done) {
	    	   hasfinished = true;
	    	   importfinished =   new AlertDialog.Builder(Importfile.this)
			     .setIcon(R.drawable.app_icon)
			     .setTitle("Import Complete")
			     .setMessage("Import has finished, returning to main application screen")
			     .setPositiveButton("OK", new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface arg0, int arg1) {
							// TODO Auto-generated method stub
							iservicerunning = false;
							hasfinished = false;
							finish();
							
							
						}})
				     
				     
				     
				     .show(); 
	    	   
	       }
	       
	       }
	       
	       importdata = new DBAdapter(Importfile.this);
	       
	       ListView lw = getListView();
	      
	       
	      
	       
	       lw.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				File fileci = new File(pathi.get(arg2));
				if (fileci.isDirectory())
				  {
					 dirchk = 1;
					 
					
				   if(fileci.canRead()){
					   Log.d("FILECI", fileci.getName());
					   String parentofarea = fileci.getParent();
					   Log.d("Parent of FilecCI", parentofarea);
					   Log.d("ROOTDIR PARENT", rootdir.substring(0, rootdir.lastIndexOf("/")));
					   if (!fileci.getParent().equals(rootdir.substring(0, rootdir.lastIndexOf("/")))) {
						   rootdir = fileci.getParent()+"/"+fileci.getName();
					      //rootdir = rootdir+"/"+fileci.getName();
					      Log.d("ROOTDIR_CHANGE", rootdir);
					      ((TextView)arg1).setBackgroundColor(Color.TRANSPARENT); 
					   }
				    getdiri(pathi.get(arg2));
				   
				    
				    oki.setEnabled(false);
				   }else{
				   new AlertDialog.Builder(Importfile.this)
				     .setIcon(R.drawable.quitapp)
				     .setTitle("[" + fileci.getName() + "] Cannot be accessed! Please try another folder")
				     .setPositiveButton("OK", null).show(); 
				   
				   } 
				  } else {
				  dirchk = 0;
				  if (selpos==arg2) {
					  isbluebefore = true;
					  posselc = arg2;
					  
					   fl.setSelectedPosition(selpos);
					   selpos = -1;
					   
				  } else {
					  selpos = arg2;
					  posselc = arg2;
					  isbluebefore = false;
					   fl.setSelectedPosition(selpos);
				  }
				  
				  
				  
				 

				//  posselc = arg2;
				 //  fl.setSelectedPosition(selpos);
			    File fileselected = new File(pathi.get(arg2));

			    selectedfile = fileselected.getName();

			    selectedext = selectedfile.substring(selectedfile.lastIndexOf("."), selectedfile.length());
			    selectedfname = selectedfile.substring(0, selectedfile.lastIndexOf("_")+1);
			    
		   if (selectedfname.equalsIgnoreCase(filenamei) || selectedext.equalsIgnoreCase(exti) ) {
			   if (!isbluebefore) {
 		         oki.setEnabled(true); 
 		         } else {
 		        	oki.setEnabled(false); 
 		         }
 	        }
		   
		   
		   if (!selectedext.equalsIgnoreCase(exti) || !selectedfname.equalsIgnoreCase(filenamei) ) {
	         	new AlertDialog.Builder(Importfile.this)
      	          .setIcon(R.drawable.quitapp)
       		      .setTitle("Incorrect File Type")
       		     .setMessage("Please choose a CSV/Comma Separated file which was exported from this App")
     		     .setPositiveButton("OK", null).show();
            	 ((TextView)arg1).setBackgroundColor(Color.TRANSPARENT); 
 
    			 oki.setEnabled(false);
    			 currpos = -1;
  			     selectedfile = "";
			    selectedext = "";
	    }

		   
		   
			     }
			}});
	       
	       oki.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
			
				// TODO This is where the filename and folder are used - this needs to change so that it is passed to the fragment
				try {
					 csvimport = new FileReader(getcurpathi+"/"+selectedfile);
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 csvbuf = new BufferedReader(csvimport);
				try {
					// moves on a line to ignore the headers
					csvbuf.readLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
							 
				     
				 //    importdata = importdata.open();
				 	
					new AlertDialog.Builder(Importfile.this)
	    	          .setIcon(R.drawable.exportcsv)
	     		      .setTitle("Import routine ")
	     		     .setMessage("This Will Delete all Current Records "+"\n"+"Do You Wish To Contine?")
	   		     .setPositiveButton("CONTINUE", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						
						// User has accepted that the current data will be delete...
					//	importdata.deleteAllLogs();
						
						// Starts the spinner dialog box to show that something is happening
						// importprogress.show();
						 // Creates the async object
					//	 mdbimport = new mDBProgressAsync();
						 // Starts the background task....
				///		 mdbimport.execute();
                      String servicefile = getcurpathi+"/"+selectedfile;
					  Intent intentMyIntentService = new Intent(Importfile.this,ImpExpService.class);
						  intentMyIntentService.putExtra("FILE",servicefile);
						  intentMyIntentService.putExtra("IMPEXP",1);
						  
						  startService(intentMyIntentService);
						  myimportbr = new importbr();
						  
						  //register BroadcastReceiver
						  IntentFilter intentFilter = new IntentFilter(ImpExpService.ACTION_MyIntentService);
						  intentFilter.addCategory(Intent.CATEGORY_DEFAULT);
						  registerReceiver(myimportbr, intentFilter);
						  iservicerunning = true;
						  importprogress.setCancelable(false);
					       importprogress.setCanceledOnTouchOutside(false);
					       // Sets the style of the dialog box as a spinner
					       importprogress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
					        // Gives the dialog a title of what is happening
					       importprogress.setTitle("Import");
					       // Sets a message to inform the user of what is in progress
					       importprogress.setMessage("Import in Progress.. Please Wait... "); 
						  importprogress.show();
						 
					}})
					
					.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							iservicerunning = false;
							dialog.cancel();
						}})
	   		     
	   		     .show();
					//importdata.close();
				    
				     
				    
//				     new AlertDialog.Builder(Importfile.this)
//	    	          .setIcon(R.drawable.app_icon3)
//	     		      .setTitle("Import Data ")
//	     		     .setMessage("Import Found So Far: " +"\n" +
//	     		      "Day = "+String.valueOf(day) +" Month = "+String.valueOf(month)+" Year = "+String.valueOf(year)+"\n"+
//	     		      "Hour = "+String.valueOf(hour)+" Minute = "+String.valueOf(min)+ " Seconds =  "+String.valueOf(sec)+"\n"+
//	     		      "Notes = "+impnotes + " Noise type code = "+String.valueOf(imptype) +" Desc = "+importtypes[imptype] 
//	     		    		 )
//	   		     .setPositiveButton("OK", null).show();
				     
				     
					
				
				
			} });
	       
	       
	       canceli = (Button)findViewById(R.id.canceli);
	       
	       canceli.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				quit = true;
				quitimport= new AlertDialog.Builder(Importfile.this)
			     .setIcon(R.drawable.app_icon)
			     .setTitle("Quit Import")
			     .setMessage("Do you wish to quit the Import Routine?")
			     .setPositiveButton("YES", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						// TODO Auto-generated method stub
						
						finish();
						
						
					}})
			     
			     .setNegativeButton("NO", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						dialog.dismiss();
					}
				})
			     
			     .show();  
				
				
			}
	       
	        
	 });
	       
	       rooti = Environment.getExternalStorageDirectory().getPath();
	       rootdir = Environment.getExternalStorageDirectory().getPath();
	     getdiri(rooti);  
     //getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);
	    // getListView().setSelector(R.drawable.selector);
 }
	 

	 
	 @Override
		protected void onSaveInstanceState(Bundle saved) {
		 if (iservicerunning) {
		    	saved.putBoolean("RUNNING", iservicerunning); 
			}
		 if (hasfinished) {
			 saved.putBoolean("DONE", hasfinished); 
			 importfinished.dismiss();
			}
		 if (quit) {
			 saved.putBoolean("QUIT", quit);
			 quitimport.dismiss();
		 }
			super.onSaveInstanceState(saved);
		}
	 
	 
	 
	public class importbr extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			String comp = intent.getStringExtra("FINISH");
			importprogress.dismiss();
			iservicerunning = false;
			hasfinished = true;
			if (comp.equals("DONE")) {
				importfinished =   new AlertDialog.Builder(Importfile.this)
				     .setIcon(R.drawable.app_icon)
				     .setTitle("Import Complete")
				     .setMessage("Import has finished, returning to main application screen")
				     .setPositiveButton("OK", new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface arg0, int arg1) {
							// TODO Auto-generated method stub
							iservicerunning = false;
							hasfinished = false;
							finish();
							
							
						}})
				     
				     
				     
				     .show(); 
				   
				   
			} else {
				   new AlertDialog.Builder(Importfile.this)
				     .setIcon(R.drawable.quitapp)
				     .setTitle("OOPS")
				     .setMessage("Something has gone horribly wrong :(")
				     .setPositiveButton("OK", null).show();
				   iservicerunning = false;
			
			}
			
		}
		
	}
	
	@Override
	 protected void onDestroy() {
	  super.onDestroy();
	  //un-register BroadcastReceiver
	  if (myimportbr != null) {
	  unregisterReceiver(myimportbr); 
	  }
	 }
	 
	 private void getdiri(String dirpathi) {
		 mypathi.setText("Current Folder:"+dirpathi);
		 getcurpathi = dirpathi;
		 itemi = new ArrayList<String>();
	     pathi = new ArrayList<String>();
	     fullpathi = new ArrayList<String>();
	     File fi = new File(dirpathi);
	     
	     File[] filesi = fi.listFiles();
	     
	     if(!dirpathi.equals(rooti))
	     {
	      itemi.add(rooti);
	      pathi.add(rooti);
	      itemi.add("../");
	      pathi.add(fi.getParent()); 
	     }
	     Arrays.sort(filesi, dirsort);
	     for(int i=0; i < filesi.length; i++)
	     {
	      File filei = filesi[i];
	   //   path.add(sortorder.get(i).toString());
	     // item.add(sortorder.get(i).toString()+ "/");
	      if(!filei.isHidden() && filei.canRead()){
	     
	          if(filei.isDirectory()){
	        	pathi.add(filei.getPath());
	            itemi.add(filei.getName() + "/");
	         
	          } else {
	        	  
	        	  itemi.add(filei.getName());
	        	  pathi.add(filei.getName());
	        	
	        	  
	          }
	      } 
	     }
//	    fileListi =
//	  	       new ArrayAdapter<String>(this, R.layout.row, itemi);
//	     
//	  	     setListAdapter(fileListi);  
	  	     
	  	 fl = new FileListAdapter(this,R.layout.row2,itemi);
	  	
	  	 setListAdapter(fl);
//	  	 
	  	     
	 }
	 
	 Comparator<? super File> dirsort = new Comparator<File>() {

         @Override
			public int compare(File arg0, File arg1) {
				// TODO Auto-generated method stub
				if (arg0.isDirectory()) {
					if (arg1.isDirectory()) {
						return String.valueOf(arg0.getName().toLowerCase()).compareTo(arg1.getName().toLowerCase());
					} else {
						return -1;
					}
				} else {
					if (arg1.isDirectory()) {
						return 1;
					} else {
						return String.valueOf(arg0.getName().toLowerCase()).compareTo(arg1.getName().toLowerCase());
					}
				}
			
			}
	    	
	    	
	    }; 
	 
	 @Override
	 public void onBackPressed() {
		 if (rootdir.equals(rooti)) {
			quit = true;
			quitimport= new AlertDialog.Builder(Importfile.this)
		     .setIcon(R.drawable.app_icon)
		     .setTitle("Quit Import")
		     .setMessage("Do you wish to quit the Import Routine?")
		     .setPositiveButton("YES", new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface arg0, int arg1) {
					// TODO Auto-generated method stub
					
					finish();
					
					
				}})
		     
		     .setNegativeButton("NO", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					dialog.dismiss();
				}
			})
		     
		     .show();  
			 //super.onBackPressed();
		 } else {
			 dirchk= 1;
			 //rowtext.setBackgroundColor(Color.TRANSPARENT); 
			 rootdir=rootdir.substring(0, rootdir.lastIndexOf("/"));
			 Log.d("ROOTDIR", rootdir);
			 getdiri(rootdir);
		 }
		 return;
	 }
//	 @Override
//	 protected void onListItemClick(ListView l, View v, int position, long id) {
//	  // TODO Auto-generated method stub
//	  File fileci = new File(pathi.get(position));
//	  //File filepath = new File(fullpathi.get(position));
////	  new AlertDialog.Builder(Exportfile.this)
////	     .setIcon(R.drawable.quitapp)
////	     .setTitle(file.getName() + "has been clicked !, absolute path="+file.getAbsolutePath())
////	     .setPositiveButton("OK", null).show(); 
//	  
//	//  Toast.makeText(Exportfile.this, "Position clicked:"+Integer.toString(position)+"\n"+"Details are ", Toast.LENGTH_LONG).show();
//	  //Toast.makeText(Exportfile.this, "Position clicked:"+Integer.toString(position), Toast.LENGTH_LONG).show();
//	  if (fileci.isDirectory())
//	  {
//		 // Toast.makeText(Exportfile.this, "Position clicked:"+Integer.toString(position)+" Is a directory!", Toast.LENGTH_LONG).show();
//	   if(fileci.canRead()){
//		   //Toast.makeText(Exportfile.this, "Position clicked:"+Integer.toString(position)+" Can be read!", Toast.LENGTH_LONG).show();
//	    getdiri(pathi.get(position));
//	    
//	    ((TextView)v).setBackgroundColor(Color.TRANSPARENT);
//	    oki.setEnabled(false);
//	   }else{
//	   new AlertDialog.Builder(Importfile.this)
//	     .setIcon(R.drawable.quitapp)
//	     .setTitle("[" + fileci.getName() + "] Cannot be accessed! Please try another folder")
//	     .setPositiveButton("OK", null).show(); 
//	   
//	   } 
//	  }	 else {
////		  if (currpos != -1 ) {
////			((ListView)l).smoothScrollToPosition(currpos);
////			 ((TextView)v).setBackgroundColor(Color.TRANSPARENT); 
////			 ((ListView)l).smoothScrollToPosition(position);
////			 selectedrow = 0;
////		  }
//		  
//		  
////		   if (selectedrow == 0) {
////		// ((TextView)v).setBackgroundColor(Color.rgb(0, 153, 204)); 
////		    selectedrow = 1;
////		    oki.setEnabled(true);
//		  // int selpos = position;
//		   // fl.setSelectedPosition(selpos);
////		    
////		    File fileselected = new File(pathi.get(currpos));
////		    //File pathselected = new File(fullpathi.get(currpos));
////		    selectedfile = fileselected.getName();
////		    //String selectedfilepath = pathselected.getPath();
////		    selectedext = selectedfile.substring(selectedfile.lastIndexOf("."), selectedfile.length());
////		    selectedfname = selectedfile.substring(0, selectedfile.lastIndexOf("_")+1);
////		    
//////		    if (selectedfname.equalsIgnoreCase(filenamei) || selectedext.equalsIgnoreCase(exti) ) {
////// 		    new AlertDialog.Builder(Importfile.this)
//////		     .setIcon(R.drawable.quitapp)
//////		     .setTitle("Correct Format File Clicked!!!!!")
//////		     .setMessage("[" + selectedfile + "] You have clicked on a file - how could you!"+"\n"+
//////		     "Extention of file is : "+selectedext+"\n" + "File Name Prefix is "+selectedfname)
//////		     .setPositiveButton("OK", null).show(); 
////// 		    }
//// 		    
////		    
////		    
////		    if (!selectedext.equalsIgnoreCase(exti)) {
////		    	new AlertDialog.Builder(Importfile.this)
////			     .setIcon(R.drawable.quitapp)
////			     .setTitle("Incorrect File Type")
////			     .setMessage("Please choose a CSV/Comma Separated file")
////			     .setPositiveButton("OK", null).show();
////		    //	 ((TextView)v).setBackgroundColor(Color.TRANSPARENT); 
////				 selectedrow = 0;
////				 oki.setEnabled(false);
////				 currpos = -1;
////				 selectedfile = "";
////				 selectedext = "";
////		    }
////		    
////		    if (!selectedfname.equalsIgnoreCase(filenamei)) {
////		    	new AlertDialog.Builder(Importfile.this)
////			     .setIcon(R.drawable.quitapp)
////			     .setTitle("Incorrect File Name")
////			     .setMessage("Please choose a file exported from This App")
////			     .setPositiveButton("OK", null).show();
////		    	// ((TextView)v).setBackgroundColor(Color.TRANSPARENT); 
////				 selectedrow = 0;
////				 oki.setEnabled(false);
////				 currpos = -1;
////				 selectedfile = "";
////				 selectedext = "";
////		    }
////			 
////
////		    
////		   } else {
////			 //  ((TextView)v).setBackgroundColor(Color.TRANSPARENT); 
////			    selectedrow = 0;
////			    oki.setEnabled(false);
////			    currpos = -1;
////			    selectedfile = "";
////			    selectedext = "";
////		   }
////		  new AlertDialog.Builder(Importfile.this)
////		     .setIcon(R.drawable.quitapp)
////		     .setTitle("File Clicked!!!!!")
////		     .setMessage("[" + fileci.getName() + "] You have clicked on a file - how could you!")
////		     .setPositiveButton("OK", null).show(); 
////		  oki.setEnabled(true);
//		  
//	  }
//	  
//	  
//	 }
	 
	 public class FileListAdapter extends ArrayAdapter<String>  {

		 private List<String> itemsll; 
      		

			public FileListAdapter(Context context, int row,
					List<String> iteml) {
				super(context,row,iteml);
				// TODO Auto-generated constructor stub
				this.itemsll = iteml;
			}

			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				
				View viewnull = convertView;
				if (viewnull == null) {
					LayoutInflater vrow;
					vrow = LayoutInflater.from(getContext());
					
					viewnull = vrow.inflate(R.layout.row2, null);
			
				}
				
				if (viewnull.getId()==R.id.fname) {
					File filedirimg = new File(pathi.get(position));
					if (filedirimg.isDirectory()) {
						//TextView rowdraw = (TextView)viewnull.findViewById(R.id.fname);
						Drawable dirimg = getContext().getResources().getDrawable(R.drawable.hammer);
						
						((TextView)viewnull).setCompoundDrawablesWithIntrinsicBounds(dirimg, null, null, null);;
						//rowdraw.setCompoundDrawables(dirimg, null, null, null);

					} else {
					Drawable fileimg = getContext().getResources().getDrawable(R.drawable.loud_speaker);
					((TextView)viewnull).setCompoundDrawablesWithIntrinsicBounds(fileimg, null, null, null);;
				}
				
					
				}
				String currow = 	itemsll.get(position);
				TextView rowtext = (TextView)viewnull.findViewById(R.id.fname);
				rowtext.setHeight(50);
				rowtext.setText(currow);
				
				
				if (currpos == position && dirchk == 0 && !isbluebefore) {
					((TextView)viewnull).setBackgroundColor(R.drawable.darkslateblue);
					//isblue = true;
				
					
			       } else  {
			    	   ((TextView)viewnull).setBackgroundColor(Color.TRANSPARENT);
			    	  // isblue = false;
			    	   posselc = 0;
			    	   
			       }
				
				
				return viewnull;	
				
				
			}
			
			

			

			public void setSelectedPosition( int pos )
		    {
		        currpos = pos; 
             
		        notifyDataSetChanged();
		    }
			
			  
		  }
	 
	 
	 public String impprefixzero(Integer number) {
			String result = Integer.toString(number);
		  //  Log.d("PREFIX", "result starts with this = "+result);
		    if (result.length() >1 ) {
		  	 // Log.d("PREFIX", "NO ZEROES HERE");
		  	 return Integer.toString(number);
		  	 }
		   	 
		   String zeroprefix = "";
		   zeroprefix = "0"+result;
		  // Log.d("PREFIX", zeroprefix);
		   
		      return zeroprefix ;
		}
	 
////	 @Override
////	 public void onDestroy() {
////		 super.onDestroy();
////		
////	 }
////	 
//	 @Override
//	 public void onResume()
// {
//		 super.onResume();
//		 if (mdbimport !=null) {
//		 mdbimport.execute();
//		 importprogress.show();
//		 }
//	 }	 
//////	 
//////	 
//	 @Override
//	 public void onPause() {
//		 super.onPause();
//		 if (mdbimport !=null) { 
//		 mdbimport.cancel(true);
//		importprogress.cancel();
//		importdata.deleteAllLogs();
//		 }
//	 }
////	 
//	 
	 
	 private class mDBProgressAsync extends AsyncTask<Void, Void, Void> {
        
		
		
        
		@Override
		protected Void doInBackground(Void... arg0) {
			// TODO Auto-generated method stub
			try {
				importdata.begint();
				while 	((readline = csvbuf.readLine()) != null && !mdbimport.isCancelled() ) {
					
					// read in the data and using the comma to split the fields up
					 row = readline.split(",");
					// read in the date and separate the values by the forward slash
					 if (row.length==4) {
						 imptype = Arrays.asList(importtypes).indexOf(row[0]);
						 impnotes = row[1];
				    	 impdate = row[2].split("/");
				    	 imptime = row[3].split(":");						        
				     } else {
				    	 imptype = Arrays.asList(importtypes).indexOf(row[0]);
				    	 for (Integer i=1; i<row.length;i++) {
				    		 if (!row[i].contains("/") || !row[i].contains(":")) { 
					    	       impnotes += row[i]; 
					    	      } else if (row[i].contains("/") ) {
					    	    	 impdate = row[i].split("/");
					    	      } else if (row[i].contains(":")) {
					    	    	 imptime = row[i].split(":");
					    	      }
				    	 }
				     }
				      day = Integer.valueOf(impdate[0].trim());
					  month = Integer.valueOf(impdate[1].trim());
					 year = Integer.valueOf(impdate[2].trim());
					   hour = Integer.valueOf(imptime[0].trim());
					 min = Integer.valueOf(imptime[1].trim());
					  sec = Integer.valueOf(imptime[2].trim());
					  impdatetime = Integer.toString(year)+impprefixzero(month)+impprefixzero(day)
							 +impprefixzero(hour)+impprefixzero(min)+impprefixzero(sec);
					  impsortdatetime = Long.valueOf(impdatetime);
					 impdates = Integer.toString(year)+impprefixzero(month)+impprefixzero(day);
					 impsortdate = Long.valueOf(impdates);
					importdata.createLog(impnotes, impimgref+noisedrawableimp[imptype].toString(), imptype, hour, min, sec, day, month, year, impsortdatetime, impsortdate);
				}
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			importdata.settSuc();
			importdata.endt();
			return null;
		}
		
		
		@Override
        protected void onPostExecute(Void result) { 
            super.onPostExecute(result);
            importcursor = importdata.allrecords();
            importprogress.cancel();
            new AlertDialog.Builder(Importfile.this)
		     .setIcon(R.drawable.exportcsv)
		     .setTitle("Import Completed ")
		     .setMessage("Import has finished. Imported "+String.valueOf(importcursor.getCount())+" Records"+"\n"+
		     "Do you want to return to main program?")
		     .setPositiveButton("YES", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
				importcursor.close();
				importdata.close();
					
				try {
					csvbuf.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finish();
				}
			})	
		    .setNegativeButton("NO", null)		 
		     
		     .show(); 
            
		}
	 }



	 
	
}
