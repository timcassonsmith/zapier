package co.uk.shieldstothemax.blastedneighbours;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
//import android.widget.Toast;

public class DBAdapter {
    private static final String DB_NAME = "Neighbours";
    private static final String DB_TABLE = "Log";
    private static final int DB_VERSION = 4;
    
    private static final String DB_CREATE = "CREATE TABLE IF NOT EXISTS "+DB_TABLE+ 
    		    " (_id INTEGER PRIMARY KEY AUTOINCREMENT, " + 
    		           "noise_type_id INTEGER, " +" noise_hour INTEGER, " + 
    		             "noise_min INTEGER , " +" noise_info VARCHAR,"+"noise_image_desc VARCHAR, "+ 
    		           "noise_day INTEGER, "+"noise_month INTEGER,  "+ "noise_year INTEGER,"+" noise_second INTEGER,noise_date_sort INTEGER ,noise_date INTEGER NOT NULL "+");" ;
    
    //private static final String DB_UPGRADE = 
    	//	"DROP TABLE IF EXISTS Log";
    	public static final String COL_NOISE_TYPE = "noise_type_id";
    	public static final String COL_NOISE_HOUR = "noise_hour";
    	public static final String COL_NOISE_MIN = "noise_min";
    	public static final String COL_NOISE_SEC = "noise_second";
    	public static final String COL_NOISE_IMAGE = "noise_image_desc";
    	
    	public static final String COL_NOISE_DAY = "noise_day";
    	public static final String COL_NOISE_MON = "noise_month";
    	public static final String COL_NOISE_YEAR = "noise_year";
    	public static final String COL_NOISE_DATE = "noise_date";
    	public static final String COL_NOISE_SORT_DATE = "noise_date_sort";
    	public static final String COL_NOISE_INFO = "noise_info";	
    	public static final String COL_ID = "_id";
    	
    	private SQLiteDatabase mDB;
    	private DBHelper mDBHelper;
    	private Context mCtx;
    	
    	private static class DBHelper extends SQLiteOpenHelper{
    		public DBHelper(Context context) {
    			super(context, DB_NAME, null, DB_VERSION);
    		}

    		@Override
    		public void onCreate(SQLiteDatabase db) {
    			db.execSQL(DB_CREATE);
    			
    		}

    		@Override
    		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    			Log.v("OLDDBVERSION", "Old version="+String.valueOf(oldVersion));
    			Log.v("NEWDBVERSION", "New version="+String.valueOf(newVersion));
    		/**	if (newVersion>oldVersion) {
    				String indexcreate = null;
    				indexcreate = "create Index id_date_sort_idx ON Log(noise_date_sort)  ";
    				if (indexcreate!=null) {
    					db.execSQL(indexcreate);
    				
    				
    				}
    			} **/
    			
    			if (newVersion==5) {
    				String dateupdatesql = null;
    				dateupdatesql = "";
    			}
    			
//    			//String upgradesql = null;
//    			String populatesql = null;
//    			if (newVersion==1) {
//    				//upgradesql = "alter table " +DB_TABLE + " add COLUMN noise_date_sort INTEGER;";
//    				//populatesql = "update "+ DB_TABLE +" set noise_date_sort="+COL_NOISE_YEAR +" || " +prefixfieldzero(COL_NOISE_MON) + " || " + prefixfieldzero(COL_NOISE_DAY);
//    				populatesql = "update "+DB_TABLE + " set noise_date_sort = (select noise_year || substr('00' || noise_month, -2, 2  ) || substr('00' || noise_day, -2 ,2)  from "+DB_TABLE+" AS LogTemp2 where "+DB_TABLE+"._id=LogTemp2._id)   "  ; 
//                 //populatesql = "update "+ DB_TABLE +" set noise_date_sort= "+getDateStr(COL_NOISE_YEAR,COL_NOISE_MON,COL_NOISE_DAY);   				
//    			}
//    			if (populatesql !=null) {
//    				//db.execSQL(upgradesql);    			
//    				if (populatesql !=null) {
//    					
//    					db.execSQL(populatesql);
//    				}
//    			}
//
////    			//db.execSQL(DB_UPGRADE);
////    			//onCreate(db);
////    		}		
    	} 
   }
    	
    	public void begint() {
    		try {
    			mDB.beginTransaction();
    			
    		} 	catch (Exception e) {
    			Log.w("Error", e.getMessage());
    		}
    	}
    	
    	
    	public void endt() {
    		try {
    			mDB.endTransaction();
    		} 	catch (Exception e) {
    			Log.w("Error", e.getMessage());
    		}
    	}
    	
    	public void settSuc() {
    		try {
    			mDB.setTransactionSuccessful();
    		} 	catch (Exception e) {
    			Log.w("Error", e.getMessage());
    		}
    	}
    	
    	
    	public DBAdapter(Context ctx)
    	{
    		this.mCtx = ctx;
    	}
    	
    	//OPEN METHOD AND CLOSE METHOD
    	public DBAdapter open()
    	{
    		mDBHelper = new DBHelper(mCtx);
    		mDB = mDBHelper.getWritableDatabase(); //important
    		return this;
    	}
    	
    	public void close()
    	{
    		mDBHelper.close();
    	}
    	
    	//INSERT AND DELETE
    	public long createLog(String info,String image, Integer type,Integer hour,Integer mins,Integer sec,Integer day,Integer month,Integer year,Long sortdate,Long noisedate)
    	{
    		ContentValues v = new ContentValues();
    		v.put(COL_NOISE_TYPE, type);
    		v.put(COL_NOISE_INFO, info);
    		v.put(COL_NOISE_IMAGE, image);
    		v.put(COL_NOISE_HOUR, hour);
    		v.put(COL_NOISE_SEC, sec);
    		v.put(COL_NOISE_MIN, mins);
    		v.put(COL_NOISE_DAY, day);
    		v.put(COL_NOISE_MON, month);
    		v.put(COL_NOISE_YEAR, year);
    		v.put(COL_NOISE_DATE, noisedate);
    		v.put(COL_NOISE_SORT_DATE, sortdate);
    	
    		return mDB.insert(DB_TABLE, null, v);
    	}
    	
    	public boolean deleteLogRec(long id)
    	{
    		return mDB.delete(DB_TABLE, COL_ID + "="+ id, null)>0;
    	}
    	
    	public boolean deleteAllLogs()
    	{
    		return mDB.delete(DB_TABLE, null, null)>0;
    	}
    	
    	public Cursor searchnotes(String notes) {
    		Log.i("DBNOTES", notes);
    		return mDB.query(DB_TABLE, new String[] {COL_ID, COL_NOISE_TYPE,COL_NOISE_IMAGE, COL_NOISE_INFO,COL_NOISE_IMAGE,COL_NOISE_HOUR,COL_NOISE_SEC,COL_NOISE_MIN,COL_NOISE_DAY,COL_NOISE_MON,COL_NOISE_YEAR,COL_NOISE_SORT_DATE},
					" noise_info like "+"'%"+notes+"%'"  , null, null, null,"noise_date_sort DESC");
    		
    	}
    	
    	public Integer getrecpos(Integer month) {
    		Log.i("DBMONTH", "Month = "+month);
    		Integer getpos = -1;
    		Integer getposmonth= -1;;
    		Cursor pos = mDB.query(DB_TABLE, new String[] {COL_ID, COL_NOISE_TYPE,COL_NOISE_IMAGE, COL_NOISE_INFO,COL_NOISE_IMAGE,COL_NOISE_HOUR,COL_NOISE_SEC,COL_NOISE_MIN,COL_NOISE_DAY,COL_NOISE_MON,COL_NOISE_YEAR,COL_NOISE_SORT_DATE},
					null , null, null, null," _id ASC");
    		pos.moveToFirst();
    		while (!pos.isLast() || getposmonth==month  ) {
    			getposmonth = pos.getInt(pos.getColumnIndex("noise_month"));
    			if (getposmonth==month) {
    				getpos = pos.getPosition();
    			}
    			pos.moveToNext();
    		}
    		
    		Log.i("DBMONTH", "Pos Month = "+getposmonth);
    		Log.i("DBPOS", "POS  = "+getpos);
    		return getpos;
    	}
    	
    	//get all bookmark
    	public Cursor GetAllLogs(Integer i,String sortfield)
    	{
    		String sorted = "";
    		if (i == 1 ) {
    			sorted = "DESC";
    		} else if (i == 2) {
    			sorted = "ASC";
    		} 
    		
    		
    		return mDB.query(DB_TABLE, new String[] {COL_ID, COL_NOISE_TYPE,COL_NOISE_IMAGE, COL_NOISE_INFO,COL_NOISE_IMAGE,COL_NOISE_HOUR,COL_NOISE_SEC,COL_NOISE_MIN,COL_NOISE_DAY,COL_NOISE_MON,COL_NOISE_YEAR,COL_NOISE_SORT_DATE},
    						null, null, null, null, COL_ID+" "+sorted);
    	}
    	
    	public Cursor allrecords() {
    		
    		return mDB.query(DB_TABLE, new String[] {COL_ID, COL_NOISE_TYPE,COL_NOISE_IMAGE, COL_NOISE_INFO,COL_NOISE_IMAGE,COL_NOISE_HOUR,COL_NOISE_SEC,COL_NOISE_MIN,COL_NOISE_DAY,COL_NOISE_MON,COL_NOISE_YEAR,COL_NOISE_SORT_DATE},
					null, null, null, null, null);
    	}
    	
    	// Used to show the Top noises recorded 
       public Cursor topnoises() {
    	   
    	   return mDB.rawQuery("select  count(noise_type_id) as topnoise,noise_type_id,noise_image_desc,_id from Log group by noise_type_id order by topnoise DESC", null);
    		
    	
    	}
       // By the noise given , counts how many records there are
       public Cursor topnoise(int noiseid) {
    	   
    	   return mDB.rawQuery("select noise_type_id,noise_image_desc,_id from Log where noise_type_id="+Integer.toString(noiseid)+"  ", null);
    		
    	
    	}
       
       // Used when a noise is selected and gives the month with the most amounts of that noise
        public Cursor topnoise_month(int noiseid) {
    	   
    	   return mDB.rawQuery("select count(noise_month) as topnoisemonth,noise_month,noise_type_id,noise_image_desc,_id from Log where noise_type_id="+String.valueOf(noiseid)+" group by noise_month order by topnoisemonth DESC limit 1 ", null);
    		
    	
    	}
       // Shows The Top Months where the most noise has happen .
       public Cursor topmonths() {
   		
    	   return mDB.rawQuery("select  count(noise_month) as topmonth,noise_month,noise_year,_id from Log group by noise_month order by topmonth DESC", null);
    	   
   		
   	}
       // Counts how many records of noises there are based on the month / year selected .
       public Cursor monthcount(int month,int year) {
      		
    	   return mDB.rawQuery("select noise_month,noise_year,_id from Log where noise_month="+Integer.toString(month)+" and noise_year="+Integer.toString(year), null);
    	   
   		
   	}  
       
    // Counts the top noise there is based on the month / year selected .
       public Cursor noisemonthcount(int month,int year) {
      		
    	   return mDB.rawQuery("select count(noise_type_id) as noisecount,noise_type_id,noise_month,noise_year,_id from Log where noise_month="+Integer.toString(month)+" and noise_year="+Integer.toString(year)+" group by noise_type_id order by noisecount DESC limit 1 ", null);
    	   
   		
   	}  
    	
    	public Cursor GetDateFilter(Integer fromday,Integer frommonth,Integer fromyear, Integer tooday,Integer tomonth, Integer toyear) {
//    		
//    		Log.v("DATEFROM_DB", "dateFrom="+Long.toString(datefrom));
//    		Log.v("DATEFTO_DB", "dateTo="+Long.toString(dateto));
    		
    		Log.v("FROM DATE DD MM YY", Integer.toString(fromday) +" "+Integer.toString(frommonth)+" "+Integer.toString(fromyear));
    		Log.v("TO DATE DD MM YY", Integer.toString(tooday) +" "+Integer.toString(tomonth)+" "+Integer.toString(toyear));
    		
//    		return mDB.query(DB_TABLE, new String[] {COL_ID, COL_NOISE_TYPE,COL_NOISE_IMAGE, COL_NOISE_INFO,COL_NOISE_IMAGE,COL_NOISE_HOUR,COL_NOISE_SEC,COL_NOISE_MIN,COL_NOISE_DAY,COL_NOISE_MON,COL_NOISE_YEAR,COL_NOISE_SORT_DATE},
//					" noise_day BETWEEN "+Integer.toString(fromday)+" AND "+Integer.valueOf(today)+" " +
//							"AND noise_month BETWEEN "+Integer.toString(frommonth)+" AND "+Integer.toString(tomonth) +" " +
//							  "AND noise_year BETWEEN "+Integer.toString(fromyear) +" AND "+Integer.toString(toyear)+" "  , null, null, null, "noise_date_sort DESC");
    		
    		return mDB.query(DB_TABLE, new String[] {COL_ID, COL_NOISE_TYPE,COL_NOISE_IMAGE, COL_NOISE_INFO,COL_NOISE_IMAGE,COL_NOISE_HOUR,COL_NOISE_SEC,COL_NOISE_MIN,COL_NOISE_DAY,COL_NOISE_MON,COL_NOISE_YEAR,COL_NOISE_SORT_DATE},
					" (noise_year,noise_month,noise_day) >= ("+Integer.valueOf(fromyear)+","+Integer.valueOf(frommonth)+","+Integer.valueOf(fromday)+")"+
    		            " AND (noise_year,noise_month,noise_day) <= ("+Integer.valueOf(toyear)+","+Integer.valueOf(tomonth)+","+Integer.valueOf(tooday)+")"
							+" "  , null, null, null, "noise_date_sort DESC");
    		
//    		return mDB.query(DB_TABLE, new String[] {COL_ID, COL_NOISE_TYPE,COL_NOISE_IMAGE, COL_NOISE_INFO,COL_NOISE_IMAGE,COL_NOISE_HOUR,COL_NOISE_SEC,COL_NOISE_MIN,COL_NOISE_DAY,COL_NOISE_MON,COL_NOISE_YEAR,COL_NOISE_SORT_DATE},
//					" noise_year >="+Integer.valueOf(fromyear)+" AND noise_year <="+Integer.valueOf(toyear)+" " +
//							"AND noise_month >="+Integer.valueOf(frommonth)+" AND noise_month <="+Integer.valueOf(tomonth) +" " +
//							  "AND noise_day <="+Integer.valueOf(fromday)+" "  , null, null, null, "noise_date_sort DESC");
    	}
    	
    	
    	public Cursor gdf(Integer fromd,Integer tooday) {
    		
    		return mDB.query(DB_TABLE, new String[] {COL_ID, COL_NOISE_TYPE,COL_NOISE_IMAGE, COL_NOISE_INFO,COL_NOISE_IMAGE,COL_NOISE_HOUR,COL_NOISE_SEC,COL_NOISE_MIN,COL_NOISE_DAY,COL_NOISE_MON,COL_NOISE_YEAR,COL_NOISE_SORT_DATE},
					" noise_date_sort BETWEEN "+Integer.valueOf(fromd)+" AND "+Integer.valueOf(tooday)  , null, null, null, "noise_date_sort DESC");
    	}
    	
       public Cursor gdfl(Long fromd,Long tooday) {
    		
    		return mDB.query(DB_TABLE, new String[] {COL_ID, COL_NOISE_TYPE,COL_NOISE_IMAGE, COL_NOISE_INFO,COL_NOISE_IMAGE,COL_NOISE_HOUR,COL_NOISE_SEC,COL_NOISE_MIN,COL_NOISE_DAY,COL_NOISE_MON,COL_NOISE_YEAR,COL_NOISE_SORT_DATE},
					" noise_date_sort BETWEEN "+Long.valueOf(fromd)+" AND "+Long.valueOf(tooday)  , null, null, null, "noise_date_sort DESC");
    	}
    	
    	//get a specific bookmark by id
    	public Cursor getLog(long id)
    	{
    		Cursor mCursor = mDB.query(true, DB_TABLE, new String[] {COL_ID, COL_NOISE_TYPE,COL_NOISE_IMAGE, COL_NOISE_INFO,COL_NOISE_IMAGE,COL_NOISE_HOUR,COL_NOISE_SEC,COL_NOISE_MIN,COL_NOISE_DAY,COL_NOISE_MON,COL_NOISE_YEAR},
    				COL_ID + "=" + id,
    				null, null, null, null, null);
    	
    		if (mCursor!=null)
    			mCursor.moveToFirst();
    		return mCursor;
    	}
    	
    	//finally update the bookmark
    	public boolean updateLog(long id, String uinfo, String uimage,Integer utype,Integer uhour,Integer usec,Integer umin,Integer uday,Integer umonth,Integer uyear,Long unoisesortdate,Long unoisedate)
    	{
    		ContentValues v = new ContentValues();
    		v.put(COL_NOISE_TYPE, utype);
    		v.put(COL_NOISE_INFO, uinfo);
    		v.put(COL_NOISE_IMAGE, uimage);
    		v.put(COL_NOISE_HOUR, uhour);
    		v.put(COL_NOISE_SEC, usec);
    		v.put(COL_NOISE_MIN, umin);
    		v.put(COL_NOISE_DAY, uday);
    		v.put(COL_NOISE_MON, umonth);
    		v.put(COL_NOISE_YEAR, uyear);
    	    v.put(COL_NOISE_DATE, unoisedate);
    	    v.put(COL_NOISE_SORT_DATE, unoisesortdate);
    	    //unoisesortdate
    		return mDB.update(DB_TABLE, v, COL_ID + "=" + id, null) > 0;
    	}	
    
    	public static String prefixfieldzero(String number) {
    		String result = String.valueOf(number);
    	  //  Log.d("PREFIX", "result starts with this = "+result);
    	    if (result.length() >1 ) {
    	  	 // Log.d("PREFIX", "NO ZEROES HERE");
    	  	 return number;
    	  	 }
    	   	 
    	   String zerofieldprefix = "";
    	   zerofieldprefix = "0"+result;
    	  // Log.d("PREFIX", zeroprefix);
    	   
    	      return zerofieldprefix ;
    	}
    	
    public static String getDateStr(String year, String month,String day) {
            return year+ prefixfieldzero(month)+ prefixfieldzero(day);
         }

    	
}
