package co.uk.shieldstothemax.blastedneighbours;

import android.content.Context;

import java.util.Calendar;


public class AppWidgetDB {

	 public void widgetnoiseupdate(Context ctx,Integer widgetnoisetype) {
		 DBAdapter database;
		 String drawloc = "co.uk.shieldstothemax.blastedneighbours:drawable/";
		 String noise_desc = "";
		 String noise_img = "";
		 
		
		 
		 switch (widgetnoisetype) {
		 
		   case 0:
				noise_img ="shouticon48";
			   	noise_desc = "Widget Shouting Noise";
			 break;
		   
		   case 1:
				noise_img ="babygate";
			   	noise_desc = "Widget Baby Gate Bounced Noise";
			 break;
			 
		   case 2:
				noise_img ="dooricon48";
			   	noise_desc = "Widget Door Slamming Noise";
			 break;
		   case 3:
				noise_img ="hammer";
			   	noise_desc = "Widget DIY Noise";
			 break;
		   case 4:
				noise_img ="vacuum";
			   	noise_desc = "Widget Vacuuming Noise";
			 break;		
		   
		   case 5:
				noise_img ="tv";
			   	noise_desc = "Widget TV / Music Noise";
		     break;
		   case 6:
			   	noise_img ="kid";
			   	noise_desc = "Widget Kid Noise";
			break;
			
		   case 7:
				noise_img ="bungeespydaquestion";
			   	noise_desc = "Widget Other Noise";
			 break;
			 
		   case 8:
				noise_img ="loud_speaker";
			   	noise_desc = "Widget Loud Noise";
			 break;
			 
		   case 9:
				noise_img ="very_loud_speaker";
			   	noise_desc = "Widget Very Loud Noise";
			 break;
			 
		   case 10:
				noise_img ="extremly_loud_speaker";
			   	noise_desc = "Widget Extremely Loud Noise";
			 break;
		 }
		
		 database = new DBAdapter(ctx);
		 database = database.open();
        
		 Calendar widgetcal = Calendar.getInstance();
		 String widgethour = String.valueOf(widgetcal.get(Calendar.HOUR_OF_DAY));
		 if (widgethour.length()<=1) {
			 widgethour = "0"+widgethour;
		 }
		 
		 String widgetmin = String.valueOf(widgetcal.get(Calendar.MINUTE));
		 if (widgetmin.length()<=1) {
			 widgetmin = "0"+widgetmin;
		 }
		 String widgetsec = String.valueOf(widgetcal.get(Calendar.SECOND));
		 if (widgetsec.length()<=1) {
			 widgetsec = "0"+widgetsec;
		 }
		 String widgetday = String.valueOf(widgetcal.get(Calendar.DAY_OF_MONTH));
		 if (widgetday.length()<=1) {
			 widgetday = "0"+widgetday;
		 }
		 
		 String widgetmon = String.valueOf(widgetcal.get(Calendar.MONTH)+1);
		 if (widgetmon.length()<=1) {
			 widgetmon = "0"+widgetmon;
		 }
		 String widgetyear = String.valueOf(widgetcal.get(Calendar.YEAR));
		 
		 String longdate = widgetyear+widgetmon+widgetday+widgethour+widgetmin+widgetsec;
		 String sortlongdate = widgetyear+widgetmon+widgetday;
		 Long widgetnoisedate = Long.valueOf(longdate);
		 Long widgetsortnoisedate = Long.valueOf(sortlongdate);
		 database.createLog(noise_desc,drawloc+noise_img, widgetnoisetype, Integer.valueOf(widgethour), Integer.valueOf(widgetmin), Integer.valueOf(widgetsec), Integer.valueOf(widgetday), Integer.valueOf(widgetmon), Integer.valueOf(widgetyear) ,widgetsortnoisedate,widgetnoisedate);
	     database.close();
		 
	 }
	
	
}
