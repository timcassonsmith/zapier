package co.uk.shieldstothemax.blastedneighbours;

import android.app.PendingIntent;
import android.appwidget.AppWidgetProvider;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import android.widget.Toast;

public class BnWidgetClass1 extends AppWidgetProvider {

	public static String ACTION_WIDGET_VAC_CLICK = "CLICK_VAC";
	public static String ACTION_WIDGET_DOOR_CLICK = "CLICK_DOOR";
	public static String ACTION_WIDGET_BABYG_CLICK = "CLICK_BABYG";
	public static String ACTION_WIDGET_OTHER_CLICK = "CLICK_OTHER";
	@Override
	public void onReceive(Context ctx,Intent intent)
	{
		 AppWidgetDB wnu1 = new AppWidgetDB();
		
		
		
		  
			 if (intent.getAction().equals(ACTION_WIDGET_VAC_CLICK)) {
				 Toast.makeText(ctx, "Vacuuming Noise Logged", Toast.LENGTH_LONG).show();
				
				 wnu1.widgetnoiseupdate(ctx,4);
			 } else {
				 super.onReceive(ctx, intent);
			 }
			 
			 if (intent.getAction().equals(ACTION_WIDGET_DOOR_CLICK)) {
				 Toast.makeText(ctx, "Door Slammed Noise Logged", Toast.LENGTH_LONG).show();
				 wnu1.widgetnoiseupdate(ctx,2);
				 
			 } else {
				 super.onReceive(ctx, intent);
			 }
			 
			 
			 if (intent.getAction().equals(ACTION_WIDGET_BABYG_CLICK)) {
				 Toast.makeText(ctx, "Baby Gate Bounced Noise Logged", Toast.LENGTH_LONG).show();
				 wnu1.widgetnoiseupdate(ctx,1);
				 
			 } else {
				 super.onReceive(ctx, intent);
			 }
			 
			 if (intent.getAction().equals(ACTION_WIDGET_OTHER_CLICK)) {
				 Toast.makeText(ctx, "Other Noise Logged", Toast.LENGTH_LONG).show();
				 wnu1.widgetnoiseupdate(ctx,7);
				 
			 } else {
				 super.onReceive(ctx, intent);
			 }
			 
		    
			 
	}	
	
	
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
	 int[] appWidgetIds) {
	// TODO Auto-generated method stub
	super.onUpdate(context, appWidgetManager, appWidgetIds); 
	ComponentName thisWidget = new ComponentName(context,
	        BnWidgetClass1.class);
	    
	    int[] allWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
	    for (int widgetId : allWidgetIds) { 
	    	
	    	RemoteViews updateViews = new RemoteViews(context.getPackageName(), R.layout.widget_layout); 
	    	
	    	Intent vacintent = new Intent(context,BnWidgetClass1.class);
	    	vacintent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
	    	vacintent.setAction(ACTION_WIDGET_VAC_CLICK);
	    	vacintent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
	    	
	    	 PendingIntent vacpendingIntent = PendingIntent.getBroadcast(context,
			          widgetId, vacintent,0);
	    	 
	    	 Intent doorintent = new Intent(context,BnWidgetClass1.class);
		    	doorintent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
		    	doorintent.setAction(ACTION_WIDGET_DOOR_CLICK);
		    	doorintent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
		    	
		    	 PendingIntent doorpendingIntent = PendingIntent.getBroadcast(context,
				          widgetId, doorintent,0);
		    	 
		    	 Intent babygintent = new Intent(context,BnWidgetClass1.class);
		    	 babygintent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
		    	 babygintent.setAction(ACTION_WIDGET_BABYG_CLICK);
		    	 babygintent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
			    	
			    	 PendingIntent babygpendingIntent = PendingIntent.getBroadcast(context,
					          widgetId, babygintent,0);
			    	 
			    	 Intent otherintent = new Intent(context,BnWidgetClass1.class);
			    	 otherintent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
			    	 otherintent.setAction(ACTION_WIDGET_OTHER_CLICK);
			    	 otherintent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
				    	
				    	 PendingIntent otherpendingIntent = PendingIntent.getBroadcast(context,
						          widgetId, otherintent,0);
	    	 
	    	 updateViews.setOnClickPendingIntent(R.id.vac, vacpendingIntent);
	    	 updateViews.setOnClickPendingIntent(R.id.doorslam, doorpendingIntent);
	    	 updateViews.setOnClickPendingIntent(R.id.babygate, babygpendingIntent);
	    	 updateViews.setOnClickPendingIntent(R.id.other, otherpendingIntent);
	    	 
	    	 appWidgetManager.updateAppWidget(appWidgetIds, updateViews);
	    
	    }
	}
	
}
