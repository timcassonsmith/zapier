package co.uk.shieldstothemax.blastedneighbours;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import co.uk.shieldstothemax.blastedneighbours.Exportfile.exportbr;

import android.app.IntentService;
import android.content.Intent;
import android.database.Cursor;
import android.os.Environment;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

public class Exportservice extends IntentService {
	public DBAdapter expdata;
	 public Cursor expcursor;
	// public static final String ACTION_MyIntentServiceE = "co.uk.shieldstothemax.RESPONSEE";
	 public static final String ACTION_ServiceE = "co.uk.shieldstothemax.RESPONSEE";
	 
	 String[] importtypes = {"Shouting", "Baby Gate Bounced", "Door Slammed",
	    		"DIY", "Hoovering", "TV Music Loud","Kids Running", "Other", 
	    		  "Loud Sound","Very Loud Sound","Extremely Loud Sound"};
	 String impimgref = "co.uk.shieldstothemax.blastedneighbours:drawable/";
		String[] noisedrawableimp = {"shouticon48","babygate","dooricon48","hammer","vacuum","tv","kid","loudicon48",
				   "loud_speaker","very_loud_speaker","extremly_loud_speaker"};
		String datefile= "";
		 String fullpathname ="";
		 String ext = ".csv";
		 String filename = "nuisance_log_";
		 String getcurpath = "";
		 List<String> exporti = null;
		String exportdatefrom="",exportdateto="";
		Integer daye=-1,monthe=-1,yeare=-1,houre=-1,mine=-1,sece=-1,noisetypee=-1,noisenotee=-1;
		String recinfo = "";
		 String csvheadings = "noise type,noise notes,noise date,noise time"+ "\n";
		 Integer noiseid;
		 String exportedinfo = "";
		 String fulldate = ""; 
		 	String fulltime = "";
	
	public Exportservice() {
		super("Exportservice");
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void onHandleIntent(Intent arg0) {
		// TODO Auto-generated method stub
		   exportdatefrom = arg0.getStringExtra("FROMDATE");
    	   exportdateto = arg0.getStringExtra("TODATE");
    	   fullpathname = arg0.getStringExtra("FILEE");
    	   
    	   
    	   
    	   exporti = new ArrayList<String>();
  		 expdata = new DBAdapter(Exportservice.this);
  		expdata.open();
  		
  		if (exportdatefrom!=null && exportdateto!=null) {
  			expcursor = expdata.gdf(Integer.valueOf(exportdatefrom), Integer.valueOf(exportdateto));
  		} else {
  			expcursor = expdata.GetAllLogs(2, "noise_date_sort");
  		}
  		
  		expcursor.moveToFirst();
      	daye = expcursor.getColumnIndex("noise_day");		
      	monthe = expcursor.getColumnIndex("noise_month");
      	yeare = expcursor.getColumnIndex("noise_year");
      	houre = expcursor.getColumnIndex("noise_hour");
      	mine = expcursor.getColumnIndex("noise_min");
      	sece = expcursor.getColumnIndex("noise_second");
      	noisetypee = expcursor.getColumnIndex("noise_type_id");
      	noisenotee = expcursor.getColumnIndex("noise_info");
      	
      	
      	noiseid = expcursor.getInt(noisetypee);
      	exporti.add(csvheadings);
      	recinfo = String.format("%s,%s,%02d/%02d/%04d,%02d:%02d:%02d", importtypes[noiseid],
      			expcursor.getString(noisenotee),expcursor.getInt(daye),expcursor.getInt(monthe)
      			  ,expcursor.getInt(yeare),expcursor.getInt(houre),expcursor.getInt(mine),expcursor.getInt(sece));
      	exporti.add(recinfo+"\n");
      	
    //  	exportedinfo = csvheadings;
  	//	exportedinfo += importtypes[noiseid] +","+expcursor.getString(noisenotee)+","+
  	//			fulldate+","+fulltime + " \n" ; 
  		
  		while (!expcursor.isAfterLast()) {
      		if ( expcursor.moveToNext() ) {
      			recinfo = String.format("%s,%s,%02d/%02d/%04d,%02d:%02d:%02d",importtypes[expcursor.getInt(noisetypee)],expcursor.getString(noisenotee),expcursor.getInt(daye),expcursor.getInt(monthe)
  	        			  ,expcursor.getInt(yeare),expcursor.getInt(houre),expcursor.getInt(mine),expcursor.getInt(sece));
  	        	exporti.add(recinfo+"\n");
      		}
      	}
  		
  		expcursor.close();
  		expdata.close();
  		
  		//Intent EintentResponse = new Intent();
  		//EintentResponse.setAction(ACTION_ServiceE);
  	//	EintentResponse.addCategory(Intent.CATEGORY_DEFAULT);
  //		EintentResponse.putExtra("FINISH", "DONE");
 // 		EintentResponse.putExtra("RESULT", 1);
//		  sendBroadcast(EintentResponse);
		//  Log.d("SERVICE","Sent message from service to reciever.....");
  		
  		if (writelog(exporti,fullpathname)) {
  			SystemClock.sleep(10000);
			Log.d("WRITE", "Used writelog Routine");
		Intent EintentResponse = new Intent();
		  EintentResponse.setAction(Exportservice.ACTION_ServiceE);
		  EintentResponse.addCategory(Intent.CATEGORY_DEFAULT);
		  EintentResponse.putExtra("FINISH", "DONE");
		  EintentResponse.putExtra("RESULT", 1);
		  
		  sendBroadcast(EintentResponse);
		  Log.d("SERVICE","Sent message from service to reciever SUCCESS!.....");
		} else {
			SystemClock.sleep(10000);
			Log.d("WRITE", "Failed to use writelog Routine");
			Intent EEintentResponse = new Intent();
			 EEintentResponse.setAction(Exportservice.ACTION_ServiceE);
			  EEintentResponse.addCategory(Intent.CATEGORY_DEFAULT);
			  EEintentResponse.putExtra("FINISH", "ERROR");
			  EEintentResponse.putExtra("RESULT", 1);
			  
			  sendBroadcast(EEintentResponse);
			  Log.d("SERVICE","Sent message from service to reciever FAILED!.....");
		}
    	   
    	   
	}

	public boolean writelog(List<String> logfile,String logfilename) {
		Log.d("EXPORT", "Reached writelog Routine");
		 if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
			 File file = new File(logfilename);
			 if (!file.exists()) {
				 try
				 {
					file.createNewFile(); 
					
				 } catch (IOException error) {
					 error.printStackTrace();
					 Toast.makeText(this, "Error Writing file:" + file.getName(), Toast.LENGTH_LONG).show();
					 return false;
				 }
			 }
			 try {
				BufferedWriter buflog = new BufferedWriter(new FileWriter(file,false));
				  if (logfile.size()>0) {
		            for (int data=0;data<=logfile.size()-1;data++) {
		            	buflog.write(logfile.get(data));
		            }
				  }
				buflog.close();
				
			 } catch (IOException error) {
				 error.printStackTrace();
				 Toast.makeText(this, "Error Creating file.", Toast.LENGTH_LONG).show();
				 return false;
			 }
		 } else {
			 Toast.makeText(this, "Cannot write to this folder", Toast.LENGTH_LONG).show();
			 return false;
		 }
		 return true;
	 }
	
	
	
	
	
}
