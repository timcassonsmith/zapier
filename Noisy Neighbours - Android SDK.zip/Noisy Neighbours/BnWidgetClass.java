package co.uk.shieldstothemax.blastedneighbours;








import android.app.PendingIntent;
import android.appwidget.AppWidgetProvider;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import android.widget.Toast;

//import java.util.Calendar;



public class BnWidgetClass extends AppWidgetProvider {

	public static String ACTION_WIDGET_KID_CLICK = "KID_CLICK";
	public static String ACTION_WIDGET_HAMMER_CLICK = "CLICK_HAMMER";
	public static String ACTION_WIDGET_SHOUTING_CLICK = "CLICK_SHOUTING";
	public static String ACTION_WIDGET_TV_CLICK = "CLICK_TV";
	
	
	 @Override
	 public void onReceive(Context ctx,Intent intent) {
		  AppWidgetDB wnu = new AppWidgetDB();
		 
		 
		//  Toast.makeText(ctx, "BnWidgetClass reached onreceive", Toast.LENGTH_LONG).show();
		  
		  
//		  RemoteViews updateviews = new RemoteViews(ctx.getPackageName(),
//		        R.layout.widget_layout1);
//		  final int ids = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
//		  
		 if (intent.getAction().equals(ACTION_WIDGET_KID_CLICK)) {
			 Toast.makeText(ctx, "Kid Noise Logged", Toast.LENGTH_LONG).show();
	
			 wnu.widgetnoiseupdate(ctx,6);
		 } else {
			 super.onReceive(ctx, intent);
		 }
		 
		 if (intent.getAction().equals(ACTION_WIDGET_TV_CLICK)) {
			 Toast.makeText(ctx, "TV Music Noise Logged", Toast.LENGTH_LONG).show();
			 wnu.widgetnoiseupdate(ctx,5);
			 
		 } else {
			 super.onReceive(ctx, intent);
		 }
		 
		 
		 if (intent.getAction().equals(ACTION_WIDGET_HAMMER_CLICK)) {
			 Toast.makeText(ctx, "DIY / HAMMERING Noise Logged", Toast.LENGTH_LONG).show();
			 wnu.widgetnoiseupdate(ctx,3);
			 
		 } else {
			 super.onReceive(ctx, intent);
		 }
		 
		 if (intent.getAction().equals(ACTION_WIDGET_SHOUTING_CLICK)) {
			 Toast.makeText(ctx, "Shouting Noise Logged", Toast.LENGTH_LONG).show();
			 wnu.widgetnoiseupdate(ctx,0);
			 
		 } else {
			 super.onReceive(ctx, intent);
		 }
		 
		
		 
//		 
//		    
		
		//	database.close();   
			
	 }
	 
//	 private void widgetnoiseupdate(Context ctx,Integer widgetnoisetype) {
//		 DBAdapter database;
//		 String drawloc = "co.uk.shieldstothemax.blastedneighbours:drawable/";
//		 String noise_desc = "";
//		 String noise_img = "";
//		 
//		 
//		 switch (widgetnoisetype) {
//		 
//		   case 0:
//				noise_img ="shouticon48";
//			   	noise_desc = "Widget Shouting Noise";
//			 break;
//		   
//		   case 3:
//				noise_img ="hammer";
//			   	noise_desc = "Widget DIY Noise";
//			 break;
//		   
//		   case 5:
//				noise_img ="tv";
//			   	noise_desc = "Widget TV / Music Noise";
//		     break;
//		   case 6:
//			   	noise_img ="kid";
//			   	noise_desc = "Widget Kid Noise";
//			break;
//		 }
//		
//		 database = new DBAdapter(ctx);
//		 database = database.open();
//        
//		 Calendar widgetcal = Calendar.getInstance();
//		 String widgethour = String.valueOf(widgetcal.get(Calendar.HOUR_OF_DAY));
//		 if (widgethour.length()<=1) {
//			 widgethour = "0"+widgethour;
//		 }
//		 
//		 String widgetmin = String.valueOf(widgetcal.get(Calendar.MINUTE));
//		 if (widgetmin.length()<=1) {
//			 widgetmin = "0"+widgetmin;
//		 }
//		 String widgetsec = String.valueOf(widgetcal.get(Calendar.SECOND));
//		 if (widgetsec.length()<=1) {
//			 widgetsec = "0"+widgetsec;
//		 }
//		 String widgetday = String.valueOf(widgetcal.get(Calendar.DAY_OF_MONTH));
//		 if (widgetday.length()<=1) {
//			 widgetday = "0"+widgetday;
//		 }
//		 
//		 String widgetmon = String.valueOf(widgetcal.get(Calendar.MONTH))+1;
//		 if (widgetmon.length()<=1) {
//			 widgetmon = "0"+widgetmon;
//		 }
//		 String widgetyear = String.valueOf(widgetcal.get(Calendar.YEAR));
//		 
//		 String longdate = widgetyear+widgetmon+widgetday+widgethour+widgetmin+widgetsec;
//		 Long widgetnoisedate = Long.valueOf(longdate);
//		 
//		 database.createLog(noise_desc,drawloc+noise_img, widgetnoisetype, Integer.valueOf(widgethour), Integer.valueOf(widgetmin), Integer.valueOf(widgetsec), Integer.valueOf(widgetday), Integer.valueOf(widgetmon), Integer.valueOf(widgetyear), widgetnoisedate);
//	     database.close();
//		 
//	 }
//	
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
	 int[] appWidgetIds) {
	// TODO Auto-generated method stub
	super.onUpdate(context, appWidgetManager, appWidgetIds);
	// Get all ids
    ComponentName thisWidget = new ComponentName(context,
        BnWidgetClass.class);
    
    int[] allWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
    for (int widgetId : allWidgetIds) { 
    	
    	RemoteViews updateViews = new RemoteViews(context.getPackageName(), R.layout.widget_layout1);
    	
    	
    	Intent kidintent = new Intent(context,BnWidgetClass.class);
    	kidintent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
    	kidintent.setAction(ACTION_WIDGET_KID_CLICK);
    	kidintent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
    	
    	 PendingIntent kidpendingIntent = PendingIntent.getBroadcast(context,
		          widgetId, kidintent,0);
    	
    	 
    	 Intent tvintent = new Intent(context,BnWidgetClass.class);
     	tvintent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
     	tvintent.setAction(ACTION_WIDGET_TV_CLICK);
     	tvintent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
     	
     	 PendingIntent tvpendingIntent = PendingIntent.getBroadcast(context,
 		          widgetId, tvintent,0); 
     	 
    	 Intent diyintent = new Intent(context,BnWidgetClass.class);
      	diyintent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
      	diyintent.setAction(ACTION_WIDGET_HAMMER_CLICK);
      	diyintent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
      	
      	 PendingIntent diypendingIntent = PendingIntent.getBroadcast(context,
  		          widgetId, diyintent,0); 
    	 
      	 
      	 Intent shoutintent = new Intent(context,BnWidgetClass.class);
       	shoutintent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
       	shoutintent.setAction(ACTION_WIDGET_SHOUTING_CLICK);
       	shoutintent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
       	
       	 PendingIntent shoutpendingIntent = PendingIntent.getBroadcast(context,
   		          widgetId, shoutintent,0); 
       	 
//       	Intent vacintent = new Intent(context,BnWidgetClass1.class);
//    	vacintent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
//    	vacintent.setAction(ACTION_WIDGET_VAC_CLICK);
//    	vacintent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
//    	
//    	 PendingIntent vacpendingIntent = PendingIntent.getBroadcast(context,
//		          widgetId, vacintent,0);
//    	 
//    	 updateViews.setOnClickPendingIntent(R.id.vac, vacpendingIntent);
     	 
      	 
    	updateViews.setOnClickPendingIntent(R.id.kid, kidpendingIntent);
    	updateViews.setOnClickPendingIntent(R.id.tv, tvpendingIntent);
    	updateViews.setOnClickPendingIntent(R.id.diy, diypendingIntent);
    	updateViews.setOnClickPendingIntent(R.id.shout, shoutpendingIntent);
    	
    	
    	
    	appWidgetManager.updateAppWidget(appWidgetIds, updateViews);
    }
	
	

	
	

	}
	
	
	
	
}
