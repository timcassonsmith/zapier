package co.uk.shieldstothemax.blastedneighbours;


import android.app.Activity;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.widget.TimePicker;
import android.widget.Toast;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;
import android.view.View;
//import android.view.View.OnClickListener;
//import android.view.View.OnFocusChangeListener;
//import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
//import android.view.WindowManager;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
//import android.database.Cursor;
//import android.graphics.Color;

import java.util.Calendar;
//import android.widget.SimpleCursorAdapter;
import android.app.AlertDialog;

public class enterdata extends Activity implements TextWatcher {
	Integer[] noiserefer = {R.drawable.shouticon48,R.drawable.babygate,R.drawable.dooricon48,
	           R.drawable.hammer,R.drawable.vac,R.drawable.tv,R.drawable.kid,R.drawable.bungeespydaquestion,
	             R.drawable.loud_speaker,R.drawable.very_loud_speaker,R.drawable.extremly_loud_speaker,R.drawable.app_icon };
	String cancelbdymsg = "";
	String limgref = "co.uk.shieldstothemax.blastedneighbours:drawable/";
	String[] noisedrawable = {"shouticon48","babygate","dooricon48","hammer","vacuum","tv","kid","bungeespydaquestion",
			   "loud_speaker","very_loud_speaker","extremly_loud_speaker","app_icon"};
	
	  String[] noiseimage = {"Shouting", "Baby Gate Bounced", "Door Slammed",
	    		"DIY", "Hoovering / Vacumming", "TV Music Loud", "Childrens Noise","Other Problems","Loud Sound","Very Loud Sound","Extremely Loud Sound","Ridiculously Loud Sound"};
	    
    private EditText Enotes,Ehour,Emin,Esec,Emonth,Eyear,Eday;
	private Button okaybtn,cancelbtn,pickthedate,pickthetime;
	private Spinner noiseimages;
	Integer recordcount=1;
	private Intent data,UpdateI;
	TimePickerDialog timed = null;
	DatePickerDialog dated = null;
	private long id_rec; 
	private boolean nnupdatenew = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
	   super.onCreate(savedInstanceState);
	   setContentView(R.layout.enterdata);
	   Enotes = (EditText)findViewById(R.id.notes);
	   Ehour = (EditText)findViewById(R.id.hour_edit);
	   Emin = (EditText)findViewById(R.id.min_edit);
	   Esec = (EditText)findViewById(R.id.sec_edit);
	   Eday = (EditText)findViewById(R.id.Day_edit);
	   Emonth = (EditText)findViewById(R.id.Mon_edit);
	   Eyear = (EditText)findViewById(R.id.year_edit);
	   UpdateI = new Intent();
	   
//	 Ehour.setOnFocusChangeListener(new OnFocusChangeListener() {
//
//		@Override
//		public void onFocusChange(View arg0, boolean arg1) {
//			// TODO Auto-generated method stub
//			if (!arg1) {
//				if (((EditText)arg0).getText().length()<=0) {
//					
//					Calendar nohour = Calendar.getInstance();
//					((EditText)arg0).setText(numberformatter(nohour.get(Calendar.HOUR_OF_DAY)));
//				    if (((EditText)arg0).requestFocus()) {
//				    	 getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
//			             Emin.clearFocus();   
//			             Toast.makeText(getApplicationContext(), "No Hour Entered", Toast.LENGTH_LONG).show();	
//				    }
//				
//				//	((EditText)arg0).setFocusable(((EditText)arg0).requestFocus());
//					
//				}
//			}
//		}});
//	   
	   
	   
	   
	   Ehour.addTextChangedListener(this);
	   Emin.addTextChangedListener(this);	   
       Esec.addTextChangedListener(this);
       Eday.addTextChangedListener(this);
       Emonth.addTextChangedListener(this);
       Eyear.addTextChangedListener(this);

	  
	   
	  
	   okaybtn = (Button)findViewById(R.id.okay);
	   cancelbtn = (Button)findViewById(R.id.cancel);
	   noiseimages = (Spinner)findViewById(R.id.image_list);
	   pickthetime = (Button)findViewById(R.id.picktime);
	   pickthedate = (Button)findViewById(R.id.pickdate);
	   
	  
	   noiseimages.setAdapter(new MyCustomAdapter(enterdata.this, R.layout.spinner, noiseimage));
	   
	//   noiseimages.setBackgroundColor(Color.LTGRAY);
	   
	 	    
	   data = this.getIntent();
	   setupvalues();
//	   id_rec = data.getLongExtra(DBAdapter.COL_ID, 0);
//	   if (id_rec ==0) {
//		   Log.v("INSERT", "This is inserting a record");
//		   Ehour.setText(numberformatter(curdatetime.get(Calendar.HOUR_OF_DAY)));
//		        
//			   Emin.setText(numberformatter(curdatetime.get(Calendar.MINUTE))); 
//			  
//			   Esec.setText(numberformatter(curdatetime.get(Calendar.SECOND)));
//			   Eday.setText(numberformatter(curdatetime.get(Calendar.DAY_OF_MONTH)));
//			   Emonth.setText(numberformatter(curdatetime.get(Calendar.MONTH)+1)); 
//			   Eyear.setText(Integer.toString(curdatetime.get(Calendar.YEAR)));
//			  /* Emin.setText(String.format("%02d",Integer.toString(curdatetime.get(Calendar.MINUTE)))); 
//			   Esec.setText(String.format("%02d",Integer.toString(curdatetime.get(Calendar.SECOND))));
//			   Eday.setText(String.format("%02d",Integer.toString(curdatetime.get(Calendar.DAY_OF_MONTH))));
//			   Emonth.setText(String.format("%02d",Integer.toString(curdatetime.get(Calendar.MONTH)+1)));*/
//		
//		  
//		   nnupdatenew = false;
//		   
//	   } else {
//		   nnupdatenew = true;
//		   Log.v("INSERT", "This is updating  a record");
//		   String updatenotes = data.getStringExtra(DBAdapter.COL_NOISE_INFO);
//		   Integer updateday = data.getIntExtra(DBAdapter.COL_NOISE_DAY, 0);
//		   Integer updatemon = data.getIntExtra(DBAdapter.COL_NOISE_MON, 0);
//		   Integer updateyear = data.getIntExtra(DBAdapter.COL_NOISE_YEAR, 0);
//		   Integer updatehour = data.getIntExtra(DBAdapter.COL_NOISE_HOUR, 0);
//		   Integer updatemin = data.getIntExtra(DBAdapter.COL_NOISE_MIN, 0);
//		   Integer updatesec = data.getIntExtra(DBAdapter.COL_NOISE_SEC, 0);
//		   Integer updatetype = data.getIntExtra(DBAdapter.COL_NOISE_TYPE, 0);
//		   
//		   Enotes.setText(updatenotes);
//		   Eday.setText(numberformatter(updateday));
//		   Emonth.setText(numberformatter(updatemon));
//		   Eyear.setText(Integer.toString(updateyear));
//		   Ehour.setText(numberformatter(updatehour));
//		   Emin.setText(numberformatter(updatemin));
//		   Esec.setText(numberformatter(updatesec));
//		  
//		   noiseimages.setSelection(updatetype);
//		   
//		   
//	   }
//	   
	   pickthetime.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			if (nnupdatenew) {
				Integer timehour = data.getIntExtra(DBAdapter.COL_NOISE_HOUR, 0);
				Integer timemin = data.getIntExtra(DBAdapter.COL_NOISE_MIN, 0);
				timed = new TimePickerDialog(v.getContext(), new TimePickHandler(), timehour, timemin, true);
			    	
			} else {
				Calendar timecal = Calendar.getInstance();
			    timed = new TimePickerDialog(v.getContext(), new TimePickHandler(), timecal.get(Calendar.HOUR_OF_DAY), timecal.get(Calendar.MINUTE), true);
		
			}
			timed.show();
		}
	});
			   
   pickthedate.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (nnupdatenew) {
			Integer dateday = data.getIntExtra(DBAdapter.COL_NOISE_DAY, 0);
			Integer datemon = data.getIntExtra(DBAdapter.COL_NOISE_MON, 0);
			Integer dateyear = data.getIntExtra(DBAdapter.COL_NOISE_YEAR, 0);
			Toast.makeText(v.getContext(), "Existing Record Date: "+String.valueOf(dateday)+String.valueOf(0+datemon)+String.valueOf(dateyear), Toast.LENGTH_LONG).show();
			dated = new DatePickerDialog(v.getContext(), new DatePickHandler(), dateyear, datemon-1, dateday);
		    	
		} else {
			Calendar datecal = Calendar.getInstance();
			dated = new DatePickerDialog(v.getContext(), new DatePickHandler(), datecal.get(Calendar.YEAR), datecal.get(Calendar.MONTH), datecal.get(Calendar.DAY_OF_MONTH));
	
		}
		dated.show();
	}
});
			   
			   
			   
	   
	   okaybtn.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			//Intent UpdateI = new Intent();
			
			UpdateI.putExtra("info"+Integer.toString(recordcount), Enotes.getText().toString());
			UpdateI.putExtra("type"+Integer.toString(recordcount), noiseimages.getSelectedItemPosition());
			UpdateI.putExtra("image"+Integer.toString(recordcount), limgref+noisedrawable[noiseimages.getSelectedItemPosition()].toString());
           String alertmsg = "";
 
 
           
			
			if (Ehour.getText().length()==0  || Emin.getText().length()==0 || Esec.getText().length()==0 
					  || Eday.getText().length()==0 || Emonth.getText().toString().equals("0") || Emonth.getText().toString().equals("")  || Emonth.getText().length()==0 || (Eyear.getText().length()==0 
					  || Integer.valueOf(Eyear.getText().toString())<1999 || Integer.valueOf(Eyear.getText().toString())>2099)  
					){
				
				if (Ehour.getText().length()==0) {
					
					  alertmsg += "Hour";
				}
				
				if (Emin.getText().length()==0) {
					if (alertmsg.length()>0) {alertmsg +=",";}
					alertmsg += "Minute";
				}
				
				if (Esec.getText().length()==0) {
					if (alertmsg.length()>0) {alertmsg +=",";}
					alertmsg += "Seconds";
				}
				
				if (Eday.getText().length()==0) {
					if (alertmsg.length()>0) {alertmsg +=",";}
					alertmsg += "Day";
				}
				
				if (Emonth.getText().length()==0 || Emonth.getText().toString().equals("") || Emonth.getText().toString().equals("0")) {
					if (alertmsg.length()>0) {alertmsg +=",";}
					alertmsg += "Month";
				}
				
				if (Eyear.getText().length()==0 || Integer.valueOf(Eyear.getText().toString())<1999 || Integer.valueOf(Eyear.getText().toString())>2099 ) {
					if (alertmsg.length()>0) {alertmsg +=",";}
					alertmsg += "Year";
				}
				
//				if (Integer.valueOf(Eyear.getText().toString())<1999 || Integer.valueOf(Eyear.getText().toString())>2099 ) {
//					if (alertmsg.length()>0) {alertmsg +=",";}
//					alertmsg += "Year";
//				}
				AlertDialog.Builder deldialog = new AlertDialog.Builder(enterdata.this);
				deldialog.setMessage("No Valid Entry In "+alertmsg)
				.setCancelable(false)
				.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
					   dialog.cancel();
					}
				});
			
				AlertDialog deleterecords = deldialog.create();
				deleterecords.setTitle("Invalid Entries!");
				deleterecords.setIcon(R.drawable.dateerror);
				deleterecords.show();
			} else {
			
			
			UpdateI.putExtra("hour"+Integer.toString(recordcount), Integer.parseInt(Ehour.getText().toString()));
			
			UpdateI.putExtra("records", recordcount);
			
			UpdateI.putExtra("min"+Integer.toString(recordcount), Integer.parseInt(Emin.getText().toString()));
			
			UpdateI.putExtra("sec"+Integer.toString(recordcount), Integer.parseInt(Esec.getText().toString()));
			
			UpdateI.putExtra("day"+Integer.toString(recordcount), Integer.parseInt(Eday.getText().toString()));
		
			UpdateI.putExtra("month"+Integer.toString(recordcount), Integer.parseInt(Emonth.getText().toString()));
		
			UpdateI.putExtra("year"+Integer.toString(recordcount), Integer.parseInt(Eyear.getText().toString()));
		
			if (nnupdatenew) {
			   UpdateI.putExtra("id", id_rec);
			}
			 setResult(RESULT_OK, UpdateI);
			if (!nnupdatenew) { 
			 new AlertDialog.Builder(enterdata.this) 
			 .setTitle("Add other record?")
		     .setMessage("Do you want to add another record or quit to Main Program?")
		     .setPositiveButton("Add Record", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					dialog.dismiss();
					recordcount++;
					setupvalues();
				}
			})
			.setNegativeButton(" Quit ", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					finish();		
				}
			})
			.show();
		} else {
			finish();
		}
	 		
			}
		}
	});
	   
	   cancelbtn.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			String cancelmsg = "Are you sure you want to quit?";
			AlertDialog.Builder cancelldialog = new AlertDialog.Builder(enterdata.this);
			
			if (recordcount >1) {
			   cancelbdymsg = "Any unsaved data will be lost"+"\n" +"Cancel Current Record Only?"+"\n"+
							"or Cancel ALL Records."+"\n"
					        +"There are currently : "+Integer.toString(recordcount-1)+" records added";
			   cancelldialog.setMessage(cancelbdymsg)
			   .setCancelable(false)
			   .setPositiveButton("Cancel Current", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
					   finish();
					}
				})
				.setNeutralButton("Cancel ALL", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						UpdateI = new Intent();
						setResult(0);
						finish();
						
					}
					
					
				})
				
				
				.setNegativeButton("NO", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
					  dialog.cancel();	
					}
				});
				
   
			   
			}  else {
				cancelldialog.setMessage("Are you sure you want to quit?"+"\n" + 
						   "Any unsaved data will be lost"+"\n" )
			    .setCancelable(false)
			    .setPositiveButton("YES", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						finish();
					}
					
					
				})
				
				.setNegativeButton("NO",  new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						dialog.cancel();
					}
				});
				
			}
			
			
					
			AlertDialog deleterecords = cancelldialog.create();
			deleterecords.setTitle(cancelmsg);
			deleterecords.setIcon(R.drawable.quitapp);
			deleterecords.show();
		   	
		}
	});
	}
	
	
	private class DatePickHandler implements OnDateSetListener {

		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			// TODO Auto-generated method stub
			 Eday.setText(numberformatter(dayOfMonth));
			 if (nnupdatenew){
				 Emonth.setText(numberformatter(monthOfYear+1));
			 } else {
			     Emonth.setText(numberformatter(monthOfYear+1)); 
			   }
			   Eyear.setText(Integer.toString(year));
			dated.hide();
			
		}}
	
	 private class TimePickHandler implements OnTimeSetListener {

		@Override
		public void onTimeSet(TimePicker arg0, int arg1, int arg2) {
			// TODO Auto-generated method stub
			Calendar timesec = Calendar.getInstance();
			Ehour.setText(numberformatter(arg1));
			Emin.setText(numberformatter(arg2));
			Esec.setText(numberformatter(timesec.get(Calendar.SECOND)));
		  timed.hide();	
		} 
		 
		
		 
	 }
	
	 @Override
	 public void onBackPressed() {
	 // do something on back.
		 AlertDialog.Builder cancelldialog = new AlertDialog.Builder(enterdata.this);
			cancelldialog.setMessage("Are you sure you want to quit? Any unsaved data will be lost")
			.setCancelable(false)
			.setPositiveButton("YES", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
				   finish();
				}
			})
			.setNegativeButton("NO", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
				  dialog.cancel();	
				}
			});
		
			AlertDialog deleterecords = cancelldialog.create();
			deleterecords.setTitle("Quit?");
			deleterecords.setIcon(R.drawable.quitapp);
			deleterecords.show();
	     	
	 return;
	 }
	
	public String numberformatter(int i) {
		String result = Integer.toString(i);
	    Log.d("PREFIX", "result starts with this = "+result);
	    if (result.length() >1 ) {
	  	  Log.d("PREFIX", "NO ZEROES HERE");
	  	 return Integer.toString(i);
	  	 }
	   	 
	   String zeroprefix = "";
	   zeroprefix = "0"+result;
	   Log.d("PREFIX", zeroprefix);
	   
	      return zeroprefix ;
	}
	
	public class MyCustomAdapter extends ArrayAdapter<String>{

		public MyCustomAdapter(Context context, int textViewResourceId,
		String[] objects) {
		super(context, textViewResourceId, objects);
		// TODO Auto-generated constructor stub
		}
		
		@Override
		public View getDropDownView(int position, View convertView,
		ViewGroup parent) {
		// TODO Auto-generated method stub
		return getCustomView(position, convertView, parent);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		return getCustomView(position, convertView, parent);
		}

		public View getCustomView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		//return super.getView(position, convertView, parent);

		LayoutInflater inflater=getLayoutInflater();
	
		View row=inflater.inflate(R.layout.spinner, parent, false);
		
		
		
		TextView label=(TextView)row.findViewById(R.id.noisetypetext);
		label.setText(noiseimage[position]);

		ImageView icon=(ImageView)row.findViewById(R.id.noisetypespinner);

		if (noiserefer[position]==R.drawable.shouticon48){
			icon.setImageResource(R.drawable.shouticon48);
			}else if (noiserefer[position]==R.drawable.babygate) {
			icon.setImageResource(R.drawable.babygate);
			}else if (noiserefer[position]==R.drawable.dooricon48) {
			icon.setImageResource(R.drawable.dooricon48);
			} else if (noiserefer[position]==R.drawable.hammer) {
			icon.setImageResource(R.drawable.hammer);
			}else if (noiserefer[position]==R.drawable.vac) {
			icon.setImageResource(R.drawable.vacuum);
			}else if (noiserefer[position]==R.drawable.tv) {
			icon.setImageResource(R.drawable.tv);
			}else if (noiserefer[position]==R.drawable.bungeespydaquestion) {
			icon.setImageResource(R.drawable.bungeespydaquestion);
			}else if (noiserefer[position]==R.drawable.kid) {
				icon.setImageResource(R.drawable.kid);
			}else if (noiserefer[position]==R.drawable.loud_speaker) {
				icon.setImageResource(R.drawable.loud_speaker);
			}else if (noiserefer[position]==R.drawable.very_loud_speaker) {
				icon.setImageResource(R.drawable.very_loud_speaker);
			}else if (noiserefer[position]==R.drawable.extremly_loud_speaker) {
				icon.setImageResource(R.drawable.extremly_loud_speaker);
			}else if (noiserefer[position]==R.drawable.app_icon) {
				icon.setImageResource(R.drawable.app_icon);
			}
		
		return row;
		}

		
		

	}


	@Override
	public void afterTextChanged(Editable s) {
		// TODO Auto-generated method stub
		
		if (s == Esec.getEditableText()) {
			Integer chksec;
		if (Esec.getText().length()>0) {
	    	chksec = Integer.valueOf(Esec.getText().toString());
	     	if (chksec>59 || chksec<0) { 
		    	Toast.makeText(getApplication(),"Please enter between 0 and 59",Toast.LENGTH_LONG).show();
		    	Calendar secchk = Calendar.getInstance();
		    	Esec.setText(numberformatter(secchk.get(Calendar.MINUTE)));
		    	
			
		    }
		}
		
		
		
		
		
	}
		
		if (s == Emin.getEditableText()) {
		Integer chkmin;
		if (Emin.getText().length()>0) {
	    	chkmin = Integer.valueOf(Emin.getText().toString());
	     	if (chkmin>59 || chkmin<0) { 
		    	Toast.makeText(getApplication(),"Please enter between 0 and 59",Toast.LENGTH_LONG).show();
		    	Calendar minchk = Calendar.getInstance();
		    	Emin.setText(numberformatter(minchk.get(Calendar.MINUTE)));
		    	
			
		    }
		  }	
		}
		
		if (s == Ehour.getEditableText()) {
		Integer chkhour;
		if (Ehour.getText().length()>0) {
	    	chkhour = Integer.valueOf(Ehour.getText().toString());
	     	if (chkhour>23 || chkhour<0) { 
		    	Toast.makeText(this,"Please enter between 0 and 23",Toast.LENGTH_LONG).show();
		    	Calendar hourchk = Calendar.getInstance();
		    	Ehour.setText(numberformatter(hourchk.get(Calendar.HOUR_OF_DAY)));
		    	
			
		    }
	    	}
		}
		
		
		if (s == Eday.getEditableText()) {
			Integer chkday;
			if (Eday.getText().length()>0) {
		    	chkday = Integer.valueOf(Eday.getText().toString());
		     	if (chkday>31 || chkday<1) { 
			    	Toast.makeText(this,"Please enter between 1 and 31",Toast.LENGTH_LONG).show();
			    	Calendar daychk = Calendar.getInstance();
			    	Eday.setText(numberformatter(daychk.get(Calendar.DAY_OF_MONTH)));
			    	
				
			    }
		    	}
			}
		
		if (s == Emonth.getEditableText()) {
			Integer chkmonth;
			if (Emonth.getText().length()>0) {
		    	chkmonth = Integer.valueOf(Emonth.getText().toString());
		     	if (chkmonth>12) { 
			    	Toast.makeText(this,"Please enter between 1 and 12",Toast.LENGTH_LONG).show();
			    	Calendar monthchk = Calendar.getInstance();
			    	Emonth.setText(numberformatter(monthchk.get(Calendar.MONTH)+1));
			    	
				
			    }
		    	}
			}
		
//		if (s == Eyear.getEditableText()) {
//			Integer chkyear;
//			if (Eyear.getText().length()>0) {
//		    	chkyear = Integer.valueOf(Eyear.getText().toString());
//		     	if (chkyear>2099 || chkyear<1999) { 
//			    	Toast.makeText(this,"Please enter between 1999 and 2099",Toast.LENGTH_LONG).show();
//			    	Calendar yearchk = Calendar.getInstance();
//			    	Eyear.setText(numberformatter(yearchk.get(Calendar.YEAR)));
//			    	
//				
//			    }
//		    	}
//			}
		
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		// TODO Auto-generated method stub
		
	}
	
	public void setupvalues () {
		 Calendar curdatetime = Calendar.getInstance();
		
		   id_rec = data.getLongExtra(DBAdapter.COL_ID, 0);
		   if (id_rec ==0) {
			   Log.v("INSERT", "This is inserting a record");
			   noiseimages.setSelection(0);
			   Ehour.setText(numberformatter(curdatetime.get(Calendar.HOUR_OF_DAY)));
			   Enotes.setText("Notes");     
				   Emin.setText(numberformatter(curdatetime.get(Calendar.MINUTE))); 
				  
				   Esec.setText(numberformatter(curdatetime.get(Calendar.SECOND)));
				   Eday.setText(numberformatter(curdatetime.get(Calendar.DAY_OF_MONTH)));
				   Emonth.setText(numberformatter(curdatetime.get(Calendar.MONTH)+1)); 
				   Eyear.setText(Integer.toString(curdatetime.get(Calendar.YEAR)));
				  /* Emin.setText(String.format("%02d",Integer.toString(curdatetime.get(Calendar.MINUTE)))); 
				   Esec.setText(String.format("%02d",Integer.toString(curdatetime.get(Calendar.SECOND))));
				   Eday.setText(String.format("%02d",Integer.toString(curdatetime.get(Calendar.DAY_OF_MONTH))));
				   Emonth.setText(String.format("%02d",Integer.toString(curdatetime.get(Calendar.MONTH)+1)));*/
			
			  
			   nnupdatenew = false;
			   
		   } else {
			   nnupdatenew = true;
			   Log.v("INSERT", "This is updating  a record");
			   String updatenotes = data.getStringExtra(DBAdapter.COL_NOISE_INFO);
			   Integer updateday = data.getIntExtra(DBAdapter.COL_NOISE_DAY, 0);
			   Integer updatemon = data.getIntExtra(DBAdapter.COL_NOISE_MON, 0);
			   Integer updateyear = data.getIntExtra(DBAdapter.COL_NOISE_YEAR, 0);
			   Integer updatehour = data.getIntExtra(DBAdapter.COL_NOISE_HOUR, 0);
			   Integer updatemin = data.getIntExtra(DBAdapter.COL_NOISE_MIN, 0);
			   Integer updatesec = data.getIntExtra(DBAdapter.COL_NOISE_SEC, 0);
			   Integer updatetype = data.getIntExtra(DBAdapter.COL_NOISE_TYPE, 0);
			   
			   Enotes.setText(updatenotes);
			   Eday.setText(numberformatter(updateday));
			   Emonth.setText(numberformatter(updatemon));
			   Eyear.setText(Integer.toString(updateyear));
			   Ehour.setText(numberformatter(updatehour));
			   Emin.setText(numberformatter(updatemin));
			   Esec.setText(numberformatter(updatesec));
			  
			   noiseimages.setSelection(updatetype);
			   
			   
		   }
	}
	

}
