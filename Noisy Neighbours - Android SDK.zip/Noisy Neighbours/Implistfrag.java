package co.uk.shieldstothemax.blastedneighbours;

import java.io.File;
import java.util.ArrayList;
import java.util.List;



import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

public class Implistfrag extends ListFragment {
	
	 TextView mypathi,rowtext;
	 Button oki,canceli;
	 ProgressDialog importprogress;
	 private List<String> itemi = null;
	 private List<String> pathi = null;
	 String rooti;
	 String getcurpathi = "";
	 FileListAdapterFrag fl = null;
	 Integer selectedrow = 0;
	 Integer currpos = -1;
	 Integer dirchk = 0 , posselc = 0;
	 Boolean isblue = false;
	 
	 
	 
	 @Override
	    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		   View view = inflater.inflate(R.layout.main_list, container, false);
		// Sets up TextView for the Path display
	        mypathi = (TextView) view.findViewById(R.id.pathi);
	        // Sets up the Textview for the rows in the list
	        rowtext = (TextView) view.findViewById(R.id.rowtext);
	        oki = (Button)view.findViewById(R.id.oki);
		    // This is not enabled until the user selects a valid file.
		       oki.setEnabled(false);
		       importprogress = new ProgressDialog(getActivity());
		       // Stops the dialog from being cancelled
		       importprogress.setCancelable(false);
		       // Sets the style of the dialog box as a spinner
		       importprogress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		        // Gives the dialog a title of what is happening
		       importprogress.setTitle("Import");
		       // Sets a message to inform the user of what is in progress
		       importprogress.setMessage("Import in Progress.. Please Wait... ");
		      // rooti = Environment.getExternalStorageDirectory().getPath();
			 //    getdiri(rooti); 
	        return view;
	    }
	 
	 private void getdiri(String dirpathi) {
		 mypathi.setText("Current Folder:"+dirpathi);
		 getcurpathi = dirpathi;
		 itemi = new ArrayList<String>();
	     pathi = new ArrayList<String>();
	   
	     File fi = new File(dirpathi);
	     
	     File[] filesi = fi.listFiles();
	     
	     if(!dirpathi.equals(rooti))
	     {
	      itemi.add(rooti);
	      pathi.add(rooti);
	      itemi.add("../");
	      pathi.add(fi.getParent()); 
	     }
	     
	     for(int i=0; i < filesi.length; i++)
	     {
	      File filei = filesi[i];
	   //   path.add(sortorder.get(i).toString());
	     // item.add(sortorder.get(i).toString()+ "/");
	      if(!filei.isHidden() && filei.canRead()){
	     
	          if(filei.isDirectory()){
	        	pathi.add(filei.getPath());
	            itemi.add(filei.getName() + "/");
	         
	          } else {
	        	  
	        	  itemi.add(filei.getName());
	        	  pathi.add(filei.getName());
	        	
	        	  
	          }
	      } 
	     }

	  	     
	  	 fl = new FileListAdapterFrag(getActivity(),R.layout.row,itemi);
	  	 setListAdapter(fl);
  	 
	  	     
	 }
	 
	 public class FileListAdapterFrag extends ArrayAdapter<String>  {

		 private List<String> itemsll; 
      		

			public FileListAdapterFrag(Context implistfrag, int row,
					List<String> iteml) {
				super(implistfrag,row,iteml);
				// TODO Auto-generated constructor stub
				this.itemsll = iteml;
			}

			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				
				View viewnull = convertView;
				if (viewnull == null) {
					LayoutInflater vrow;
					vrow = LayoutInflater.from(getContext());
					
					viewnull = vrow.inflate(R.layout.row, null);
			
				}
				String currow = 	itemsll.get(position);
				TextView rowtext = (TextView)viewnull.findViewById(R.id.rowtext);
				rowtext.setHeight(50);
				rowtext.setText(currow);
				
				
				if (currpos == position && dirchk == 0 ) {
					((TextView)viewnull).setBackgroundColor(R.drawable.darkslateblue);
					isblue = true;
				
					
			       } else  {
			    	   ((TextView)viewnull).setBackgroundColor(Color.TRANSPARENT);
			    	   isblue = false;
			    	   posselc = 0;
			       }
				
				
				return viewnull;	
				
				
			}
			
			

			

			public void setSelectedPosition( int pos )
		    {
		        currpos = pos; 
             
		        notifyDataSetChanged();
		    }
			
			  
		  }
}
