package co.uk.shieldstothemax.blastedneighbours;

import android.app.IntentService;
import android.content.Intent;
import java.io.BufferedReader;

import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

import java.util.Arrays;
import java.io.IOException;
import android.database.Cursor;

public class ImpExpService extends IntentService {
	// **** Shared Variables *****
	public DBAdapter importexpdata;
	 public Cursor importexpcursor;
	 // ********** Import Variables **************
	 FileReader csvimport = null;
	 String readline = "";
	 String[] row = null;
	 String[] impdate = null;
	 String[] imptime = null;
	 Integer imptype = 0;
	 String impnotes= "";
	  Integer day = 0;
		 Integer month = 0;
		 Integer year = 0;
		  Integer hour = 0;
		 Integer min = 0;
		 Integer sec = 0;
		 Integer impexp = -1;
		 String impdatetime = "";
		 Long impsortdatetime = null;
		 String impdates = "";
		 Long impsortdate = null;
		 BufferedReader csvbuf;
		 String sentfile="";
		// *************************************************************************************************************
		// Shared between Import and Export 
		 public static final String ACTION_MyIntentService = "co.uk.shieldstothemax.RESPONSE";
		 public static final String ACTION_MyIntentServiceE = "co.uk.shieldstothemax.RESPONSEE";
	     String[] importtypes = {"Shouting", "Baby Gate Bounced", "Door Slammed",
		    		"DIY", "Hoovering", "TV Music Loud","Kids Running", "Other", 
		    		  "Loud Sound","Very Loud Sound","Extremely Loud Sound"};
		 String impimgref = "co.uk.shieldstothemax.blastedneighbours:drawable/";
			String[] noisedrawableimp = {"shouticon48","babygate","dooricon48","hammer","vacuum","tv","kid","loudicon48",
					   "loud_speaker","very_loud_speaker","extremly_loud_speaker"};
	  // *************************************************************************************************************
	  // *********************** Export Variables *************************
			 String datefile= "";
			 String fullpathname ="";
			 String ext = ".csv";
			 String filename = "nuisance_log_";
			 String getcurpath = "";
			 List<String> exporti = null;
			String exportdatefrom="",exportdateto="";
			Integer daye=-1,monthe=-1,yeare=-1,houre=-1,mine=-1,sece=-1,noisetypee=-1,noisenotee=-1;
			String recinfo = "";
			 String csvheadings = "noise type,noise notes,noise date,noise time"+ "\n";
			 Integer noiseid;
			 String exportedinfo = "";
			 String fulldate = ""; 
			 	String fulltime = "";
	public ImpExpService() {
		super("ImpExpService");
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void onHandleIntent(Intent arg0) {
		  Log.d("SERVICE", "Reached Service onHandleIntent");
		// TODO Auto-generated method stub
      
       impexp = arg0.getIntExtra("IMPEXP", -1);
       
       Log.d("IMPEXP", Integer.toString(impexp));
       if (impexp == 1) {
    	   Log.d("SERVICE", "KNOWS ITS AN IMPORT CALL");
    	   sentfile = arg0.getStringExtra("FILE");
    	   Log.d("FILE", sentfile);
    	   importroutine();
       }
       
       if (impexp == 2) {
    	   Log.d("SERVICE", "KNOWS ITS AN EXPORT CALL");
    	   exportdatefrom = arg0.getStringExtra("FROMDATE");
    	   exportdateto = arg0.getStringExtra("TODATE");
    	   fullpathname = arg0.getStringExtra("FILEE");
    	   exportroutine();
       }
		
		
	}
	
	// ******************************************************
	// *************** Import Routine ***********************
	// **** Called When the import option has bee selected **
	// ******************************************************
	public void importroutine(){
		Log.d("IMPORT", "Arrived at import routine");
		try {
			csvimport = new FileReader(sentfile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		csvbuf = new BufferedReader(csvimport);
		try {
			csvbuf.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 importexpdata = new DBAdapter(ImpExpService.this);
		importexpdata.open();
		importexpdata.deleteAllLogs();
		try {
			importexpdata.begint();
			while 	((readline = csvbuf.readLine()) != null ) {
				
				// read in the data and using the comma to split the fields up
				 row = readline.split(",");
				// read in the date and separate the values by the forward slash
				 if (row.length==4) {
					 imptype = Arrays.asList(importtypes).indexOf(row[0]);
					 impnotes = row[1];
			    	 impdate = row[2].split("/");
			    	 imptime = row[3].split(":");						        
			     } else {
			    	 imptype = Arrays.asList(importtypes).indexOf(row[0]);
			    	 impnotes = "";
			    	 for (Integer i=1; i<row.length;i++) {
			    		 Log.d("COMMA Values", row[i]);
			    		 if (row[i].indexOf("/")==-1 && row[i].indexOf(":")==-1){ 
				    	       impnotes += row[i]; 
				    	       
				    	      // Log.d("IMPNOTES Values", impnotes);
				    	      } 
			    		       if (row[i].indexOf("/")>0 ) {
				    	    	  
				    	    	 impdate = row[i].split("/");
				    	    	// Log.d("IMPDATE", impdate.toString());
				    	      }
			    		       
			    		      if (row[i].indexOf(":")>0) {
				    	    	 imptime = row[i].split(":");
				    	    	 //Log.d("IMPTIME", imptime.toString());
				    	      }
			    	 }
			     }
			      day = Integer.valueOf(impdate[0].trim());
				  month = Integer.valueOf(impdate[1].trim());
				 year = Integer.valueOf(impdate[2].trim());
				   hour = Integer.valueOf(imptime[0].trim());
				 min = Integer.valueOf(imptime[1].trim());
				  sec = Integer.valueOf(imptime[2].trim());
				  impdatetime = Integer.toString(year)+impprefixzero(month)+impprefixzero(day)
						 +impprefixzero(hour)+impprefixzero(min)+impprefixzero(sec);
				  //Log.d("IMPDATETIME Value", impdatetime);
				  impsortdatetime = Long.valueOf(impdatetime);
				 // Log.d("IMPSORTDATETIME Value", Long.toString(impsortdatetime));
				 impdates = Integer.toString(year)+impprefixzero(month)+impprefixzero(day);
				// Log.d("IMPDATES Value", impdates);
				 impsortdate = Long.valueOf(impdates);
				// Log.d("IMPSORTDATE Value", Long.toString(impsortdate));
				importexpdata.createLog(impnotes, impimgref+noisedrawableimp[imptype].toString(), imptype, hour, min, sec, day, month, year, impsortdate, impsortdatetime);
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		importexpdata.settSuc();
		importexpdata.endt();
		importexpdata.close();
		Intent intentResponse = new Intent();
		  intentResponse.setAction(ACTION_MyIntentService);
		  intentResponse.addCategory(Intent.CATEGORY_DEFAULT);
		  intentResponse.putExtra("FINISH", "DONE");
		  intentResponse.putExtra("RESULT", 1);
		  sendBroadcast(intentResponse);
		
	}
	
	// ******************************************************
	// *************** Export Routine ***********************
	// **** Called When the export option has bee selected **
	// ******************************************************

	
	public void exportroutine() {
		Log.d("EXPORT", "Reached Export Routine");
	//	Calendar filedate = Calendar.getInstance();
	//	 datefile = Integer.toString(filedate.get(Calendar.DAY_OF_MONTH))+Integer.toString(filedate.get(Calendar.MONTH)+1)+
		//		    Integer.toString(filedate.get(Calendar.YEAR))+Integer.toString(filedate.get(Calendar.HOUR))+
		//		    Integer.toString(filedate.get(Calendar.MINUTE))+Integer.toString(filedate.get(Calendar.SECOND));
		//fullpathname = getcurpath+"/"+filename+datefile+ext;
		exporti = new ArrayList<String>();
		 importexpdata = new DBAdapter(ImpExpService.this);
		importexpdata.open();
		
		if (exportdatefrom!=null && exportdateto!=null) {
			importexpcursor = importexpdata.gdf(Integer.valueOf(exportdatefrom), Integer.valueOf(exportdateto));
		} else {
			importexpcursor = importexpdata.GetAllLogs(2, "noise_date_sort");
		}
		
		importexpcursor.moveToFirst();
    	daye = importexpcursor.getColumnIndex("noise_day");		
    	monthe = importexpcursor.getColumnIndex("noise_month");
    	yeare = importexpcursor.getColumnIndex("noise_year");
    	houre = importexpcursor.getColumnIndex("noise_hour");
    	mine = importexpcursor.getColumnIndex("noise_min");
    	sece = importexpcursor.getColumnIndex("noise_second");
    	noisetypee = importexpcursor.getColumnIndex("noise_type_id");
    	noisenotee = importexpcursor.getColumnIndex("noise_info");
    	
    	
    	noiseid = importexpcursor.getInt(noisetypee);
    	exporti.add(csvheadings);
    	recinfo = String.format("%s,%s,%02d/%02d/%04d,%02d:%02d:%02d", importtypes[noiseid],
    			importexpcursor.getString(noisenotee),importexpcursor.getInt(daye),importexpcursor.getInt(monthe)
    			  ,importexpcursor.getInt(yeare),importexpcursor.getInt(houre),importexpcursor.getInt(mine),importexpcursor.getInt(sece));
    	exporti.add(recinfo+"\n");
    	
  //  	exportedinfo = csvheadings;
	//	exportedinfo += importtypes[noiseid] +","+importexpcursor.getString(noisenotee)+","+
	//			fulldate+","+fulltime + " \n" ; 
		
		while (!importexpcursor.isAfterLast()) {
    		if ( importexpcursor.moveToNext() ) {
    			recinfo = String.format("%s,%s,%02d/%02d/%04d,%02d:%02d:%02d",importtypes[importexpcursor.getInt(noisetypee)],importexpcursor.getString(noisenotee),importexpcursor.getInt(daye),importexpcursor.getInt(monthe)
	        			  ,importexpcursor.getInt(yeare),importexpcursor.getInt(houre),importexpcursor.getInt(mine),importexpcursor.getInt(sece));
	        	exporti.add(recinfo+"\n");
    		}
    	}
		
		importexpcursor.close();
		if (writelog(exporti,fullpathname)) {
			Log.d("WRITE", "Used writelog Routine");
		Intent intentResponse = new Intent();
		  intentResponse.setAction(ACTION_MyIntentService);
		  intentResponse.addCategory(Intent.CATEGORY_DEFAULT);
		  intentResponse.putExtra("FINISH", "DONE");
		  intentResponse.putExtra("RESULT", 1);
		  
		  sendBroadcast(intentResponse);
		} else {
			Log.d("WRITE", "Failed to use writelog Routine");
			Intent intentResponse = new Intent();
			 intentResponse.setAction(ACTION_MyIntentService);
			  intentResponse.addCategory(Intent.CATEGORY_DEFAULT);
			  intentResponse.putExtra("FINISH", "ERROR");
			  intentResponse.putExtra("RESULT", 1);
			  
			  sendBroadcast(intentResponse);
		}
		
	}
	
	
	public boolean writelog(List<String> logfile,String logfilename) {
		Log.d("EXPORT", "Reached writelog Routine");
		 if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
			 File file = new File(logfilename);
			 if (!file.exists()) {
				 try
				 {
					file.createNewFile(); 
					
				 } catch (IOException error) {
					 error.printStackTrace();
					 Toast.makeText(this, "Error Writing file:" + file.getName(), Toast.LENGTH_LONG).show();
					 return false;
				 }
			 }
			 try {
				BufferedWriter buflog = new BufferedWriter(new FileWriter(file,false));
				  if (logfile.size()>0) {
		            for (int data=0;data<=logfile.size()-1;data++) {
		            	buflog.write(logfile.get(data));
		            }
				  }
				buflog.close();
				
			 } catch (IOException error) {
				 error.printStackTrace();
				 Toast.makeText(this, "Error Creating file.", Toast.LENGTH_LONG).show();
				 return false;
			 }
		 } else {
			 Toast.makeText(this, "Cannot write to this folder", Toast.LENGTH_LONG).show();
			 return false;
		 }
		 return true;
	 }
	
	
	
	 public String impprefixzero(Integer number) {
			String result = Integer.toString(number);
		  //  Log.d("PREFIX", "result starts with this = "+result);
		    if (result.length() >1 ) {
		  	 // Log.d("PREFIX", "NO ZEROES HERE");
		  	 return Integer.toString(number);
		  	 }
		   	 
		   String zeroprefix = "";
		   zeroprefix = "0"+result;
		  // Log.d("PREFIX", zeroprefix);
		   
		      return zeroprefix ;
		}
}
