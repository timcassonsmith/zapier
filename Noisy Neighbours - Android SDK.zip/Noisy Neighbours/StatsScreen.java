package co.uk.shieldstothemax.blastedneighbours;




import android.app.Activity;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TextView;
import android.widget.TabHost.TabSpec;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import android.app.AlertDialog;

public class StatsScreen extends Activity {
 Cursor noisestats,monthstats;
 private DBAdapter mDBstats;
 SimpleCursorAdapter adapternoise,adaptermonths;
 String[] statsmonthsofyear = new String[] {"January","February","March","April","May","June","July","August","September","October","November","December"};
 Integer top =0;
 Boolean noise_month=true;
 ListView lstats;
 String[] tabsfields = new String[] {DBAdapter.COL_NOISE_IMAGE,DBAdapter.COL_NOISE_TYPE,DBAdapter.COL_ID};
 int[] tabsviewfields = new int[] {R.id.stat_noise_type,R.id.stat_noise_desc,
		 R.id.pos};
 
 String[] tabsfieldsmonths = new String[] {DBAdapter.COL_NOISE_MON,DBAdapter.COL_NOISE_YEAR,DBAdapter.COL_ID};
 int[] tabsviewfieldsmon = new int[] {R.id.stat_month,R.id.stat_year,R.id.posmonth};

 Integer[] statsnoiserefer = {R.drawable.shouticon48,R.drawable.babygate,R.drawable.dooricon48,
         R.drawable.hammer,R.drawable.vacuum,R.drawable.tv,R.drawable.kid,R.drawable.loudicon48,
           R.drawable.loud_speaker,R.drawable.very_loud_speaker,R.drawable.extremly_loud_speaker };

String[] statsnoiseimage = {"Shouting", "Baby Gate Bounced", "Door Slammed",
  		"DIY", "Hoovering", "TV Music Loud","Kids Running", "Other", 
  		  "Loud Sound","Very Loud Sound","Extremely Loud Sound"};
 @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState); 
		setContentView(R.layout.tabs);
		
		TabHost tabhost=(TabHost)findViewById(R.id.tabmaster);
        tabhost.setup();
        final TabSpec topnoises = tabhost.newTabSpec("topnoises");
        topnoises.setContent(R.id.topnoisestab);
       
        
        topnoises.setIndicator("Top Noises", getApplicationContext().getResources().getDrawable(R.drawable.loudicon48));
        final TabSpec topmonths = tabhost.newTabSpec("topmonths");
        topmonths.setContent(R.id.topmonthstab);
       
        topmonths.setIndicator("Top Months", getApplicationContext().getResources().getDrawable(R.drawable.month));
        
        tabhost.addTab(topnoises);
        tabhost.addTab(topmonths);
        mDBstats = new DBAdapter(this);
	       mDBstats = mDBstats.open();
	       lstats = (ListView)findViewById(R.id.topnoiseslist);
		   noisestats = mDBstats.topnoises(); 
		   monthstats = mDBstats.topmonths();
		   adapternoise = new SimpleCursorAdapter(this,R.layout.stats_entires, noisestats, tabsfields, tabsviewfields);
		   adaptermonths = new SimpleCursorAdapter(this,R.layout.tabsmonths, monthstats, tabsfieldsmonths, tabsviewfieldsmon);
		   
		   lstats.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1,
						int arg2, long arg3) {
					
					// TODO Auto-generated method stub
			 		
					  Cursor noisepos = (Cursor) adapternoise.getItem(arg2);
					  
					  Integer noisedescid = noisepos.getInt(noisepos.getColumnIndex("noise_type_id"));
					  Cursor topn = mDBstats.topnoise(noisedescid);
					  Cursor topnm = mDBstats.topnoise_month(noisedescid);
					  topnm.moveToFirst();
					  Integer topnmonth = topnm.getInt(topnm.getColumnIndex("noise_month"));
					  Integer topncount = topnm.getInt(topnm.getColumnIndex("topnoisemonth"));
					  String noisedescstr = statsnoiseimage[noisedescid];
					  String statinfo = "Total Number of Records: "+topn.getCount()+"\n"
					  +"Top Month: "+months(topnmonth)+"\n"+months(topnmonth)+" has a total of: "+String.valueOf(topncount);
					  new AlertDialog.Builder(StatsScreen.this)
						.setMessage(statinfo)
						.setTitle("Noise Stats for "+noisedescstr)
						.setCancelable(false)
						.setIcon(statsnoiserefer[noisedescid])
						.setPositiveButton("OK", new DialogInterface.OnClickListener() {
							
							@Override
							public void onClick(DialogInterface dialog, int which) {
								// TODO Auto-generated method stub
							   dialog.cancel();
							}
						})
						.show();
					  
					  
					  //Toast.makeText(StatsScreen.this,"Noise Description is :"+noisedescstr, Toast.LENGTH_LONG).show();
					  //Toast.makeText(StatsScreen.this,noisedescstr+" Has A Total Of :"+topnm.getCount()+" Records within the months", Toast.LENGTH_LONG).show();
					  //Toast.makeText(StatsScreen.this,noisedescstr+" Has A Total Of :"+Integer.valueOf(topncount)+" Records in Month="+Integer.toString(topnmonth), Toast.LENGTH_LONG).show();
				}});	

       tabhost.setOnTabChangedListener( new OnTabChangeListener() {

		@Override
		public void onTabChanged(String arg0) {
			// TODO Auto-generated method stub
			
			if (arg0.equals("topnoises")) {
				Log.v("TOP_NOISES", "TAB PRESSED");
				lstats = (ListView)findViewById(R.id.topnoiseslist);
				
			    noisestats = mDBstats.topnoises();
			    adapternoise.changeCursor(noisestats);
			    lstats.setAdapter(adapternoise);
			 

			    top=0;
			    noise_month=true;
			}
			
			if (arg0.equals("topmonths")) {
				Log.v("TOP_MONTHS", "TAB PRESSED");
				lstats = (ListView)findViewById(R.id.topmonthslist);
			     monthstats = mDBstats.topmonths();
			     adaptermonths.changeCursor(monthstats);
			     lstats.setAdapter(adaptermonths);
			     lstats.setOnItemClickListener(new OnItemClickListener() {

						@Override
						public void onItemClick(AdapterView<?> arg0, View arg1,
								int arg2, long arg3) {
							
							// TODO Auto-generated method stub

								Cursor monthpos = (Cursor) adaptermonths.getItem(arg2);
								  Integer monthdescid = monthpos.getInt(monthpos.getColumnIndex("noise_month"));
								  Integer yeardescid = monthpos.getInt(monthpos.getColumnIndex("noise_year"));
								  String monthdescstr = months(monthdescid);
								  Cursor monthc = mDBstats.monthcount(monthdescid, yeardescid);
								  monthc.moveToFirst();
								  Cursor monthnc = mDBstats.noisemonthcount(monthdescid, yeardescid);
								  monthnc.moveToFirst();
								  Integer monthnoise = monthnc.getInt(monthnc.getColumnIndex("noise_type_id"));
								  Integer monthnoisec = monthnc.getInt(monthnc.getColumnIndex("noisecount"));
								  String monthtxt = "Total Records found:"+monthc.getCount()+"\n"
								    +"Top Noise is: "+statsnoiseimage[monthnoise]+"\n"
							        +statsnoiseimage[monthnoise]+" has a total of: "+Integer.toString(monthnoisec);
								  new AlertDialog.Builder(StatsScreen.this)
									.setMessage(monthtxt)
									.setTitle("Noise Stats for "+monthdescstr+" "+Integer.toString(yeardescid))
									.setCancelable(false)
									.setIcon(R.drawable.month)
									.setPositiveButton("OK", new DialogInterface.OnClickListener() {
										
										@Override
										public void onClick(DialogInterface dialog, int which) {
											// TODO Auto-generated method stub
										   dialog.cancel();
										}
									})
									.show();
								  //Toast.makeText(StatsScreen.this,"Noise Month/Year is :"+monthdescstr+"/"+yeardescid, Toast.LENGTH_LONG).show();

							
						
						}});	

			     top=0;
			     noise_month=false;
			}
		}}); 
        
        //lstats = (ListView)findViewById(R.id.topnoiseslist);
       lstats.setAdapter(adapternoise);   
	        
	   
        
        
        adapternoise.setViewBinder(new SimpleCursorAdapter.ViewBinder() {

			@Override
			public boolean setViewValue(View view, Cursor cursor,
					int columnIndex) {
				// TODO Auto-generated method stub
				
				if (view.getId()==R.id.pos) {
					
					
					((TextView)view).setText(Integer.toString(cursor.getPosition()+1)+")");
					
					return true;
				}
				String imgreference = cursor.getString(cursor.getColumnIndex("noise_image_desc"));
				if (view instanceof ImageView ) {
					//Log.i("IMG", "Setting unqiue image");
					int imgres = getResources().getIdentifier(imgreference, null, null);
					((ImageView)view).setImageResource(imgres);
					return true;
				} 
				if (view.getId()==R.id.stat_noise_desc) {
					int imgtext = cursor.getInt(cursor.getColumnIndex("noise_type_id"));
					((TextView)view).setText(statsnoiseimage[imgtext]);
					return true;
				}
				
				return false;
			}
		  
	       
	       
	       
   });

        
        
        adaptermonths.setViewBinder(new SimpleCursorAdapter.ViewBinder() {

			@Override
			public boolean setViewValue(View view, Cursor cursor,
					int columnIndex) {
				// TODO Auto-generated method stub
				
				if (view.getId()==R.id.posmonth) {
					
					((TextView)view).setText(Integer.toString(cursor.getPosition()+1)+")");
					
					return true;
				}
				if (view.getId()==R.id.stat_month) {
					
					
					((TextView)view).setText(months(cursor.getInt(cursor.getColumnIndex("noise_month"))));
					
					return true;
				}
				
				
				return false;
			}
		  
	       
	       
	       
   });

        
        
         
 }      
 
 public String months(Integer monthin) {
		String monthout="";
		switch (monthin) {
		
		case 1:
			monthout = statsmonthsofyear[0];
			break;
			
		case 2:
			monthout = statsmonthsofyear[1];
			break;
		
		case 3:
			monthout = statsmonthsofyear[2];
			break;
			
		case 4:
			monthout = statsmonthsofyear[3];
			break;
			
		case 5:
			monthout = statsmonthsofyear[4];
			break;
		
		case 6:
			monthout = statsmonthsofyear[5];
			break;
			
		case 7:
			monthout = statsmonthsofyear[6];
			break;
			
		case 8:
			monthout = statsmonthsofyear[7];
			break;
		
		case 9:
			monthout = statsmonthsofyear[8];
			break;
		
		case 10:
			monthout = statsmonthsofyear[9];
			break;
		
		case 11:
			monthout = statsmonthsofyear[10];
			break;
			
		case 12:
			monthout = statsmonthsofyear[11];
			break;
		
		}
		
		return monthout;
		
	}
		

 
}
